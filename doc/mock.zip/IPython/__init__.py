from __future__ import print_function
from _mock import _Mock

config = __import__('IPython.config', fromlist=['config'])
core = __import__('IPython.core', fromlist=['core'])
external = __import__('IPython.external', fromlist=['external'])
kernel = __import__('IPython.kernel', fromlist=['kernel'])
lib = __import__('IPython.lib', fromlist=['lib'])
qt = __import__('IPython.qt', fromlist=['qt'])
release = __import__('IPython.core.release', fromlist=['release'])
terminal = __import__('IPython.terminal', fromlist=['terminal'])
testing = __import__('IPython.testing', fromlist=['testing'])
utils = __import__('IPython.utils', fromlist=['utils'])


absolute_import = _Mock()

embed = _Mock()

embed_kernel = _Mock()

extract_module_locals = _Mock()

frontend = _Mock()

get_ipython = _Mock()

os = _Mock()

start_ipython = _Mock()

start_kernel = _Mock()

sys = _Mock()

sys_info = _Mock()

test = _Mock()

version_info = _Mock()

__version__ = '1.0.0'

class Application(_Mock):
  pass


class Config(_Mock):
  pass


class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class TryNext(_Mock):
  pass


