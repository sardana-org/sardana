from __future__ import print_function
from _mock import _Mock




absolute_import = _Mock()

import_item = _Mock()

kernel_method = _Mock()

os = _Mock()

uuid = _Mock()

zmq = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class Dict(_Mock):
  pass
  info_text = 'any value'

class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class DuplicateKernelError(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class LoggingConfigurable(_Mock):
  pass


class MultiKernelManager(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

