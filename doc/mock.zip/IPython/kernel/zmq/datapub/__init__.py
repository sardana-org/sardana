from __future__ import print_function
from _mock import _Mock




extract_header = _Mock()

json_clean = _Mock()

publish_data = _Mock()

serialize_object = _Mock()



class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Session(_Mock):
  pass


class SocketABC(_Mock):
  pass
  _abc_negative_cache_version = 37

class ZMQDataPublisher(_Mock):
  pass


