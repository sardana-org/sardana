from __future__ import print_function
from _mock import _Mock




encode_images = _Mock()

extract_header = _Mock()

sys = _Mock()



class Dict(_Mock):
  pass
  info_text = 'any value'

class DisplayHook(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Session(_Mock):
  pass


class SocketABC(_Mock):
  pass
  _abc_negative_cache_version = 37

class ZMQDisplayHook(_Mock):
  pass
  topic = 'pyout'

class ZMQShellDisplayHook(_Mock):
  pass


