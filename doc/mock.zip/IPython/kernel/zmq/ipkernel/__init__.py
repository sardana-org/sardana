from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
release = __import__('IPython.core.release', fromlist=['release'])


default_int_handler = _Mock()

ioloop = _Mock()

ipython_version = _Mock()

json_clean = _Mock()

language_version = _Mock()

logging = _Mock()

print_function = _Mock()

protocol_version = _Mock()

serialize_object = _Mock()

signal = _Mock()

sys = _Mock()

time = _Mock()

traceback = _Mock()

unpack_apply_message = _Mock()

uuid = _Mock()

zmq = _Mock()

SIGINT = 2

class Any(_Mock):
  pass
  info_text = 'any value'

class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Float(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class Kernel(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class Session(_Mock):
  pass


class Set(_Mock):
  pass
  info_text = 'any value'

class StdinNotImplementedError(_Mock):
  pass


class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class ZMQInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class ZMQStream(_Mock):
  pass


class datetime(_Mock):
  pass


