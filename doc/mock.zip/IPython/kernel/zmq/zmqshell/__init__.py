from __future__ import print_function
from _mock import _Mock

openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])
page = __import__('IPython.core.page', fromlist=['page'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


arg_split = _Mock()

connect_qtconsole = _Mock()

display = _Mock()

encode_images = _Mock()

error = _Mock()

extract_header = _Mock()

get_connection_file = _Mock()

get_connection_info = _Mock()

install_payload_page = _Mock()

ioloop = _Mock()

json_clean = _Mock()

line_magic = _Mock()

magics_class = _Mock()

os = _Mock()

print_function = _Mock()

skip_doctest = _Mock()

sys = _Mock()

time = _Mock()



class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class CodeMagics(_Mock):
  pass
  registered = True

class Dict(_Mock):
  pass
  info_text = 'any value'

class DisplayPublisher(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class InteractiveShellABC(_Mock):
  pass
  _abc_negative_cache_version = 42

class Javascript(_Mock):
  pass
  _read_flags = 'r'

class KernelMagics(_Mock):
  pass
  registered = True

class MacroToEdit(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class Session(_Mock):
  pass


class SocketABC(_Mock):
  pass
  _abc_negative_cache_version = 37

class Type(_Mock):
  pass
  info_text = 'any value'

class UsageError(_Mock):
  pass


class ZMQDataPublisher(_Mock):
  pass


class ZMQDisplayPublisher(_Mock):
  pass


class ZMQExitAutocall(_Mock):
  pass
  rewrite = False

class ZMQInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class ZMQShellDisplayHook(_Mock):
  pass


