from __future__ import print_function
from _mock import _Mock

datapub = __import__('IPython.kernel.zmq.datapub', fromlist=['datapub'])
displayhook = __import__('IPython.kernel.zmq.displayhook', fromlist=['displayhook'])
heartbeat = __import__('IPython.kernel.zmq.heartbeat', fromlist=['heartbeat'])
ipkernel = __import__('IPython.kernel.zmq.ipkernel', fromlist=['ipkernel'])
kernelapp = __import__('IPython.kernel.zmq.kernelapp', fromlist=['kernelapp'])
log = __import__('IPython.kernel.zmq.log', fromlist=['log'])
parentpoller = __import__('IPython.kernel.zmq.parentpoller', fromlist=['parentpoller'])
pylab = __import__('IPython.kernel.zmq.pylab', fromlist=['pylab'])
serialize = __import__('IPython.kernel.zmq.serialize', fromlist=['serialize'])
session = __import__('IPython.kernel.zmq.session', fromlist=['session'])
zmqshell = __import__('IPython.kernel.zmq.zmqshell', fromlist=['zmqshell'])


check_for_zmq = _Mock()



class Session(_Mock):
  pass


