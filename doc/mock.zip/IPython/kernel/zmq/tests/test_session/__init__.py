from __future__ import print_function
from _mock import _Mock

ss = __import__('IPython.kernel.zmq.session', fromlist=['session'])


os = _Mock()

uuid = _Mock()

zmq = _Mock()



class BaseZMQTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  green = False
  longMessage = False
  maxDiff = 640

class SessionTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  green = False
  longMessage = False
  maxDiff = 640

class TestSession(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  green = False
  longMessage = False
  maxDiff = 640

class ZMQStream(_Mock):
  pass


