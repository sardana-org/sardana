from __future__ import print_function
from _mock import _Mock






DEBUG = 10

ERROR = 40

FATAL = 50

INFO = 20

WARN = 30

class EnginePUBHandler(_Mock):
  pass


class PUBHandler(_Mock):
  pass
  root_topic = ''

