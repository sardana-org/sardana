from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


extract_header = _Mock()

os = _Mock()

threading = _Mock()

time = _Mock()

uuid = _Mock()

zmq = _Mock()

CHILD = 1

MASTER = 0

class OutStream(_Mock):
  pass
  _subprocess_flush_limit = 256
  flush_interval = 0.05

class StringIO(_Mock):
  pass


class UnsupportedOperation(_Mock):
  pass


