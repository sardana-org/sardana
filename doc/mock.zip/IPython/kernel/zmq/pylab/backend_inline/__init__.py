from __future__ import print_function
from _mock import _Mock




display = _Mock()

draw_if_interactive = _Mock()

flush_figures = _Mock()

matplotlib = _Mock()

new_figure_manager = _Mock()

print_figure = _Mock()

print_function = _Mock()

publish_display_data = _Mock()

select_figure_format = _Mock()

show = _Mock()

warn = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class Dict(_Mock):
  pass
  info_text = 'any value'

class FigureCanvas(_Mock):
  pass
  supports_blit = True

class FigureCanvasAgg(_Mock):
  pass
  supports_blit = True

class Gcf(_Mock):
  pass


class InlineBackend(_Mock):
  pass


class InlineBackendConfig(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class SingletonConfigurable(_Mock):
  pass


