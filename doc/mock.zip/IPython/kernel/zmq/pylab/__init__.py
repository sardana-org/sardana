from __future__ import print_function
from _mock import _Mock

backend_inline = __import__('IPython.kernel.zmq.pylab.backend_inline', fromlist=['backend_inline'])








