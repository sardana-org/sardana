from __future__ import print_function
from _mock import _Mock




os = _Mock()

socket = _Mock()

zmq = _Mock()

LOCALHOST = '127.0.0.1'

class Heartbeat(_Mock):
  pass
  _Thread__initialized = False

class Thread(_Mock):
  pass
  _Thread__initialized = False

