from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


DONE = _Mock()

cPickle = _Mock()

date_default = _Mock()

default_packer = _Mock()

default_secure = _Mock()

default_unpacker = _Mock()

extract_dates = _Mock()

extract_header = _Mock()

hashlib = _Mock()

hmac = _Mock()

import_item = _Mock()

json_packer = _Mock()

json_unpacker = _Mock()

jsonapi = _Mock()

logging = _Mock()

msg_header = _Mock()

os = _Mock()

pickle = _Mock()

pickle_packer = _Mock()

pickle_unpacker = _Mock()

pprint = _Mock()

random = _Mock()

session_aliases = _Mock()

session_flags = _Mock()

squash_dates = _Mock()

squash_unicode = _Mock()

str_to_bytes = _Mock()

str_to_unicode = _Mock()

test_msg2obj = _Mock()

uuid = _Mock()

zmq = _Mock()

DELIM = '<IDS|MSG>'

MAX_BYTES = 1024

MAX_ITEMS = 64

class Any(_Mock):
  pass
  info_text = 'any value'

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class CUnicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class IOLoop(_Mock):
  pass
  ERROR = 24
  NONE = 0
  READ = 1
  WRITE = 4
  _EPOLLERR = 8
  _EPOLLET = 2147483648
  _EPOLLHUP = 16
  _EPOLLIN = 1
  _EPOLLONESHOT = 1073741824
  _EPOLLOUT = 4
  _EPOLLPRI = 2
  _EPOLLRDHUP = 8192

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class LoggingConfigurable(_Mock):
  pass


class Message(_Mock):
  pass


class Session(_Mock):
  pass


class SessionFactory(_Mock):
  pass


class Set(_Mock):
  pass
  info_text = 'any value'

class TraitError(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class ZMQStream(_Mock):
  pass


class datetime(_Mock):
  pass


