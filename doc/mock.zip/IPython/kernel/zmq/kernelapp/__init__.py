from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


atexit = _Mock()

base_aliases = _Mock()

base_flags = _Mock()

catch_config_error = _Mock()

default_secure = _Mock()

filefind = _Mock()

import_item = _Mock()

ioloop = _Mock()

json = _Mock()

kernel_aliases = _Mock()

kernel_flags = _Mock()

main = _Mock()

os = _Mock()

print_function = _Mock()

session_aliases = _Mock()

session_flags = _Mock()

shell_aliases = _Mock()

shell_flags = _Mock()

signal = _Mock()

str_to_bytes = _Mock()

sys = _Mock()

write_connection_file = _Mock()

zmq = _Mock()

LOCALHOST = '127.0.0.1'

_ctrl_c_message = 'NOTE: When using the `ipython kernel` entry point, Ctrl-C will not work.\n\nTo exit, you will have to explicitly quit this process, by either sending\n"quit" from a client, or using Ctrl-\\ in UNIX-like environments.\n\nTo read more about this, see https://github.com/ipython/ipython/issues/2049\n\n'

class Any(_Mock):
  pass
  info_text = 'any value'

class BaseIPythonApplication(_Mock):
  pass
  _in_init_profile_dir = False

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class Dict(_Mock):
  pass
  info_text = 'any value'

class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class FormattedTB(_Mock):
  pass
  tb_offset = 0

class Heartbeat(_Mock):
  pass
  _Thread__initialized = False

class IPKernelApp(_Mock):
  pass
  _in_init_profile_dir = False
  name = 'ipkernel'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class InteractiveShellApp(_Mock):
  pass


class Kernel(_Mock):
  pass


class ParentPollerUnix(_Mock):
  pass
  _Thread__initialized = False

class ParentPollerWindows(_Mock):
  pass
  _Thread__initialized = False

class ProfileDir(_Mock):
  pass


class Session(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class ZMQInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class ZMQStream(_Mock):
  pass


