from __future__ import print_function
from _mock import _Mock




gobject = _Mock()

gtk = _Mock()

sys = _Mock()



class GTKEmbed(_Mock):
  pass


