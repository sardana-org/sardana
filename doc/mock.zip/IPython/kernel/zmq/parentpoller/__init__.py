from __future__ import print_function
from _mock import _Mock




ctypes = _Mock()

interrupt_main = _Mock()

os = _Mock()

platform = _Mock()

time = _Mock()

warn = _Mock()



class ParentPollerUnix(_Mock):
  pass
  _Thread__initialized = False

class ParentPollerWindows(_Mock):
  pass
  _Thread__initialized = False

class Thread(_Mock):
  pass
  _Thread__initialized = False

