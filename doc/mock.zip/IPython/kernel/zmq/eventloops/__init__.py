from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


enable_gui = _Mock()

loop_cocoa = _Mock()

loop_gtk = _Mock()

loop_map = _Mock()

loop_qt4 = _Mock()

loop_tk = _Mock()

loop_wx = _Mock()

sys = _Mock()

zmq = _Mock()



class Application(_Mock):
  pass


