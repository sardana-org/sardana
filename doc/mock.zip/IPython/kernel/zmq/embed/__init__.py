from __future__ import print_function
from _mock import _Mock




embed_kernel = _Mock()

extract_module_locals = _Mock()

sys = _Mock()



class IPKernelApp(_Mock):
  pass
  _in_init_profile_dir = False
  name = 'ipkernel'

