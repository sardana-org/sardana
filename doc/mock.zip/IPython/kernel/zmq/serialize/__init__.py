from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_extract_buffers = _Mock()

_restore_buffers = _Mock()

cPickle = _Mock()

can = _Mock()

can_sequence = _Mock()

flatten = _Mock()

istype = _Mock()

pack_apply_message = _Mock()

pickle = _Mock()

sequence_types = _Mock()

serialize_object = _Mock()

uncan = _Mock()

uncan_sequence = _Mock()

unpack_apply_message = _Mock()

unserialize_object = _Mock()

MAX_BYTES = 1024

MAX_ITEMS = 64

class CannedObject(_Mock):
  pass


