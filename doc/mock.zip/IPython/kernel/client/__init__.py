from __future__ import print_function
from _mock import _Mock




absolute_import = _Mock()

zmq = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class ConnectionFileMixin(_Mock):
  pass


class HBChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  time_to_dead = 3.0

class IOPubChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class Instance(_Mock):
  pass
  info_text = 'any value'

class KernelClient(_Mock):
  pass


class KernelClientABC(_Mock):
  pass
  _abc_negative_cache_version = 42

class LoggingConfigurable(_Mock):
  pass


class Session(_Mock):
  pass


class ShellChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  allow_stdin = True

class StdInChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class Type(_Mock):
  pass
  info_text = 'any value'

