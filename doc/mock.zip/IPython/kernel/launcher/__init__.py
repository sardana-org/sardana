from __future__ import print_function
from _mock import _Mock




cast_bytes_py2 = _Mock()

launch_kernel = _Mock()

make_ipkernel_cmd = _Mock()

os = _Mock()

swallow_argv = _Mock()

sys = _Mock()

PIPE = -1

class Popen(_Mock):
  pass


