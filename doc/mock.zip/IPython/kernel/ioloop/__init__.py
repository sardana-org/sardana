from __future__ import print_function
from _mock import _Mock

manager = __import__('IPython.kernel.ioloop.manager', fromlist=['manager'])
restarter = __import__('IPython.kernel.ioloop.restarter', fromlist=['restarter'])






class IOLoopKernelManager(_Mock):
  pass


class IOLoopKernelRestarter(_Mock):
  pass


