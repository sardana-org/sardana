from __future__ import print_function
from _mock import _Mock




absolute_import = _Mock()

ioloop = _Mock()



class IOLoopKernelRestarter(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class KernelRestarter(_Mock):
  pass


