from __future__ import print_function
from _mock import _Mock

tunnel = __import__('IPython.external.ssh.tunnel', fromlist=['tunnel'])


absolute_import = _Mock()

bytes_to_str = _Mock()

channel_socket_types = _Mock()

connect_qtconsole = _Mock()

filefind = _Mock()

find_connection_file = _Mock()

get_connection_file = _Mock()

get_connection_info = _Mock()

get_ipython_dir = _Mock()

getpass = _Mock()

glob = _Mock()

json = _Mock()

os = _Mock()

port_names = _Mock()

socket = _Mock()

str_to_bytes = _Mock()

sys = _Mock()

tempfile = _Mock()

tunnel_to_kernel = _Mock()

write_connection_file = _Mock()

zmq = _Mock()

LOCALHOST = '127.0.0.1'

PIPE = -1

channel = 'control'

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class ConnectionFileMixin(_Mock):
  pass


class HasTraits(_Mock):
  pass


class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class Popen(_Mock):
  pass


class ProfileDir(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

