from __future__ import print_function
from _mock import _Mock








class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Dict(_Mock):
  pass
  info_text = 'any value'

class Float(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class KernelRestarter(_Mock):
  pass


class LoggingConfigurable(_Mock):
  pass


