from __future__ import print_function
from _mock import _Mock

blocking = __import__('IPython.kernel.blocking', fromlist=['blocking'])
channels = __import__('IPython.kernel.channels', fromlist=['channels'])
channelsabc = __import__('IPython.kernel.channelsabc', fromlist=['channelsabc'])
client = __import__('IPython.kernel.client', fromlist=['client'])
clientabc = __import__('IPython.kernel.clientabc', fromlist=['clientabc'])
connect = __import__('IPython.kernel.connect', fromlist=['connect'])
inprocess = __import__('IPython.kernel.inprocess', fromlist=['inprocess'])
launcher = __import__('IPython.kernel.launcher', fromlist=['launcher'])
manager = __import__('IPython.kernel.manager', fromlist=['manager'])
managerabc = __import__('IPython.kernel.managerabc', fromlist=['managerabc'])
multikernelmanager = __import__('IPython.kernel.multikernelmanager', fromlist=['multikernelmanager'])
zmq = __import__('IPython.kernel.zmq', fromlist=['zmq'])


connect_qtconsole = _Mock()

find_connection_file = _Mock()

get_connection_file = _Mock()

get_connection_info = _Mock()

launch_kernel = _Mock()

make_ipkernel_cmd = _Mock()

swallow_argv = _Mock()

tunnel_to_kernel = _Mock()

write_connection_file = _Mock()



class BlockingKernelClient(_Mock):
  pass


class KernelClient(_Mock):
  pass


class KernelManager(_Mock):
  pass


class MultiKernelManager(_Mock):
  pass


