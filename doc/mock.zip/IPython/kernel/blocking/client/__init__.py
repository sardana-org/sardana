from __future__ import print_function
from _mock import _Mock








class BlockingHBChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  time_to_dead = 1.0

class BlockingIOPubChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class BlockingKernelClient(_Mock):
  pass


class BlockingShellChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  allow_stdin = True

class BlockingStdInChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class KernelClient(_Mock):
  pass


class Type(_Mock):
  pass
  info_text = 'any value'

