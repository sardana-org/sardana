from __future__ import print_function
from _mock import _Mock

channels = __import__('IPython.kernel.blocking.channels', fromlist=['channels'])
client = __import__('IPython.kernel.blocking.client', fromlist=['client'])






class BlockingKernelClient(_Mock):
  pass


