from __future__ import print_function
from _mock import _Mock




Queue = _Mock()



class BlockingChannelMixin(_Mock):
  pass


class BlockingHBChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  time_to_dead = 1.0

class BlockingIOPubChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class BlockingShellChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  allow_stdin = True

class BlockingStdInChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class HBChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  time_to_dead = 3.0

class IOPubChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class ShellChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  allow_stdin = True

class StdInChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

