from __future__ import print_function
from _mock import _Mock




raw_print = _Mock()



class BlockingChannelMixin(_Mock):
  pass


class BlockingInProcessIOPubChannel(_Mock):
  pass


class BlockingInProcessKernelClient(_Mock):
  pass


class BlockingInProcessShellChannel(_Mock):
  pass
  allow_stdin = True

class BlockingInProcessStdInChannel(_Mock):
  pass


class InProcessIOPubChannel(_Mock):
  pass


class InProcessKernelClient(_Mock):
  pass


class InProcessShellChannel(_Mock):
  pass
  allow_stdin = True

class InProcessStdInChannel(_Mock):
  pass


class Type(_Mock):
  pass
  info_text = 'any value'

