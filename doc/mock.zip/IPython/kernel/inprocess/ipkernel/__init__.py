from __future__ import print_function
from _mock import _Mock




contextmanager = _Mock()

json_clean = _Mock()

logging = _Mock()

sys = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class DummySocket(_Mock):
  pass


class Enum(_Mock):
  pass
  info_text = 'any value'

class InProcessInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class InProcessKernel(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class InteractiveShellABC(_Mock):
  pass
  _abc_negative_cache_version = 42

class Kernel(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class Type(_Mock):
  pass
  info_text = 'any value'

class ZMQInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

