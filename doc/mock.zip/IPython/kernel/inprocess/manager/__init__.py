from __future__ import print_function
from _mock import _Mock








class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class InProcessKernelManager(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class KernelManager(_Mock):
  pass


class KernelManagerABC(_Mock):
  pass
  _abc_negative_cache_version = 42

