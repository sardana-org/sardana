from __future__ import print_function
from _mock import _Mock




print_function = _Mock()

unittest = _Mock()



class BlockingInProcessKernelClient(_Mock):
  pass


class InProcessKernelManager(_Mock):
  pass


class InProcessKernelManagerTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

