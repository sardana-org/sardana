from __future__ import print_function
from _mock import _Mock




LOCAL_IPS = _Mock()

absolute_import = _Mock()

import_item = _Mock()

launch_kernel = _Mock()

make_ipkernel_cmd = _Mock()

signal = _Mock()

sys = _Mock()

time = _Mock()

zmq = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class ConnectionFileMixin(_Mock):
  pass


class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class Instance(_Mock):
  pass
  info_text = 'any value'

class KernelManager(_Mock):
  pass


class KernelManagerABC(_Mock):
  pass
  _abc_negative_cache_version = 42

class List(_Mock):
  pass
  info_text = 'any value'

class LoggingConfigurable(_Mock):
  pass


class Session(_Mock):
  pass


class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

