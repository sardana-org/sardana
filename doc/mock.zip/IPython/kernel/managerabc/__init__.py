from __future__ import print_function
from _mock import _Mock




abc = _Mock()



class ChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 35

class HBChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 35

class IOPubChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 35

class KernelManagerABC(_Mock):
  pass
  _abc_negative_cache_version = 42

class ShellChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 35

class StdInChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 35

