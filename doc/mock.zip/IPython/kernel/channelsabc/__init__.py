from __future__ import print_function
from _mock import _Mock




abc = _Mock()



class ChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 30

class HBChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 40

class IOPubChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 39

class ShellChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 38

class StdInChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 41

