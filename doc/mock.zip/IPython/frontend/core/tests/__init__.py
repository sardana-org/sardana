from __future__ import print_function
from _mock import _Mock

daft_extension = __import__('IPython.frontend.core.tests.daft_extension', fromlist=['daft_extension'])
nonascii = __import__('IPython.frontend.core.tests.nonascii', fromlist=['nonascii'])
nonascii2 = __import__('IPython.frontend.core.tests.nonascii2', fromlist=['nonascii2'])
print_argv = __import__('IPython.frontend.core.tests.print_argv', fromlist=['print_argv'])
refbug = __import__('IPython.frontend.core.tests.refbug', fromlist=['refbug'])
simpleerr = __import__('IPython.frontend.core.tests.simpleerr', fromlist=['simpleerr'])
tclass = __import__('IPython.frontend.core.tests.tclass', fromlist=['tclass'])
test_autocall = __import__('IPython.frontend.core.tests.test_autocall', fromlist=['test_autocall'])
test_completerlib = __import__('IPython.frontend.core.tests.test_completerlib', fromlist=['test_completerlib'])
test_imports = __import__('IPython.frontend.core.tests.test_imports', fromlist=['test_imports'])
test_page = __import__('IPython.frontend.core.tests.test_page', fromlist=['test_page'])
test_shellapp = __import__('IPython.frontend.core.tests.test_shellapp', fromlist=['test_shellapp'])
test_ultratb = __import__('IPython.frontend.core.tests.test_ultratb', fromlist=['test_ultratb'])








