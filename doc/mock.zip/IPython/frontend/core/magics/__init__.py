from __future__ import print_function
from _mock import _Mock

auto = __import__('IPython.frontend.core.magics.auto', fromlist=['auto'])
basic = __import__('IPython.frontend.core.magics.basic', fromlist=['basic'])
code = __import__('IPython.frontend.core.magics.code', fromlist=['code'])
config = __import__('IPython.frontend.core.magics.config', fromlist=['config'])
deprecated = __import__('IPython.frontend.core.magics.deprecated', fromlist=['deprecated'])
display = __import__('IPython.frontend.core.magics.display', fromlist=['display'])
execution = __import__('IPython.frontend.core.magics.execution', fromlist=['execution'])
extension = __import__('IPython.frontend.core.magics.extension', fromlist=['extension'])
history = __import__('IPython.frontend.core.magics.history', fromlist=['history'])
logging = __import__('IPython.frontend.core.magics.logging', fromlist=['logging'])
namespace = __import__('IPython.frontend.core.magics.namespace', fromlist=['namespace'])
osm = __import__('IPython.frontend.core.magics.osm', fromlist=['osm'])
pylab = __import__('IPython.frontend.core.magics.pylab', fromlist=['pylab'])
script = __import__('IPython.frontend.core.magics.script', fromlist=['script'])


magics_class = _Mock()



class AutoMagics(_Mock):
  pass
  registered = True

class BasicMagics(_Mock):
  pass
  registered = True

class CodeMagics(_Mock):
  pass
  registered = True

class ConfigMagics(_Mock):
  pass
  registered = True

class DeprecatedMagics(_Mock):
  pass
  registered = True

class DisplayMagics(_Mock):
  pass
  registered = True

class ExecutionMagics(_Mock):
  pass
  registered = True

class ExtensionMagics(_Mock):
  pass
  registered = True

class HistoryMagics(_Mock):
  pass
  registered = True

class LoggingMagics(_Mock):
  pass
  registered = True

class MacroToEdit(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class NamespaceMagics(_Mock):
  pass
  registered = True

class OSMagics(_Mock):
  pass
  registered = True

class PylabMagics(_Mock):
  pass
  registered = True

class ScriptMagics(_Mock):
  pass
  registered = True

class UserMagics(_Mock):
  pass
  registered = True

