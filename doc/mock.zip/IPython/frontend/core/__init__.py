from __future__ import print_function
from _mock import _Mock

alias = __import__('IPython.frontend.core.alias', fromlist=['alias'])
application = __import__('IPython.frontend.core.application', fromlist=['application'])
autocall = __import__('IPython.frontend.core.autocall', fromlist=['autocall'])
builtin_trap = __import__('IPython.frontend.core.builtin_trap', fromlist=['builtin_trap'])
compilerop = __import__('IPython.frontend.core.compilerop', fromlist=['compilerop'])
completer = __import__('IPython.frontend.core.completer', fromlist=['completer'])
completerlib = __import__('IPython.frontend.core.completerlib', fromlist=['completerlib'])
crashhandler = __import__('IPython.frontend.core.crashhandler', fromlist=['crashhandler'])
debugger = __import__('IPython.frontend.core.debugger', fromlist=['debugger'])
display = __import__('IPython.frontend.core.display', fromlist=['display'])
display_trap = __import__('IPython.frontend.core.display_trap', fromlist=['display_trap'])
displayhook = __import__('IPython.frontend.core.displayhook', fromlist=['displayhook'])
displaypub = __import__('IPython.frontend.core.displaypub', fromlist=['displaypub'])
error = __import__('IPython.frontend.core.error', fromlist=['error'])
excolors = __import__('IPython.frontend.core.excolors', fromlist=['excolors'])
extensions = __import__('IPython.frontend.core.extensions', fromlist=['extensions'])
fakemodule = __import__('IPython.frontend.core.fakemodule', fromlist=['fakemodule'])
formatters = __import__('IPython.frontend.core.formatters', fromlist=['formatters'])
getipython = __import__('IPython.frontend.core.getipython', fromlist=['getipython'])
history = __import__('IPython.frontend.core.history', fromlist=['history'])
historyapp = __import__('IPython.frontend.core.historyapp', fromlist=['historyapp'])
hooks = __import__('IPython.frontend.core.hooks', fromlist=['hooks'])
inputsplitter = __import__('IPython.frontend.core.inputsplitter', fromlist=['inputsplitter'])
inputtransformer = __import__('IPython.frontend.core.inputtransformer', fromlist=['inputtransformer'])
interactiveshell = __import__('IPython.frontend.core.interactiveshell', fromlist=['interactiveshell'])
logger = __import__('IPython.frontend.core.logger', fromlist=['logger'])
macro = __import__('IPython.frontend.core.macro', fromlist=['macro'])
magic = __import__('IPython.frontend.core.magic', fromlist=['magic'])
magic_arguments = __import__('IPython.frontend.core.magic_arguments', fromlist=['magic_arguments'])
magics = __import__('IPython.frontend.core.magics', fromlist=['magics'])
oinspect = __import__('IPython.frontend.core.oinspect', fromlist=['oinspect'])
page = __import__('IPython.frontend.core.page', fromlist=['page'])
payload = __import__('IPython.frontend.core.payload', fromlist=['payload'])
payloadpage = __import__('IPython.frontend.core.payloadpage', fromlist=['payloadpage'])
prefilter = __import__('IPython.frontend.core.prefilter', fromlist=['prefilter'])
profileapp = __import__('IPython.frontend.core.profileapp', fromlist=['profileapp'])
profiledir = __import__('IPython.frontend.core.profiledir', fromlist=['profiledir'])
prompts = __import__('IPython.frontend.core.prompts', fromlist=['prompts'])
pylabtools = __import__('IPython.frontend.core.pylabtools', fromlist=['pylabtools'])
release = __import__('IPython.frontend.core.release', fromlist=['release'])
shadowns = __import__('IPython.frontend.core.shadowns', fromlist=['shadowns'])
shellapp = __import__('IPython.frontend.core.shellapp', fromlist=['shellapp'])
splitinput = __import__('IPython.frontend.core.splitinput', fromlist=['splitinput'])
tests = __import__('IPython.frontend.core.tests', fromlist=['tests'])
ultratb = __import__('IPython.frontend.core.ultratb', fromlist=['ultratb'])
usage = __import__('IPython.frontend.core.usage', fromlist=['usage'])








