from __future__ import print_function
from _mock import _Mock

IPython = __import__('IPython', fromlist=['IPython'])
PyColorize = __import__('IPython.utils.PyColorize', fromlist=['PyColorize'])
debugger = __import__('IPython.core.debugger', fromlist=['debugger'])
io = __import__('IPython.utils.io', fromlist=['io'])
magic = __import__('IPython.core.magic', fromlist=['magic'])
oinspect = __import__('IPython.core.oinspect', fromlist=['oinspect'])
openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])
page = __import__('IPython.core.page', fromlist=['page'])
prefilter = __import__('IPython.core.prefilter', fromlist=['prefilter'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
shadowns = __import__('IPython.core.shadowns', fromlist=['shadowns'])
ultratb = __import__('IPython.core.ultratb', fromlist=['ultratb'])


abc = _Mock()

absolute_import = _Mock()

ask_yes_no = _Mock()

ast = _Mock()

atexit = _Mock()

builtin_mod = _Mock()

check_linecache_ipython = _Mock()

dedent_re = _Mock()

error = _Mock()

format_screen = _Mock()

get_default_colors = _Mock()

get_home_dir = _Mock()

get_ipython_dir = _Mock()

get_py_filename = _Mock()

getoutput = _Mock()

init_fakemod_dict = _Mock()

io_open = _Mock()

no_op = _Mock()

no_op_context = _Mock()

os = _Mock()

print_function = _Mock()

re = _Mock()

runpy = _Mock()

skip_doctest = _Mock()

softspace = _Mock()

sys = _Mock()

system = _Mock()

tempfile = _Mock()

types = _Mock()

undoc = _Mock()

unquote_filename = _Mock()

warn = _Mock()

ESC_MAGIC = '%'

ESC_MAGIC2 = '%%'

class AliasError(_Mock):
  pass


class AliasManager(_Mock):
  pass


class BuiltinTrap(_Mock):
  pass


class Bunch(_Mock):
  pass


class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CachingCompiler(_Mock):
  pass


class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class DisplayFormatter(_Mock):
  pass


class DisplayHook(_Mock):
  pass


class DisplayPublisher(_Mock):
  pass


class DisplayTrap(_Mock):
  pass


class DollarFormatter(_Mock):
  pass
  skip_doctest = False

class Enum(_Mock):
  pass
  info_text = 'any value'

class ExitAutocall(_Mock):
  pass
  rewrite = False

class ExtensionManager(_Mock):
  pass


class FakeModule(_Mock):
  pass


class HistoryManager(_Mock):
  pass


class IPythonInputSplitter(_Mock):
  pass
  _full_dedent = False
  encoding = ''
  indent_spaces = 0
  source = ''
  source_raw = ''
  transformer_accumulating = False
  within_python_line = False

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class InteractiveShellABC(_Mock):
  pass
  _abc_negative_cache_version = 55

class LSString(_Mock):
  pass


class LaTeXTool(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class Logger(_Mock):
  pass


class Macro(_Mock):
  pass


class NoOpContext(_Mock):
  pass


class PayloadManager(_Mock):
  pass


class PickleShareDB(_Mock):
  pass
  _abc_negative_cache_version = 56

class PrefilterManager(_Mock):
  pass


class ProfileDir(_Mock):
  pass


class PromptManager(_Mock):
  pass


class ReadlineNoRecord(_Mock):
  pass


class SList(_Mock):
  pass


class SeparateUnicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class SingletonConfigurable(_Mock):
  pass


class SpaceInInput(_Mock):
  pass


class StrDispatch(_Mock):
  pass


class Struct(_Mock):
  pass
  _allownew = True

class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class UsageError(_Mock):
  pass


class prepended_to_syspath(_Mock):
  pass


