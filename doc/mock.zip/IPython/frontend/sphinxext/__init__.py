from __future__ import print_function
from _mock import _Mock

ipython_console_highlighting = __import__('IPython.frontend.sphinxext.ipython_console_highlighting', fromlist=['ipython_console_highlighting'])
ipython_directive = __import__('IPython.frontend.sphinxext.ipython_directive', fromlist=['ipython_directive'])








