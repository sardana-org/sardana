from __future__ import print_function
from _mock import _Mock




Comment = _Mock()

Generic = _Mock()

do_insertions = _Mock()

highlighting = _Mock()

line_re = _Mock()

re = _Mock()

setup = _Mock()



class IPythonConsoleLexer(_Mock):
  pass
  name = 'IPython console session'
  priority = 0

class Lexer(_Mock):
  pass
  priority = 0

class PythonConsoleLexer(_Mock):
  pass
  name = 'Python console session'
  priority = 0

class PythonLexer(_Mock):
  pass
  _tmpname = 4
  flags = 8
  name = 'Python'
  priority = 0

class PythonTracebackLexer(_Mock):
  pass
  flags = 8
  name = 'Python Traceback'
  priority = 0

