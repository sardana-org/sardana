from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


ast = _Mock()

block_parser = _Mock()

cStringIO = _Mock()

directives = _Mock()

matplotlib = _Mock()

md5 = _Mock()

nodes = _Mock()

os = _Mock()

re = _Mock()

setup = _Mock()

sphinx = _Mock()

sys = _Mock()

tempfile = _Mock()

test = _Mock()

COMMENT = 0

INPUT = 1

OUTPUT = 2

class Config(_Mock):
  pass


class Directive(_Mock):
  pass
  final_argument_whitespace = False
  has_content = False
  optional_arguments = 0
  required_arguments = 0

class EmbeddedSphinxShell(_Mock):
  pass


class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class IpythonDirective(_Mock):
  pass
  final_argument_whitespace = False
  final_argumuent_whitespace = True
  has_content = True
  optional_arguments = 4
  required_arguments = 0

class ProfileDir(_Mock):
  pass


