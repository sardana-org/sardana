from __future__ import print_function
from _mock import _Mock




abspath = _Mock()

cast_bytes_py2 = _Mock()

cast_unicode = _Mock()

clear_output = _Mock()

display = _Mock()

display_html = _Mock()

display_javascript = _Mock()

display_jpeg = _Mock()

display_json = _Mock()

display_latex = _Mock()

display_png = _Mock()

display_pretty = _Mock()

display_svg = _Mock()

exists = _Mock()

isdir = _Mock()

isfile = _Mock()

join = _Mock()

os = _Mock()

print_function = _Mock()

publish_display_data = _Mock()

splitext = _Mock()

string_types = _Mock()

struct = _Mock()

walk = _Mock()

css_t = '$("head").append($("<link/>").attr({\n  rel:  "stylesheet",\n  type: "text/css",\n  href: "%s"\n}));\n'

lib_t1 = '$.getScript("%s", function () {\n'

lib_t2 = '});\n'

sep = '/'

class DisplayObject(_Mock):
  pass
  _read_flags = 'r'

class FileLink(_Mock):
  pass
  html_link_str = "<a href='%s' target='_blank'>%s</a>"

class FileLinks(_Mock):
  pass
  html_link_str = "<a href='%s' target='_blank'>%s</a>"

class HTML(_Mock):
  pass
  _read_flags = 'r'

class IFrame(_Mock):
  pass
  iframe = '\n        <iframe\n            width="{width}"\n            height={height}"\n            src="{src}{params}"\n            frameborder="0"\n            allowfullscreen\n        ></iframe>\n        '

class Image(_Mock):
  pass
  _FMT_JPEG = u'jpeg'
  _FMT_PNG = u'png'
  _read_flags = 'rb'

class JSON(_Mock):
  pass
  _read_flags = 'r'

class Javascript(_Mock):
  pass
  _read_flags = 'r'

class Latex(_Mock):
  pass
  _read_flags = 'r'

class Math(_Mock):
  pass
  _read_flags = 'r'

class Pretty(_Mock):
  pass
  _read_flags = 'r'

class SVG(_Mock):
  pass
  _read_flags = 'r'

class ScribdDocument(_Mock):
  pass
  iframe = '\n        <iframe\n            width="{width}"\n            height={height}"\n            src="{src}{params}"\n            frameborder="0"\n            allowfullscreen\n        ></iframe>\n        '

class VimeoVideo(_Mock):
  pass
  iframe = '\n        <iframe\n            width="{width}"\n            height={height}"\n            src="{src}{params}"\n            frameborder="0"\n            allowfullscreen\n        ></iframe>\n        '

class YouTubeVideo(_Mock):
  pass
  iframe = '\n        <iframe\n            width="{width}"\n            height={height}"\n            src="{src}{params}"\n            frameborder="0"\n            allowfullscreen\n        ></iframe>\n        '

