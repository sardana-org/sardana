from __future__ import print_function
from _mock import _Mock




classtypes = _Mock()

generic = _Mock()

test_suite = _Mock()



class ClassType(_Mock):
  pass


class InstanceType(_Mock):
  pass


