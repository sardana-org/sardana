from __future__ import print_function
from _mock import _Mock

_simplegeneric = __import__('IPython.frontend.external.simplegeneric._simplegeneric', fromlist=['_simplegeneric'])


generic = _Mock()





