from __future__ import print_function
from _mock import _Mock




ID = _Mock()

can_import = _Mock()

check_version = _Mock()

commit_api = _Mock()

has_binding = _Mock()

import_pyqt4 = _Mock()

import_pyside = _Mock()

load_qt = _Mock()

loaded_api = _Mock()

qtapi_version = _Mock()

sys = _Mock()

QT_API_PYQT = 'pyqt'

QT_API_PYQT_DEFAULT = 'pyqtdefault'

QT_API_PYQTv1 = 'pyqtv1'

QT_API_PYSIDE = 'pyside'

class ImportDenier(_Mock):
  pass


class partial(_Mock):
  pass


