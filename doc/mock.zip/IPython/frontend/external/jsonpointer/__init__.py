from __future__ import print_function
from _mock import _Mock

_jsonpointer = __import__('IPython.frontend.external.jsonpointer._jsonpointer', fromlist=['_jsonpointer'])


pairwise = _Mock()

resolve_pointer = _Mock()

set_pointer = _Mock()

tee = _Mock()

unquote = _Mock()



class JsonPointer(_Mock):
  pass


class JsonPointerException(_Mock):
  pass


class izip(_Mock):
  pass


