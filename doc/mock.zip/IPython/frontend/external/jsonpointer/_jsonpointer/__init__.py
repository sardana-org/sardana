from __future__ import print_function
from _mock import _Mock




_nothing = _Mock()

pairwise = _Mock()

resolve_pointer = _Mock()

set_pointer = _Mock()

tee = _Mock()

unquote = _Mock()

__version__ = '0.3'

class JsonPointer(_Mock):
  pass


class JsonPointerException(_Mock):
  pass


class izip(_Mock):
  pass


