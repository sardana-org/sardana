from __future__ import print_function
from _mock import _Mock

_pexpect = __import__('IPython.frontend.external.pexpect._pexpect', fromlist=['_pexpect'])


pexpect = _Mock()

run = _Mock()

split_command_line = _Mock()

which = _Mock()

__version__ = '2.3'

class EOF(_Mock):
  pass


class ExceptionPexpect(_Mock):
  pass


class TIMEOUT(_Mock):
  pass


class spawn(_Mock):
  pass


