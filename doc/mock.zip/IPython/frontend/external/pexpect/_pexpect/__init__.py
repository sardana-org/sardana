from __future__ import print_function
from _mock import _Mock




_cast_bytes = _Mock()

_cast_unicode = _Mock()

errno = _Mock()

fcntl = _Mock()

os = _Mock()

pty = _Mock()

re = _Mock()

resource = _Mock()

run = _Mock()

select = _Mock()

signal = _Mock()

split_command_line = _Mock()

struct = _Mock()

sys = _Mock()

termios = _Mock()

time = _Mock()

traceback = _Mock()

tty = _Mock()

types = _Mock()

version_info = _Mock()

which = _Mock()

PY3 = _Mock()

__version__ = '2.6.dev'

version = '2.6.dev'

class EOF(_Mock):
  pass


class ExceptionPexpect(_Mock):
  pass


class TIMEOUT(_Mock):
  pass


class re_type(_Mock):
  pass


class searcher_re(_Mock):
  pass


class searcher_string(_Mock):
  pass


class spawn(_Mock):
  pass
  _empty_buffer = u''
  _pty_newline = u'\r\n'
  encoding = 'utf-8'

class spawnb(_Mock):
  pass
  _empty_buffer = ''
  _pty_newline = '\r\n'
  encoding = 'utf-8'

