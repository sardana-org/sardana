from __future__ import print_function
from _mock import _Mock




_ = _Mock()

_callable = _Mock()

_copy = _Mock()

_ensure_value = _Mock()

_get_action_name = _Mock()

_os = _Mock()

_re = _Mock()

_sorted = _Mock()

_sys = _Mock()

_textwrap = _Mock()

ONE_OR_MORE = '+'

OPTIONAL = '?'

PARSER = 'A...'

REMAINDER = '...'

SUPPRESS = '==SUPPRESS=='

ZERO_OR_MORE = '*'

__version__ = '1.1'

class Action(_Mock):
  pass


class ArgumentDefaultsHelpFormatter(_Mock):
  pass


class ArgumentError(_Mock):
  pass


class ArgumentParser(_Mock):
  pass


class ArgumentTypeError(_Mock):
  pass


class FileType(_Mock):
  pass


class HelpFormatter(_Mock):
  pass


class Namespace(_Mock):
  pass


class RawDescriptionHelpFormatter(_Mock):
  pass


class RawTextHelpFormatter(_Mock):
  pass


class _ActionsContainer(_Mock):
  pass


class _AppendAction(_Mock):
  pass


class _AppendConstAction(_Mock):
  pass


class _ArgumentGroup(_Mock):
  pass


class _AttributeHolder(_Mock):
  pass


class _CountAction(_Mock):
  pass


class _HelpAction(_Mock):
  pass


class _MutuallyExclusiveGroup(_Mock):
  pass


class _StoreAction(_Mock):
  pass


class _StoreConstAction(_Mock):
  pass


class _StoreFalseAction(_Mock):
  pass


class _StoreTrueAction(_Mock):
  pass


class _SubParsersAction(_Mock):
  pass


class _VersionAction(_Mock):
  pass


class _basestring(_Mock):
  pass


class _set(_Mock):
  pass


