from __future__ import print_function
from _mock import _Mock

_argparse = __import__('IPython.frontend.external.argparse._argparse', fromlist=['_argparse'])


argparse = _Mock()

check_version = _Mock()

ONE_OR_MORE = '+'

OPTIONAL = '?'

PARSER = 'A...'

REMAINDER = '...'

SUPPRESS = '==SUPPRESS=='

ZERO_OR_MORE = '*'

class Action(_Mock):
  pass


class ArgumentDefaultsHelpFormatter(_Mock):
  pass


class ArgumentError(_Mock):
  pass


class ArgumentParser(_Mock):
  pass


class ArgumentTypeError(_Mock):
  pass


class FileType(_Mock):
  pass


class HelpFormatter(_Mock):
  pass


class Namespace(_Mock):
  pass


class RawDescriptionHelpFormatter(_Mock):
  pass


class RawTextHelpFormatter(_Mock):
  pass


