from __future__ import print_function
from _mock import _Mock

argparse = __import__('IPython.external.argparse', fromlist=['argparse'])


check_perms = _Mock()

extract_tar = _Mock()

extract_zip = _Mock()

install_mathjax = _Mock()

locate_profile = _Mock()

main = _Mock()

os = _Mock()

shutil = _Mock()

sys = _Mock()

tarfile = _Mock()

test_func = _Mock()

urllib2 = _Mock()

zipfile = _Mock()

default_dest = u'/home/zreszela/.ipython/profile_default/static/mathjax'

static = u'/home/zreszela/.ipython/profile_default/static'



