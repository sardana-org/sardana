from __future__ import print_function
from _mock import _Mock




deprecated = _Mock()

knownfailureif = _Mock()

setastest = _Mock()

skipif = _Mock()

slow = _Mock()

warnings = _Mock()



class WarningManager(_Mock):
  pass


