from __future__ import print_function
from _mock import _Mock

_decorators = __import__('IPython.frontend.external.decorators._decorators', fromlist=['_decorators'])
_numpy_testing_utils = __import__('IPython.frontend.external.decorators._numpy_testing_utils', fromlist=['_numpy_testing_utils'])


deprecated = _Mock()

knownfailureif = _Mock()

setastest = _Mock()

skipif = _Mock()

slow = _Mock()

sys = _Mock()

warnings = _Mock()



class WarningManager(_Mock):
  pass


class WarningMessage(_Mock):
  pass


