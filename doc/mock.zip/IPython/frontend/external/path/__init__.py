from __future__ import print_function
from _mock import _Mock

_path = __import__('IPython.frontend.external.path._path', fromlist=['_path'])






class path(_Mock):
  pass


