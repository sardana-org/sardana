from __future__ import print_function
from _mock import _Mock




codecs = _Mock()

fnmatch = _Mock()

generators = _Mock()

glob = _Mock()

md5 = _Mock()

os = _Mock()

pwd = _Mock()

shutil = _Mock()

sys = _Mock()

warnings = _Mock()

__version__ = '2.2'

class TreeWalkWarning(_Mock):
  pass


class path(_Mock):
  pass


