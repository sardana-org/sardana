from __future__ import print_function
from _mock import _Mock

argparse = __import__('IPython.frontend.external.argparse', fromlist=['argparse'])
decorator = __import__('IPython.frontend.external.decorator', fromlist=['decorator'])
decorators = __import__('IPython.frontend.external.decorators', fromlist=['decorators'])
jsonpointer = __import__('IPython.frontend.external.jsonpointer', fromlist=['jsonpointer'])
jsonschema = __import__('IPython.frontend.external.jsonschema', fromlist=['jsonschema'])
mathjax = __import__('IPython.frontend.external.mathjax', fromlist=['mathjax'])
path = __import__('IPython.frontend.external.path', fromlist=['path'])
pexpect = __import__('IPython.frontend.external.pexpect', fromlist=['pexpect'])
qt_for_kernel = __import__('IPython.frontend.external.qt_for_kernel', fromlist=['qt_for_kernel'])
qt_loaders = __import__('IPython.frontend.external.qt_loaders', fromlist=['qt_loaders'])
simplegeneric = __import__('IPython.frontend.external.simplegeneric', fromlist=['simplegeneric'])
ssh = __import__('IPython.frontend.external.ssh', fromlist=['ssh'])








