from __future__ import print_function
from _mock import _Mock




_delist = _Mock()

_extras_msg = _Mock()

_find_additional_properties = _Mock()

_flatten = _Mock()

_list = _Mock()

_types_msg = _Mock()

_uniq = _Mock()

collections = _Mock()

division = _Mock()

iteritems = _Mock()

itertools = _Mock()

operator = _Mock()

re = _Mock()

resolve_json_pointer = _Mock()

sys = _Mock()

unicode_literals = _Mock()

unquote = _Mock()

validate = _Mock()

warnings = _Mock()

FLOAT_TOLERANCE = 1e-15

PY3 = _Mock()

__version__ = u'0.7'

class Draft3Validator(_Mock):
  pass


class ErrorTree(_Mock):
  pass


class InvalidRef(_Mock):
  pass


class SchemaError(_Mock):
  pass


class UnknownType(_Mock):
  pass


class ValidationError(_Mock):
  pass


class Validator(_Mock):
  pass


class zip(_Mock):
  pass


