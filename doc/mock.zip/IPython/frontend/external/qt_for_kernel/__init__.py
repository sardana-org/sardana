from __future__ import print_function
from _mock import _Mock




QtCore = _Mock()

QtGui = _Mock()

QtSvg = _Mock()

api_opts = _Mock()

check_version = _Mock()

get_options = _Mock()

load_qt = _Mock()

loaded_api = _Mock()

matplotlib_options = _Mock()

os = _Mock()

sys = _Mock()

warn = _Mock()

QT_API = 'pyqtv1'

QT_API_PYQT = 'pyqt'

QT_API_PYQT_DEFAULT = 'pyqtdefault'

QT_API_PYSIDE = 'pyside'



