from __future__ import print_function
from _mock import _Mock

_decorator = __import__('IPython.frontend.external.decorator._decorator', fromlist=['_decorator'])


decorator = _Mock()



class FunctionMaker(_Mock):
  pass


class partial(_Mock):
  pass


