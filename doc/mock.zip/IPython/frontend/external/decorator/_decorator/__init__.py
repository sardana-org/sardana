from __future__ import print_function
from _mock import _Mock




DEF = _Mock()

decorator = _Mock()

inspect = _Mock()

re = _Mock()

sys = _Mock()

__version__ = '3.3.3'

class FunctionMaker(_Mock):
  pass


class getfullargspec(_Mock):
  pass


class partial(_Mock):
  pass


