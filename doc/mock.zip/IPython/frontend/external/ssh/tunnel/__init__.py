from __future__ import print_function
from _mock import _Mock

pexpect = __import__('IPython.external.pexpect', fromlist=['pexpect'])


_paramiko_tunnel = _Mock()

_random_ports = _Mock()

_shutdown_process = _Mock()

_split_server = _Mock()

_try_passwordless_openssh = _Mock()

_try_passwordless_paramiko = _Mock()

atexit = _Mock()

getpass = _Mock()

getuser = _Mock()

open_tunnel = _Mock()

openssh_tunnel = _Mock()

os = _Mock()

paramiko = _Mock()

paramiko_tunnel = _Mock()

print_function = _Mock()

select_random_ports = _Mock()

signal = _Mock()

socket = _Mock()

ssh_tunnel = _Mock()

sys = _Mock()

try_passwordless_ssh = _Mock()

tunnel_connection = _Mock()

warnings = _Mock()



class Process(_Mock):
  pass


