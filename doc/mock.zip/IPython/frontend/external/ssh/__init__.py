from __future__ import print_function
from _mock import _Mock

forward = __import__('IPython.frontend.external.ssh.forward', fromlist=['forward'])
tunnel = __import__('IPython.frontend.external.ssh.tunnel', fromlist=['tunnel'])








