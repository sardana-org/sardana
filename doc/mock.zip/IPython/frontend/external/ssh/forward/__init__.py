from __future__ import print_function
from _mock import _Mock




SocketServer = _Mock()

forward_tunnel = _Mock()

logger = _Mock()

logging = _Mock()

print_function = _Mock()

select = _Mock()



class ForwardServer(_Mock):
  pass
  address_family = 2
  allow_reuse_address = True
  daemon_threads = True
  request_queue_size = 5
  socket_type = 1

class Handler(_Mock):
  pass


