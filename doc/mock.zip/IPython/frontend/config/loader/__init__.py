from __future__ import print_function
from _mock import _Mock

argparse = __import__('IPython.external.argparse', fromlist=['argparse'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
warn = __import__('IPython.utils.warn', fromlist=['warn'])


builtin_mod = _Mock()

filefind = _Mock()

flag_pattern = _Mock()

get_ipython_dir = _Mock()

kv_pattern = _Mock()

load_pyconfig_files = _Mock()

os = _Mock()

re = _Mock()

sys = _Mock()

DEFAULT_ENCODING = 'UTF-8'

class ArgParseConfigLoader(_Mock):
  pass


class ArgumentError(_Mock):
  pass


class ArgumentParser(_Mock):
  pass


class CommandLineConfigLoader(_Mock):
  pass


class Config(_Mock):
  pass


class ConfigError(_Mock):
  pass


class ConfigFileNotFound(_Mock):
  pass


class ConfigLoader(_Mock):
  pass


class ConfigLoaderError(_Mock):
  pass


class FileConfigLoader(_Mock):
  pass


class KVArgParseConfigLoader(_Mock):
  pass


class KeyValueConfigLoader(_Mock):
  pass


class PyFileConfigLoader(_Mock):
  pass


