from __future__ import print_function
from _mock import _Mock




datetime = _Mock()

deepcopy = _Mock()

indent = _Mock()

wrap_paragraphs = _Mock()



class Config(_Mock):
  pass


class Configurable(_Mock):
  pass


class ConfigurableError(_Mock):
  pass


class HasTraits(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class LoggingConfigurable(_Mock):
  pass


class MultipleInstanceError(_Mock):
  pass


class SingletonConfigurable(_Mock):
  pass


