from __future__ import print_function
from _mock import _Mock






PY3 = _Mock()

mc_help = u'MyConfigurable options\n----------------------\n--MyConfigurable.a=<Integer>\n    Default: 1\n    The integer a.\n--MyConfigurable.b=<Float>\n    Default: 1.0\n    The integer b.'

mc_help_inst = u'MyConfigurable options\n----------------------\n--MyConfigurable.a=<Integer>\n    Current: 5\n    The integer a.\n--MyConfigurable.b=<Float>\n    Current: 4.0\n    The integer b.'

class Bar(_Mock):
  pass


class Config(_Mock):
  pass


class Configurable(_Mock):
  pass


class Float(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Foo(_Mock):
  pass


class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class MyConfigurable(_Mock):
  pass


class MyParent(_Mock):
  pass


class MyParent2(_Mock):
  pass


class SingletonConfigurable(_Mock):
  pass


class TestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestConfigurable(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestParentConfigurable(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestSingletonConfigurable(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

