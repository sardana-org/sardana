from __future__ import print_function
from _mock import _Mock




logging = _Mock()



class Application(_Mock):
  pass


class Bar(_Mock):
  pass


class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Config(_Mock):
  pass


class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Foo(_Mock):
  pass


class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class List(_Mock):
  pass
  info_text = 'any value'

class MyApp(_Mock):
  pass


class TestApplication(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

