from __future__ import print_function
from _mock import _Mock

test_application = __import__('IPython.frontend.config.tests.test_application', fromlist=['test_application'])
test_configurable = __import__('IPython.frontend.config.tests.test_configurable', fromlist=['test_configurable'])








