from __future__ import print_function
from _mock import _Mock

application = __import__('IPython.frontend.config.application', fromlist=['application'])
configurable = __import__('IPython.frontend.config.configurable', fromlist=['configurable'])
loader = __import__('IPython.frontend.config.loader', fromlist=['loader'])
profile = __import__('IPython.frontend.config.profile', fromlist=['profile'])
tests = __import__('IPython.frontend.config.tests', fromlist=['tests'])


boolean_flag = _Mock()

catch_config_error = _Mock()

datetime = _Mock()

decorator = _Mock()

dedent = _Mock()

deepcopy = _Mock()

import_item = _Mock()

indent = _Mock()

logging = _Mock()

os = _Mock()

re = _Mock()

sys = _Mock()

wrap_paragraphs = _Mock()

keyvalue_description = "Parameters are set from command-line arguments of the form:\n`--Class.trait=value`.\nThis line is evaluated in Python, so simple expressions are allowed, e.g.::\n`--C.a='range(3)'` For setting C.a=[0,1,2]."

option_description = "Arguments that take values are actually convenience aliases to full\nConfigurables, whose aliases are listed on the help line. For more information\non full configurables, see '--help-all'."

subcommand_description = "Subcommands are launched as `buildmock.py cmd [args]`. For information on using\nsubcommand 'cmd', do: `buildmock.py cmd -h`."

class Application(_Mock):
  pass


class ApplicationError(_Mock):
  pass


class ArgumentError(_Mock):
  pass


class Config(_Mock):
  pass


class ConfigFileNotFound(_Mock):
  pass


class Configurable(_Mock):
  pass


class ConfigurableError(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Enum(_Mock):
  pass
  info_text = 'any value'

class HasTraits(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class KVArgParseConfigLoader(_Mock):
  pass


class LevelFormatter(_Mock):
  pass
  highlevel_format = ' %(levelname)s |'
  highlevel_limit = 30

class List(_Mock):
  pass
  info_text = 'any value'

class LoggingConfigurable(_Mock):
  pass


class MultipleInstanceError(_Mock):
  pass


class PyFileConfigLoader(_Mock):
  pass


class SingletonConfigurable(_Mock):
  pass


class TraitError(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class defaultdict(_Mock):
  pass


