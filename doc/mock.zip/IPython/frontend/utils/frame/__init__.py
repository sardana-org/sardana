from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


debugx = _Mock()

extract_module_locals = _Mock()

extract_vars = _Mock()

extract_vars_above = _Mock()

sys = _Mock()





