from __future__ import print_function
from _mock import _Mock




clock = _Mock()

clock2 = _Mock()

clocks = _Mock()

clocku = _Mock()

resource = _Mock()

time = _Mock()

timing = _Mock()

timings = _Mock()

timings_out = _Mock()





