from __future__ import print_function
from _mock import _Mock




check_submodule_status = _Mock()

ipython_parent = _Mock()

ipython_submodules = _Mock()

is_repo = _Mock()

os = _Mock()

pjoin = _Mock()

subprocess = _Mock()

sys = _Mock()

update_submodules = _Mock()





