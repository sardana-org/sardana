from __future__ import print_function
from _mock import _Mock




LOCAL_IPS = _Mock()

PUBLIC_IPS = _Mock()

socket = _Mock()

uniq_stable = _Mock()

LOCALHOST = '127.0.0.1'

hostname = 'pc255'



