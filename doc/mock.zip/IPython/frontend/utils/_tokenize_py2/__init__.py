from __future__ import print_function
from _mock import _Mock




ISEOF = _Mock()

ISNONTERMINAL = _Mock()

ISTERMINAL = _Mock()

any = _Mock()

double3prog = _Mock()

endprogs = _Mock()

generate_tokens = _Mock()

group = _Mock()

main = _Mock()

maybe = _Mock()

printtoken = _Mock()

pseudoprog = _Mock()

re = _Mock()

single3prog = _Mock()

single_quoted = _Mock()

string = _Mock()

tok_name = _Mock()

tokenize = _Mock()

tokenize_loop = _Mock()

tokenprog = _Mock()

triple_quoted = _Mock()

untokenize = _Mock()

AMPER = 19

AMPEREQUAL = 42

AT = 50

BACKQUOTE = 25

Binnumber = '0[bB][01]+[lL]?'

Bracket = '[][(){}]'

CIRCUMFLEX = 33

CIRCUMFLEXEQUAL = 44

COLON = 11

COMMA = 12

COMMENT = 53

Comment = '#[^\\r\\n]*'

ContStr = '([uUbB]?[rR]?\'[^\\n\'\\\\]*(?:\\\\.[^\\n\'\\\\]*)*(\'|\\\\\\r?\\n)|[uUbB]?[rR]?"[^\\n"\\\\]*(?:\\\\.[^\\n"\\\\]*)*("|\\\\\\r?\\n))'

DEDENT = 6

DOT = 23

DOUBLESLASH = 48

DOUBLESLASHEQUAL = 49

DOUBLESTAR = 36

DOUBLESTAREQUAL = 47

Decnumber = '[1-9]\\d*[lL]?'

Double = '[^"\\\\]*(?:\\\\.[^"\\\\]*)*"'

Double3 = '[^"\\\\]*(?:(?:\\\\.|"(?!""))[^"\\\\]*)*"""'

ENDMARKER = 0

EQEQUAL = 28

EQUAL = 22

ERRORTOKEN = 52

Expfloat = '\\d+[eE][-+]?\\d+'

Exponent = '[eE][-+]?\\d+'

Floatnumber = '((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)'

Funny = '((\\*\\*=?|>>=?|<<=?|<>|!=|//=?|[+\\-*/%&|^=<>]=?|~)|[][(){}]|(\\r?\\n|[:;.,`@]))'

GREATER = 21

GREATEREQUAL = 31

Hexnumber = '0[xX][\\da-fA-F]+[lL]?'

INDENT = 5

Ignore = '[ \\f\\t]*(\\\\\\r?\\n[ \\f\\t]*)*(#[^\\r\\n]*)?'

Imagnumber = '(\\d+[jJ]|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)[jJ])'

Intnumber = '(0[xX][\\da-fA-F]+[lL]?|0[bB][01]+[lL]?|(0[oO][0-7]+)|(0[0-7]*)[lL]?|[1-9]\\d*[lL]?)'

LBRACE = 26

LEFTSHIFT = 34

LEFTSHIFTEQUAL = 45

LESS = 20

LESSEQUAL = 30

LPAR = 7

LSQB = 9

MINEQUAL = 38

MINUS = 15

NAME = 1

NEWLINE = 4

NL = 54

NOTEQUAL = 29

NT_OFFSET = 256

NUMBER = 2

N_TOKENS = 55

Name = '[a-zA-Z_]\\w*'

Number = '((\\d+[jJ]|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)[jJ])|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)|(0[xX][\\da-fA-F]+[lL]?|0[bB][01]+[lL]?|(0[oO][0-7]+)|(0[0-7]*)[lL]?|[1-9]\\d*[lL]?))'

OP = 51

Octnumber = '(0[oO][0-7]+)|(0[0-7]*)[lL]?'

Operator = '(\\*\\*=?|>>=?|<<=?|<>|!=|//=?|[+\\-*/%&|^=<>]=?|~)'

PERCENT = 24

PERCENTEQUAL = 41

PLUS = 14

PLUSEQUAL = 37

PlainToken = '(((\\d+[jJ]|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)[jJ])|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)|(0[xX][\\da-fA-F]+[lL]?|0[bB][01]+[lL]?|(0[oO][0-7]+)|(0[0-7]*)[lL]?|[1-9]\\d*[lL]?))|((\\*\\*=?|>>=?|<<=?|<>|!=|//=?|[+\\-*/%&|^=<>]=?|~)|[][(){}]|(\\r?\\n|[:;.,`@]))|([uUbB]?[rR]?\'[^\\n\'\\\\]*(?:\\\\.[^\\n\'\\\\]*)*\'|[uUbB]?[rR]?"[^\\n"\\\\]*(?:\\\\.[^\\n"\\\\]*)*")|[a-zA-Z_]\\w*)'

Pointfloat = '(\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?'

PseudoExtras = '(\\\\\\r?\\n|#[^\\r\\n]*|([uUbB]?[rR]?\'\'\'|[uUbB]?[rR]?"""))'

PseudoToken = '[ \\f\\t]*((\\\\\\r?\\n|#[^\\r\\n]*|([uUbB]?[rR]?\'\'\'|[uUbB]?[rR]?"""))|((\\d+[jJ]|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)[jJ])|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)|(0[xX][\\da-fA-F]+[lL]?|0[bB][01]+[lL]?|(0[oO][0-7]+)|(0[0-7]*)[lL]?|[1-9]\\d*[lL]?))|((\\*\\*=?|>>=?|<<=?|<>|!=|//=?|[+\\-*/%&|^=<>]=?|~)|[][(){}]|(\\r?\\n|[:;.,`@]))|([uUbB]?[rR]?\'[^\\n\'\\\\]*(?:\\\\.[^\\n\'\\\\]*)*(\'|\\\\\\r?\\n)|[uUbB]?[rR]?"[^\\n"\\\\]*(?:\\\\.[^\\n"\\\\]*)*("|\\\\\\r?\\n))|[a-zA-Z_]\\w*)'

RBRACE = 27

RIGHTSHIFT = 35

RIGHTSHIFTEQUAL = 46

RPAR = 8

RSQB = 10

SEMI = 13

SLASH = 17

SLASHEQUAL = 40

STAR = 16

STAREQUAL = 39

STRING = 3

Single = "[^'\\\\]*(?:\\\\.[^'\\\\]*)*'"

Single3 = "[^'\\\\]*(?:(?:\\\\.|'(?!''))[^'\\\\]*)*'''"

Special = '(\\r?\\n|[:;.,`@])'

String = '([uUbB]?[rR]?\'[^\\n\'\\\\]*(?:\\\\.[^\\n\'\\\\]*)*\'|[uUbB]?[rR]?"[^\\n"\\\\]*(?:\\\\.[^\\n"\\\\]*)*")'

TILDE = 32

Token = '[ \\f\\t]*(\\\\\\r?\\n[ \\f\\t]*)*(#[^\\r\\n]*)?(((\\d+[jJ]|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)[jJ])|((\\d+\\.\\d*|\\.\\d+)([eE][-+]?\\d+)?|\\d+[eE][-+]?\\d+)|(0[xX][\\da-fA-F]+[lL]?|0[bB][01]+[lL]?|(0[oO][0-7]+)|(0[0-7]*)[lL]?|[1-9]\\d*[lL]?))|((\\*\\*=?|>>=?|<<=?|<>|!=|//=?|[+\\-*/%&|^=<>]=?|~)|[][(){}]|(\\r?\\n|[:;.,`@]))|([uUbB]?[rR]?\'[^\\n\'\\\\]*(?:\\\\.[^\\n\'\\\\]*)*\'|[uUbB]?[rR]?"[^\\n"\\\\]*(?:\\\\.[^\\n"\\\\]*)*")|[a-zA-Z_]\\w*)'

Triple = '([uUbB]?[rR]?\'\'\'|[uUbB]?[rR]?""")'

VBAR = 18

VBAREQUAL = 43

Whitespace = '[ \\f\\t]*'

t = 'BR"'

tabsize = 8

class StopTokenizing(_Mock):
  pass


class TokenError(_Mock):
  pass


class Untokenizer(_Mock):
  pass


