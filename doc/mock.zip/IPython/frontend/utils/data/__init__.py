from __future__ import print_function
from _mock import _Mock




chop = _Mock()

flatten = _Mock()

uniq_stable = _Mock()





