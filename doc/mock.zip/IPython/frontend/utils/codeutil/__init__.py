from __future__ import print_function
from _mock import _Mock




code_ctor = _Mock()

copy_reg = _Mock()

reduce_code = _Mock()

sys = _Mock()

types = _Mock()





