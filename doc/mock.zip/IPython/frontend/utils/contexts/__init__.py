from __future__ import print_function
from _mock import _Mock








class preserve_keys(_Mock):
  pass


