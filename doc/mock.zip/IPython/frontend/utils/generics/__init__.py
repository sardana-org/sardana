from __future__ import print_function
from _mock import _Mock




complete_object = _Mock()

generic = _Mock()

inspect_object = _Mock()



class TryNext(_Mock):
  pass


