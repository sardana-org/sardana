from __future__ import print_function
from _mock import _Mock

_rl = __import__('IPython.utils.rlineimpl', fromlist=['rlineimpl'])


add_history = _Mock()

clear_history = _Mock()

get_begidx = _Mock()

get_completer = _Mock()

get_completer_delims = _Mock()

get_completion_type = _Mock()

get_current_history_length = _Mock()

get_endidx = _Mock()

get_history_item = _Mock()

get_history_length = _Mock()

get_line_buffer = _Mock()

insert_text = _Mock()

parse_and_bind = _Mock()

read_history_file = _Mock()

read_init_file = _Mock()

redisplay = _Mock()

remove_history_item = _Mock()

replace_history_item = _Mock()

set_completer = _Mock()

set_completer_delims = _Mock()

set_completion_display_matches_hook = _Mock()

set_history_length = _Mock()

set_pre_input_hook = _Mock()

set_startup_hook = _Mock()

sys = _Mock()

warnings = _Mock()

write_history_file = _Mock()

have_readline = _Mock()

uses_libedit = _Mock()



