from __future__ import print_function
from _mock import _Mock




_sentinel = _Mock()

collections = _Mock()

gethashfile = _Mock()

glob = _Mock()

main = _Mock()

os = _Mock()

pickle = _Mock()

stat = _Mock()

stress = _Mock()

test = _Mock()

time = _Mock()



class Path(_Mock):
  pass


class PickleShareDB(_Mock):
  pass
  _abc_negative_cache_version = 56

class PickleShareLink(_Mock):
  pass


