from __future__ import print_function
from _mock import _Mock

codeutil = __import__('IPython.frontend.utils.codeutil', fromlist=['codeutil'])
py3compat = __import__('IPython.frontend.utils.py3compat', fromlist=['py3compat'])


CannedBuffer = _Mock()

_import_mapping = _Mock()

_logger = _Mock()

_original_can_map = _Mock()

_original_uncan_map = _Mock()

_uncan_dependent_hook = _Mock()

can = _Mock()

can_class = _Mock()

can_dependent = _Mock()

can_dict = _Mock()

can_map = _Mock()

can_sequence = _Mock()

class_type = _Mock()

copy = _Mock()

import_item = _Mock()

istype = _Mock()

logging = _Mock()

numpy = _Mock()

pickle = _Mock()

sequence_types = _Mock()

sys = _Mock()

uncan = _Mock()

uncan_dict = _Mock()

uncan_map = _Mock()

uncan_sequence = _Mock()



class Application(_Mock):
  pass


class CannedArray(_Mock):
  pass


class CannedBytes(_Mock):
  pass


class CannedClass(_Mock):
  pass


class CannedFunction(_Mock):
  pass


class CannedObject(_Mock):
  pass


class ClassType(_Mock):
  pass


class FunctionType(_Mock):
  pass


class Reference(_Mock):
  pass


