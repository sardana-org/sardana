from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


ClassTypes = _Mock()

NoDefaultSpecified = _Mock()

SequenceTypes = _Mock()

Undefined = _Mock()

add_article = _Mock()

class_of = _Mock()

getmembers = _Mock()

import_item = _Mock()

inspect = _Mock()

is_trait = _Mock()

parse_notifier_name = _Mock()

re = _Mock()

repr_type = _Mock()

sys = _Mock()

types = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Bytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class CComplex(_Mock):
  pass
  info_text = 'a complex number'

class CFloat(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class CInt(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

class CLong(_Mock):
  pass
  info_text = 'a long'

class CRegExp(_Mock):
  pass
  info_text = 'a regular expression'

class CUnicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class ClassBasedTraitType(_Mock):
  pass
  info_text = 'any value'

class ClassType(_Mock):
  pass


class Complex(_Mock):
  pass
  info_text = 'a complex number'

class Container(_Mock):
  pass
  info_text = 'any value'

class DefaultValueGenerator(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class Enum(_Mock):
  pass
  info_text = 'any value'

class Float(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class FunctionType(_Mock):
  pass


class HasTraits(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class InstanceType(_Mock):
  pass


class Int(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class List(_Mock):
  pass
  info_text = 'any value'

class Long(_Mock):
  pass
  info_text = 'a long'

class MetaHasTraits(_Mock):
  pass


class ObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class Set(_Mock):
  pass
  info_text = 'any value'

class TCPAddress(_Mock):
  pass
  info_text = 'an (ip, port) tuple'

class This(_Mock):
  pass
  info_text = 'an instance of the same type as the receiver or None'

class TraitError(_Mock):
  pass


class TraitType(_Mock):
  pass
  info_text = 'any value'

class Tuple(_Mock):
  pass
  info_text = 'any value'

class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class _SimpleTest(_Mock):
  pass


