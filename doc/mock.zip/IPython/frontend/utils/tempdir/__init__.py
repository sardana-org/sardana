from __future__ import print_function
from _mock import _Mock




_os = _Mock()

mkdtemp = _Mock()

template = 'tmp'

class NamedFileInTemporaryDirectory(_Mock):
  pass


class TemporaryDirectory(_Mock):
  pass


class TemporaryWorkingDirectory(_Mock):
  pass


