from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


error = _Mock()

fatal = _Mock()

info = _Mock()

print_function = _Mock()

sys = _Mock()

warn = _Mock()





