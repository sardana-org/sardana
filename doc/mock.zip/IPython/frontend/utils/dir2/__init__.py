from __future__ import print_function
from _mock import _Mock




dir2 = _Mock()

get_class_members = _Mock()





