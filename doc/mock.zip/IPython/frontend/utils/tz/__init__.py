from __future__ import print_function
from _mock import _Mock




UTC = _Mock()

ZERO = _Mock()

utc_aware = _Mock()

utcfromtimestamp = _Mock()

utcnow = _Mock()



class datetime(_Mock):
  pass


class timedelta(_Mock):
  pass


class tzUTC(_Mock):
  pass


class tzinfo(_Mock):
  pass


