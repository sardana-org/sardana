from __future__ import print_function
from _mock import _Mock




MethodType = _Mock()

_modify_str_or_docstring = _Mock()

_name_re = _Mock()

bytes_to_str = _Mock()

cast_bytes = _Mock()

cast_bytes_py2 = _Mock()

cast_unicode = _Mock()

decode = _Mock()

doctest_refactor_print = _Mock()

encode = _Mock()

execfile = _Mock()

functools = _Mock()

input = _Mock()

isidentifier = _Mock()

no_code = _Mock()

orig_open = _Mock()

re = _Mock()

safe_unicode = _Mock()

str_to_bytes = _Mock()

str_to_unicode = _Mock()

string_types = _Mock()

sys = _Mock()

types = _Mock()

u_format = _Mock()

unicode_to_str = _Mock()

DEFAULT_ENCODING = 'UTF-8'

PY3 = _Mock()

builtin_mod_name = '__builtin__'

class open(_Mock):
  pass


