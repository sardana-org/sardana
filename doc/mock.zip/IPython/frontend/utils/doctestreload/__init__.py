from __future__ import print_function
from _mock import _Mock




dhook_wrap = _Mock()

doctest_reload = _Mock()

sys = _Mock()





