from __future__ import print_function
from _mock import _Mock




_get_normal_name = _Mock()

_list_readline = _Mock()

absolute_import = _Mock()

cache_from_source = _Mock()

cookie_comment_re = _Mock()

cookie_re = _Mock()

detect_encoding = _Mock()

io = _Mock()

lookup = _Mock()

open = _Mock()

os = _Mock()

re = _Mock()

read_py_file = _Mock()

read_py_url = _Mock()

source_from_cache = _Mock()

source_to_unicode = _Mock()

strip_encoding_cookie = _Mock()

BOM_UTF8 = '\xef\xbb\xbf'

class BytesIO(_Mock):
  pass


class TextIOWrapper(_Mock):
  pass


