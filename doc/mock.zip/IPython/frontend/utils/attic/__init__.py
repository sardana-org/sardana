from __future__ import print_function
from _mock import _Mock




all_belong = _Mock()

belong = _Mock()

import_fail_info = _Mock()

map_method = _Mock()

mutex_opts = _Mock()

popkey = _Mock()

sys = _Mock()

warn = _Mock()

warnings = _Mock()

with_obj = _Mock()

wrap_deprecated = _Mock()



class EvalDict(_Mock):
  pass


class EvalString(_Mock):
  pass


class NotGiven(_Mock):
  pass


