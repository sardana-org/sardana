from __future__ import print_function
from _mock import _Mock

pexpect = __import__('IPython.external.pexpect', fromlist=['pexpect'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_find_cmd = _Mock()

arg_split = _Mock()

getoutput = _Mock()

print_function = _Mock()

sp = _Mock()

sys = _Mock()

system = _Mock()

DEFAULT_ENCODING = 'UTF-8'

class ProcessHandler(_Mock):
  pass
  read_timeout = 0.05
  terminate_timeout = 0.2

