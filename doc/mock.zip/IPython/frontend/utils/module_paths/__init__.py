from __future__ import print_function
from _mock import _Mock




find_mod = _Mock()

find_module = _Mock()

get_init = _Mock()

imp = _Mock()

os = _Mock()

print_function = _Mock()





