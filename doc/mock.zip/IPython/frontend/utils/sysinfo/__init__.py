from __future__ import print_function
from _mock import _Mock

_sysinfo = __import__('IPython.utils._sysinfo', fromlist=['_sysinfo'])
encoding = __import__('IPython.utils.encoding', fromlist=['encoding'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
release = __import__('IPython.core.release', fromlist=['release'])


_num_cpus_darwin = _Mock()

_num_cpus_unix = _Mock()

_num_cpus_windows = _Mock()

num_cpus = _Mock()

os = _Mock()

pkg_commit_hash = _Mock()

pkg_info = _Mock()

platform = _Mock()

pprint = _Mock()

subprocess = _Mock()

sys = _Mock()

sys_info = _Mock()





