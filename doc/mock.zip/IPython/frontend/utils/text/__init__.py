from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_chunks = _Mock()

_find_optimal = _Mock()

_get_or_default = _Mock()

columnize = _Mock()

compute_item_matrix = _Mock()

dedent = _Mock()

format_screen = _Mock()

indent = _Mock()

ini_spaces_re = _Mock()

list_strings = _Mock()

long_substr = _Mock()

marquee = _Mock()

num_ini_spaces = _Mock()

os = _Mock()

re = _Mock()

skip_doctest = _Mock()

skip_doctest_py3 = _Mock()

strip_email_quotes = _Mock()

textwrap = _Mock()

wrap_paragraphs = _Mock()



class DollarFormatter(_Mock):
  pass
  skip_doctest = False

class EvalFormatter(_Mock):
  pass


class Formatter(_Mock):
  pass


class FullEvalFormatter(_Mock):
  pass
  skip_doctest = False

class LSString(_Mock):
  pass


class SList(_Mock):
  pass


class path(_Mock):
  pass


