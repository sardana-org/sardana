from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


arg_split = _Mock()

get_output_error_code = _Mock()

getoutput = _Mock()

getoutputerror = _Mock()

process_handler = _Mock()

read_no_interrupt = _Mock()

shlex = _Mock()

subprocess = _Mock()

sys = _Mock()





