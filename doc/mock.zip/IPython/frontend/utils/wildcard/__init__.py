from __future__ import print_function
from _mock import _Mock




create_typestr2type_dicts = _Mock()

dict_dir = _Mock()

dir2 = _Mock()

filter_ns = _Mock()

is_type = _Mock()

list_namespace = _Mock()

re = _Mock()

show_hidden = _Mock()

type2typestr = _Mock()

types = _Mock()

typestr2type = _Mock()





