from __future__ import print_function
from _mock import _Mock




_find_cmd = _Mock()

abbrev_cwd = _Mock()

arg_split = _Mock()

find_cmd = _Mock()

get_output_error_code = _Mock()

getoutput = _Mock()

getoutputerror = _Mock()

is_cmd_found = _Mock()

os = _Mock()

print_function = _Mock()

pycmd2argv = _Mock()

shlex = _Mock()

sys = _Mock()

system = _Mock()



class FindCmdError(_Mock):
  pass


