from __future__ import print_function
from _mock import _Mock




check_for_zmq = _Mock()

check_version = _Mock()

patch_pyzmq = _Mock()





