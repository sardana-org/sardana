from __future__ import print_function
from _mock import _Mock

IPython = __import__('IPython', fromlist=['IPython'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_get_long_path_name = _Mock()

_writable_dir = _Mock()

check_for_old_config = _Mock()

errno = _Mock()

expand_path = _Mock()

filefind = _Mock()

filehash = _Mock()

get_home_dir = _Mock()

get_ipython_cache_dir = _Mock()

get_ipython_dir = _Mock()

get_ipython_module_path = _Mock()

get_ipython_package_dir = _Mock()

get_long_path_name = _Mock()

get_py_filename = _Mock()

get_security_file = _Mock()

get_xdg_cache_dir = _Mock()

get_xdg_dir = _Mock()

glob = _Mock()

import_item = _Mock()

link = _Mock()

link_or_copy = _Mock()

locate_profile = _Mock()

md5 = _Mock()

old_config_md5 = _Mock()

os = _Mock()

random = _Mock()

shellglob = _Mock()

shutil = _Mock()

skip_doctest = _Mock()

sys = _Mock()

system = _Mock()

target_outdated = _Mock()

target_update = _Mock()

tempfile = _Mock()

unescape_glob = _Mock()

unquote_filename = _Mock()

warnings = _Mock()

ENOLINK = 1998

fs_encoding = 'UTF-8'

class HomeDirError(_Mock):
  pass


