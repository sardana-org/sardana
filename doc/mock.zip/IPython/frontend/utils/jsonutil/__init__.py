from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


ISO8601_PAT = _Mock()

date_default = _Mock()

encode_images = _Mock()

encodebytes = _Mock()

extract_dates = _Mock()

json_clean = _Mock()

math = _Mock()

re = _Mock()

rekey = _Mock()

squash_dates = _Mock()

types = _Mock()

DEFAULT_ENCODING = 'UTF-8'

ISO8601 = '%Y-%m-%dT%H:%M:%S.%f'

JPEG = '\xff\xd8'

JPEG64 = '/9'

PNG = '\x89PNG\r\n\x1a\n'

PNG64 = 'iVBORw0KG'

next_attr_name = 'next'

class datetime(_Mock):
  pass


