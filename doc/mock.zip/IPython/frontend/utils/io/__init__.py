from __future__ import print_function
from _mock import _Mock




ask_yes_no = _Mock()

devnull = _Mock()

os = _Mock()

print_function = _Mock()

raw_print = _Mock()

raw_print_err = _Mock()

rprint = _Mock()

rprinte = _Mock()

stderr = _Mock()

stdin = _Mock()

stdout = _Mock()

sys = _Mock()

temp_pyfile = _Mock()

tempfile = _Mock()



class CapturedIO(_Mock):
  pass


class IOStream(_Mock):
  pass


class IOTerm(_Mock):
  pass


class StringIO(_Mock):
  pass


class Tee(_Mock):
  pass


class capture_output(_Mock):
  pass
  stderr = True
  stdout = True

