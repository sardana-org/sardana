from __future__ import print_function
from _mock import _Mock

PyColorize = __import__('IPython.frontend.utils.PyColorize', fromlist=['PyColorize'])
_process_common = __import__('IPython.frontend.utils._process_common', fromlist=['_process_common'])
_process_posix = __import__('IPython.frontend.utils._process_posix', fromlist=['_process_posix'])
_sysinfo = __import__('IPython.frontend.utils._sysinfo', fromlist=['_sysinfo'])
_tokenize_py2 = __import__('IPython.frontend.utils._tokenize_py2', fromlist=['_tokenize_py2'])
attic = __import__('IPython.frontend.utils.attic', fromlist=['attic'])
codeutil = __import__('IPython.frontend.utils.codeutil', fromlist=['codeutil'])
coloransi = __import__('IPython.frontend.utils.coloransi', fromlist=['coloransi'])
contexts = __import__('IPython.frontend.utils.contexts', fromlist=['contexts'])
daemonize = __import__('IPython.frontend.utils.daemonize', fromlist=['daemonize'])
data = __import__('IPython.frontend.utils.data', fromlist=['data'])
decorators = __import__('IPython.frontend.utils.decorators', fromlist=['decorators'])
dir2 = __import__('IPython.frontend.utils.dir2', fromlist=['dir2'])
doctestreload = __import__('IPython.frontend.utils.doctestreload', fromlist=['doctestreload'])
encoding = __import__('IPython.frontend.utils.encoding', fromlist=['encoding'])
frame = __import__('IPython.frontend.utils.frame', fromlist=['frame'])
generics = __import__('IPython.frontend.utils.generics', fromlist=['generics'])
importstring = __import__('IPython.frontend.utils.importstring', fromlist=['importstring'])
io = __import__('IPython.frontend.utils.io', fromlist=['io'])
ipstruct = __import__('IPython.frontend.utils.ipstruct', fromlist=['ipstruct'])
jsonutil = __import__('IPython.frontend.utils.jsonutil', fromlist=['jsonutil'])
localinterfaces = __import__('IPython.frontend.utils.localinterfaces', fromlist=['localinterfaces'])
module_paths = __import__('IPython.frontend.utils.module_paths', fromlist=['module_paths'])
nested_context = __import__('IPython.frontend.utils.nested_context', fromlist=['nested_context'])
openpy = __import__('IPython.frontend.utils.openpy', fromlist=['openpy'])
path = __import__('IPython.frontend.utils.path', fromlist=['path'])
pickleshare = __import__('IPython.frontend.utils.pickleshare', fromlist=['pickleshare'])
pickleutil = __import__('IPython.frontend.utils.pickleutil', fromlist=['pickleutil'])
process = __import__('IPython.frontend.utils.process', fromlist=['process'])
py3compat = __import__('IPython.frontend.utils.py3compat', fromlist=['py3compat'])
rlineimpl = __import__('IPython.frontend.utils.rlineimpl', fromlist=['rlineimpl'])
strdispatch = __import__('IPython.frontend.utils.strdispatch', fromlist=['strdispatch'])
submodule = __import__('IPython.frontend.utils.submodule', fromlist=['submodule'])
sysinfo = __import__('IPython.frontend.utils.sysinfo', fromlist=['sysinfo'])
syspathcontext = __import__('IPython.frontend.utils.syspathcontext', fromlist=['syspathcontext'])
tempdir = __import__('IPython.frontend.utils.tempdir', fromlist=['tempdir'])
terminal = __import__('IPython.frontend.utils.terminal', fromlist=['terminal'])
tests = __import__('IPython.frontend.utils.tests', fromlist=['tests'])
text = __import__('IPython.frontend.utils.text', fromlist=['text'])
timing = __import__('IPython.frontend.utils.timing', fromlist=['timing'])
tokenize2 = __import__('IPython.frontend.utils.tokenize2', fromlist=['tokenize2'])
traitlets = __import__('IPython.frontend.utils.traitlets', fromlist=['traitlets'])
tz = __import__('IPython.frontend.utils.tz', fromlist=['tz'])
ulinecache = __import__('IPython.frontend.utils.ulinecache', fromlist=['ulinecache'])
version = __import__('IPython.frontend.utils.version', fromlist=['version'])
warn = __import__('IPython.frontend.utils.warn', fromlist=['warn'])
wildcard = __import__('IPython.frontend.utils.wildcard', fromlist=['wildcard'])
zmqrelated = __import__('IPython.frontend.utils.zmqrelated', fromlist=['zmqrelated'])








