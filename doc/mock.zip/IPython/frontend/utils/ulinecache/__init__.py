from __future__ import print_function
from _mock import _Mock

openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


functools = _Mock()

getline = _Mock()

getlines = _Mock()

linecache = _Mock()

sys = _Mock()





