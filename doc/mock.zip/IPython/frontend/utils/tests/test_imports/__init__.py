from __future__ import print_function
from _mock import _Mock




test_import_PyColorize = _Mock()

test_import_coloransi = _Mock()

test_import_generics = _Mock()

test_import_ipstruct = _Mock()

test_import_rlineimpl = _Mock()

test_import_strdispatch = _Mock()

test_import_wildcard = _Mock()





