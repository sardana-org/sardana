from __future__ import print_function
from _mock import _Mock

mp = __import__('IPython.utils.module_paths', fromlist=['module_paths'])


abspath = _Mock()

env = _Mock()

join = _Mock()

make_empty_file = _Mock()

make_tempfile = _Mock()

old_syspath = _Mock()

os = _Mock()

setup = _Mock()

shutil = _Mock()

split = _Mock()

sys = _Mock()

teardown = _Mock()

tempfile = _Mock()

test_find_mod_1 = _Mock()

test_find_mod_2 = _Mock()

test_find_mod_3 = _Mock()

test_find_mod_4 = _Mock()

test_find_mod_5 = _Mock()

test_find_module_1 = _Mock()

test_find_module_2 = _Mock()

test_find_module_3 = _Mock()

test_find_module_4 = _Mock()

test_find_module_5 = _Mock()

test_get_init_1 = _Mock()

test_get_init_2 = _Mock()

test_get_init_3 = _Mock()

test_get_init_4 = _Mock()

with_statement = _Mock()

TEST_FILE_PATH = '/usr/lib/python2.7/site-packages/IPython/utils/tests'

TMP_TEST_DIR = '/tmp/tmpxNtlQS'



