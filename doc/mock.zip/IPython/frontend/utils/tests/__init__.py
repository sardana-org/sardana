from __future__ import print_function
from _mock import _Mock

test_imports = __import__('IPython.frontend.utils.tests.test_imports', fromlist=['test_imports'])
test_module_paths = __import__('IPython.frontend.utils.tests.test_module_paths', fromlist=['test_module_paths'])
test_tempdir = __import__('IPython.frontend.utils.tests.test_tempdir', fromlist=['test_tempdir'])
test_wildcard = __import__('IPython.frontend.utils.tests.test_wildcard', fromlist=['test_wildcard'])








