from __future__ import print_function
from _mock import _Mock

wildcard = __import__('IPython.utils.wildcard', fromlist=['wildcard'])


l = _Mock()

o = _Mock()

p = _Mock()

q = _Mock()

root = _Mock()

unittest = _Mock()

x = 'abbot'

y = 'koppel'

class Tests(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class obj_t(_Mock):
  pass


