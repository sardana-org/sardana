from __future__ import print_function
from _mock import _Mock




os = _Mock()

test_named_file_in_temporary_directory = _Mock()

test_temporary_working_directory = _Mock()



class NamedFileInTemporaryDirectory(_Mock):
  pass


class TemporaryWorkingDirectory(_Mock):
  pass


