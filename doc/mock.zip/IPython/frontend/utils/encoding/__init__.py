from __future__ import print_function
from _mock import _Mock




get_stream_enc = _Mock()

getdefaultencoding = _Mock()

locale = _Mock()

sys = _Mock()

DEFAULT_ENCODING = 'UTF-8'



