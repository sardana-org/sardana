from __future__ import print_function
from _mock import _Mock




_set_term_title = _Mock()

_set_term_title_xterm = _Mock()

_term_clear = _Mock()

freeze_term_title = _Mock()

get_terminal_size = _Mock()

os = _Mock()

set_term_title = _Mock()

struct = _Mock()

sys = _Mock()

term_clear = _Mock()

toggle_set_term_title = _Mock()

warnings = _Mock()

TERM = 'xterm'

ignore_termtitle = _Mock()



