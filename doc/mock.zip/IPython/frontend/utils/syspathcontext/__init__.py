from __future__ import print_function
from _mock import _Mock




sys = _Mock()



class appended_to_syspath(_Mock):
  pass


class prepended_to_syspath(_Mock):
  pass


