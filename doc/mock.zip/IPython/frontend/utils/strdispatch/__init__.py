from __future__ import print_function
from _mock import _Mock




re = _Mock()



class CommandChainDispatcher(_Mock):
  pass


class StrDispatch(_Mock):
  pass


