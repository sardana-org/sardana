from __future__ import print_function
from _mock import _Mock




daemonize = _Mock()

errno = _Mock()

os = _Mock()





