from __future__ import print_function
from _mock import _Mock

error = __import__('IPython.parallel.error', fromlist=['error'])
util = __import__('IPython.parallel.util', fromlist=['util'])


MET = _Mock()

cast_bytes = _Mock()

connect_logger = _Mock()

decorator = _Mock()

ioloop = _Mock()

launch_scheduler = _Mock()

leastload = _Mock()

local_logger = _Mock()

logged = _Mock()

logging = _Mock()

lru = _Mock()

numpy = _Mock()

plainrandom = _Mock()

randint = _Mock()

random = _Mock()

sys = _Mock()

time = _Mock()

twobin = _Mock()

weighted = _Mock()

zmq = _Mock()

zmqstream = _Mock()



class Application(_Mock):
  pass


class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class Config(_Mock):
  pass


class Dependency(_Mock):
  pass
  all = True
  failure = True
  success = True

class Dict(_Mock):
  pass
  info_text = 'any value'

class Enum(_Mock):
  pass
  info_text = 'any value'

class FunctionType(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class Job(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class SessionFactory(_Mock):
  pass


class Set(_Mock):
  pass
  info_text = 'any value'

class TaskScheduler(_Mock):
  pass


class datetime(_Mock):
  pass


class deque(_Mock):
  pass


