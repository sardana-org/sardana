from __future__ import print_function
from _mock import _Mock




_adapt_bufs = _Mock()

_adapt_dict = _Mock()

_convert_bufs = _Mock()

_convert_dict = _Mock()

date_default = _Mock()

extract_dates = _Mock()

ioloop = _Mock()

json = _Mock()

null_operators = _Mock()

operators = _Mock()

os = _Mock()

pickle = _Mock()

sqlite3 = _Mock()

squash_dates = _Mock()



class BaseDB(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Instance(_Mock):
  pass
  info_text = 'any value'

class List(_Mock):
  pass
  info_text = 'any value'

class SQLiteDB(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class datetime(_Mock):
  pass


