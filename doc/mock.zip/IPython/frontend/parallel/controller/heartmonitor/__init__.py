from __future__ import print_function
from _mock import _Mock




ioloop = _Mock()

log_errors = _Mock()

print_function = _Mock()

str_to_bytes = _Mock()

time = _Mock()

uuid = _Mock()

zmq = _Mock()

zmqstream = _Mock()



class CFloat(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Dict(_Mock):
  pass
  info_text = 'any value'

class Heart(_Mock):
  pass


class HeartMonitor(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class LoggingConfigurable(_Mock):
  pass


class Set(_Mock):
  pass
  info_text = 'any value'

class ThreadDevice(_Mock):
  pass


class ThreadMonitoredQueue(_Mock):
  pass
  _in_prefix = ''
  _out_prefix = ''

