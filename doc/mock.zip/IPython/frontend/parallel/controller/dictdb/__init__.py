from __future__ import print_function
from _mock import _Mock




NODATA = _Mock()

copy = _Mock()

filters = _Mock()



class BaseDB(_Mock):
  pass


class CompositeFilter(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class DictDB(_Mock):
  pass


class Float(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class LoggingConfigurable(_Mock):
  pass


class NoDB(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class datetime(_Mock):
  pass


