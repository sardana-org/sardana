from __future__ import print_function
from _mock import _Mock

dependency = __import__('IPython.frontend.parallel.controller.dependency', fromlist=['dependency'])
dictdb = __import__('IPython.frontend.parallel.controller.dictdb', fromlist=['dictdb'])
heartmonitor = __import__('IPython.frontend.parallel.controller.heartmonitor', fromlist=['heartmonitor'])
hub = __import__('IPython.frontend.parallel.controller.hub', fromlist=['hub'])
mongodb = __import__('IPython.frontend.parallel.controller.mongodb', fromlist=['mongodb'])
scheduler = __import__('IPython.frontend.parallel.controller.scheduler', fromlist=['scheduler'])
sqlitedb = __import__('IPython.frontend.parallel.controller.sqlitedb', fromlist=['sqlitedb'])








