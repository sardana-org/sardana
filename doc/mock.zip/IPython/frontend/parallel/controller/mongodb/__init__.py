from __future__ import print_function
from _mock import _Mock








class BaseDB(_Mock):
  pass


class Binary(_Mock):
  pass


class Connection(_Mock):
  pass
  HOST = 'localhost'
  PORT = 27017
  _MongoClient__max_bson_size = 4194304

class Dict(_Mock):
  pass
  info_text = 'any value'

class Instance(_Mock):
  pass
  info_text = 'any value'

class List(_Mock):
  pass
  info_text = 'any value'

class MongoDB(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

