from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_require = _Mock()

can = _Mock()

interactive = _Mock()

require = _Mock()

uncan = _Mock()



class AsyncResult(_Mock):
  pass
  _single_result = False

class Dependency(_Mock):
  pass
  all = True
  failure = True
  success = True

class ModuleType(_Mock):
  pass


class UnmetDependency(_Mock):
  pass


class depend(_Mock):
  pass


class dependent(_Mock):
  pass


