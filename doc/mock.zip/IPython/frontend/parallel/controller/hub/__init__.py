from __future__ import print_function
from _mock import _Mock

error = __import__('IPython.parallel.error', fromlist=['error'])
util = __import__('IPython.parallel.util', fromlist=['util'])


_db_shortcuts = _Mock()

_passer = _Mock()

_printer = _Mock()

cast_bytes = _Mock()

empty_record = _Mock()

import_item = _Mock()

init_record = _Mock()

ioloop = _Mock()

json = _Mock()

os = _Mock()

print_function = _Mock()

sys = _Mock()

time = _Mock()

zmq = _Mock()

LOCALHOST = '127.0.0.1'

class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class Dict(_Mock):
  pass
  info_text = 'any value'

class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class EngineConnector(_Mock):
  pass


class HasTraits(_Mock):
  pass


class HeartMonitor(_Mock):
  pass


class Hub(_Mock):
  pass


class HubFactory(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class RegistrationFactory(_Mock):
  pass


class SessionFactory(_Mock):
  pass


class Set(_Mock):
  pass
  info_text = 'any value'

class Tuple(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class ZMQStream(_Mock):
  pass


class datetime(_Mock):
  pass


