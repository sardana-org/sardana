from __future__ import print_function
from _mock import _Mock

asyncresult = __import__('IPython.frontend.parallel.client.asyncresult', fromlist=['asyncresult'])
client = __import__('IPython.frontend.parallel.client.client', fromlist=['client'])
magics = __import__('IPython.frontend.parallel.client.magics', fromlist=['magics'])
map = __import__('IPython.frontend.parallel.client.map', fromlist=['map'])
remotefunction = __import__('IPython.frontend.parallel.client.remotefunction', fromlist=['remotefunction'])
view = __import__('IPython.frontend.parallel.client.view', fromlist=['view'])








