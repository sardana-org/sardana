from __future__ import print_function
from _mock import _Mock

Map = __import__('IPython.frontend.parallel.client.map', fromlist=['map'])


decorator = _Mock()

division = _Mock()

getname = _Mock()

parallel = _Mock()

remote = _Mock()

skip_doctest = _Mock()

sync_view_results = _Mock()

sys = _Mock()

warnings = _Mock()



class AsyncMapResult(_Mock):
  pass
  _single_result = False

class ParallelFunction(_Mock):
  pass
  _mapping = False

class RemoteFunction(_Mock):
  pass


