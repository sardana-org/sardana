from __future__ import print_function
from _mock import _Mock




arrayModules = _Mock()

dists = _Mock()

division = _Mock()

mappable = _Mock()

numpy = _Mock()

types = _Mock()

utils_flatten = _Mock()



class Map(_Mock):
  pass


class RoundRobinMap(_Mock):
  pass


class islice(_Mock):
  pass


