from __future__ import print_function
from _mock import _Mock

magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])


ast = _Mock()

exec_args = _Mock()

output_args = _Mock()

re = _Mock()

skip_doctest = _Mock()

NO_LAST_RESULT = '%pxresult recalls last %px result, which has not yet been used.'

class Magics(_Mock):
  pass
  registered = False

class ParallelMagics(_Mock):
  pass
  _autopx = False
  registered = True
  suffix = ''
  verbose = False

class UsageError(_Mock):
  pass


