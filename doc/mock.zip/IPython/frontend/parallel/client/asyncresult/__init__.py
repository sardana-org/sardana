from __future__ import print_function
from _mock import _Mock

error = __import__('IPython.parallel.error', fromlist=['error'])


_raw_text = _Mock()

_total_seconds = _Mock()

check_ready = _Mock()

clear_output = _Mock()

decorator = _Mock()

display = _Mock()

display_pretty = _Mock()

finished_tracker = _Mock()

print_function = _Mock()

sys = _Mock()

time = _Mock()



class AsyncHubResult(_Mock):
  pass
  _single_result = False

class AsyncMapResult(_Mock):
  pass
  _single_result = False

class AsyncResult(_Mock):
  pass
  _single_result = False

class MessageTracker(_Mock):
  pass


class datetime(_Mock):
  pass


