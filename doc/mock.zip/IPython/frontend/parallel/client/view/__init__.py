from __future__ import print_function
from _mock import _Mock

Map = __import__('IPython.frontend.parallel.client.map', fromlist=['map'])
util = __import__('IPython.parallel.util', fromlist=['util'])


contextmanager = _Mock()

decorator = _Mock()

getname = _Mock()

imp = _Mock()

parallel = _Mock()

remote = _Mock()

save_ids = _Mock()

skip_doctest = _Mock()

spin_after = _Mock()

sync_results = _Mock()

sys = _Mock()

warnings = _Mock()

zmq = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class AsyncMapResult(_Mock):
  pass
  _single_result = False

class AsyncResult(_Mock):
  pass
  _single_result = False

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CFloat(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Dependency(_Mock):
  pass
  all = True
  failure = True
  success = True

class Dict(_Mock):
  pass
  info_text = 'any value'

class DirectView(_Mock):
  pass
  skip_doctest = True

class HasTraits(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class List(_Mock):
  pass
  info_text = 'any value'

class LoadBalancedView(_Mock):
  pass
  skip_doctest = True

class ModuleType(_Mock):
  pass


class ParallelFunction(_Mock):
  pass
  _mapping = False

class Set(_Mock):
  pass
  info_text = 'any value'

class View(_Mock):
  pass
  skip_doctest = True

class dependent(_Mock):
  pass


