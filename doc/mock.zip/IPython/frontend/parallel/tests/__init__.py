from __future__ import print_function
from _mock import _Mock




add_engines = _Mock()

blackhole = _Mock()

get_ipython_dir = _Mock()

ipcontroller_cmd_argv = _Mock()

ipengine_cmd_argv = _Mock()

launchers = _Mock()

os = _Mock()

setup = _Mock()

teardown = _Mock()

tempfile = _Mock()

time = _Mock()

SIGKILL = 9

class Client(_Mock):
  pass
  _closed = False

class LocalProcessLauncher(_Mock):
  pass


class Popen(_Mock):
  pass


class ProcessStateError(_Mock):
  pass


class TestProcessLauncher(_Mock):
  pass


