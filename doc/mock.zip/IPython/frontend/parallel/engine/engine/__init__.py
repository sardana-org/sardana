from __future__ import print_function
from _mock import _Mock

tunnel = __import__('IPython.external.ssh.tunnel', fromlist=['tunnel'])


cast_bytes = _Mock()

disambiguate_url = _Mock()

getpass = _Mock()

ioloop = _Mock()

print_function = _Mock()

sys = _Mock()

time = _Mock()

zmq = _Mock()

zmqstream = _Mock()

LOCALHOST = '127.0.0.1'

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CBytes(_Mock):
  pass
  default_value = ''
  info_text = 'a string'

class Dict(_Mock):
  pass
  info_text = 'any value'

class EngineFactory(_Mock):
  pass
  _hb_last_monitored = 0.0
  _hb_last_pinged = 0.0
  _hb_missed_beats = 0

class Float(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class Heart(_Mock):
  pass


class IPKernelApp(_Mock):
  pass
  _in_init_profile_dir = False
  name = 'ipkernel'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class Kernel(_Mock):
  pass


class Message(_Mock):
  pass


class RegistrationFactory(_Mock):
  pass


class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

