from __future__ import print_function
from _mock import _Mock

apps = __import__('IPython.frontend.parallel.apps', fromlist=['apps'])
client = __import__('IPython.frontend.parallel.client', fromlist=['client'])
controller = __import__('IPython.frontend.parallel.controller', fromlist=['controller'])
engine = __import__('IPython.frontend.parallel.engine', fromlist=['engine'])
error = __import__('IPython.frontend.parallel.error', fromlist=['error'])
factory = __import__('IPython.frontend.parallel.factory', fromlist=['factory'])
scripts = __import__('IPython.frontend.parallel.scripts', fromlist=['scripts'])
tests = __import__('IPython.frontend.parallel.tests', fromlist=['tests'])
util = __import__('IPython.frontend.parallel.util', fromlist=['util'])


bind_kernel = _Mock()

check_for_zmq = _Mock()

collect_exceptions = _Mock()

interactive = _Mock()

os = _Mock()

parallel = _Mock()

print_function = _Mock()

remote = _Mock()

require = _Mock()

sys = _Mock()

traceback = _Mock()

unwrap_exception = _Mock()

warnings = _Mock()

wrap_exception = _Mock()

zmq = _Mock()

min_pyzmq = '2.1.11'

class AsyncHubResult(_Mock):
  pass
  _single_result = False

class AsyncMapResult(_Mock):
  pass
  _single_result = False

class AsyncResult(_Mock):
  pass
  _single_result = False

class Client(_Mock):
  pass
  _closed = False

class CompositeError(_Mock):
  pass
  tb_limit = 4

class Dependency(_Mock):
  pass
  all = True
  failure = True
  success = True

class DependencyTimeout(_Mock):
  pass


class DirectView(_Mock):
  pass
  skip_doctest = True

class IPythonError(_Mock):
  pass


class ImpossibleDependency(_Mock):
  pass


class InvalidDependency(_Mock):
  pass


class KernelError(_Mock):
  pass


class LoadBalancedView(_Mock):
  pass
  skip_doctest = True

class MultipleInstanceError(_Mock):
  pass


class NoEnginesRegistered(_Mock):
  pass


class ParallelFunction(_Mock):
  pass
  _mapping = False

class Reference(_Mock):
  pass


class RemoteError(_Mock):
  pass


class RemoteFunction(_Mock):
  pass


class TaskAborted(_Mock):
  pass


class TaskRejectError(_Mock):
  pass


class TaskTimeout(_Mock):
  pass


class TimeoutError(_Mock):
  pass


class UnmetDependency(_Mock):
  pass


class depend(_Mock):
  pass


class dependent(_Mock):
  pass


