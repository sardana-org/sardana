from __future__ import print_function
from _mock import _Mock




aliases = _Mock()

base_aliases = _Mock()

catch_config_error = _Mock()

launch_new_instance = _Mock()

os = _Mock()

sys = _Mock()

zmq = _Mock()

_description = 'Start an IPython logger for parallel computing.\n\nIPython controllers and engines (and your own processes) can broadcast log messages\nby registering a `zmq.log.handlers.PUBHandler` with the `logging` module. The\nlogger can be configured using command line options or using a cluster\ndirectory. Cluster directories contain config, log and security files and are\nusually located in your ipython directory and named as "profile_name".\nSee the `profile` and `profile-dir` options for details.\n'

class BaseParallelApplication(_Mock):
  pass
  _in_init_profile_dir = False

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Dict(_Mock):
  pass
  info_text = 'any value'

class IPLoggerApp(_Mock):
  pass
  _in_init_profile_dir = False
  description = 'Start an IPython logger for parallel computing.\n\nIPython controllers and engines (and your own processes) can broadcast log messages\nby registering a `zmq.log.handlers.PUBHandler` with the `logging` module. The\nlogger can be configured using command line options or using a cluster\ndirectory. Cluster directories contain config, log and security files and are\nusually located in your ipython directory and named as "profile_name".\nSee the `profile` and `profile-dir` options for details.\n'
  name = u'iplogger'

class LogWatcher(_Mock):
  pass


class ProfileDir(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

