from __future__ import print_function
from _mock import _Mock

release = __import__('IPython.core.release', fromlist=['release'])


base_aliases = _Mock()

base_flags = _Mock()

base_ip_aliases = _Mock()

base_ip_flags = _Mock()

catch_config_error = _Mock()

expand_path = _Mock()

logging = _Mock()

os = _Mock()

re = _Mock()

sys = _Mock()

with_statement = _Mock()

PIPE = -1

class BaseIPythonApplication(_Mock):
  pass
  _in_init_profile_dir = False

class BaseParallelApplication(_Mock):
  pass
  _in_init_profile_dir = False

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CrashHandler(_Mock):
  pass
  message_template = "Oops, {app_name} crashed. We do our best to make it stable, but...\n\nA crash report was automatically generated with the following information:\n  - A verbatim copy of the crash traceback.\n  - A copy of your input history during this session.\n  - Data on your current {app_name} configuration.\n\nIt was left in the file named:\n\t'{crash_report_fname}'\nIf you can email this file to the developers, the information in it will help\nthem in understanding and correcting the problem.\n\nYou can mail it to: {contact_name} at {contact_email}\nwith the subject '{app_name} Crash Report'.\n\nIf you want to do it now, the following command will work (under Unix):\nmail -s '{app_name} Crash Report' {contact_email} < {crash_report_fname}\n\nTo ensure accurate tracking of this issue, please file a report about it at:\n{bug_tracker}\n"
  section_sep = '\n\n***************************************************************************\n\n'

class Dict(_Mock):
  pass
  info_text = 'any value'

class Instance(_Mock):
  pass
  info_text = 'any value'

class LevelFormatter(_Mock):
  pass
  highlevel_format = ' %(levelname)s |'
  highlevel_limit = 30

class List(_Mock):
  pass
  info_text = 'any value'

class PIDFileError(_Mock):
  pass


class ParallelCrashHandler(_Mock):
  pass
  message_template = "Oops, {app_name} crashed. We do our best to make it stable, but...\n\nA crash report was automatically generated with the following information:\n  - A verbatim copy of the crash traceback.\n  - A copy of your input history during this session.\n  - Data on your current {app_name} configuration.\n\nIt was left in the file named:\n\t'{crash_report_fname}'\nIf you can email this file to the developers, the information in it will help\nthem in understanding and correcting the problem.\n\nYou can mail it to: {contact_name} at {contact_email}\nwith the subject '{app_name} Crash Report'.\n\nIf you want to do it now, the following command will work (under Unix):\nmail -s '{app_name} Crash Report' {contact_email} < {crash_report_fname}\n\nTo ensure accurate tracking of this issue, please file a report about it at:\n{bug_tracker}\n"
  section_sep = '\n\n***************************************************************************\n\n'

class Popen(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

