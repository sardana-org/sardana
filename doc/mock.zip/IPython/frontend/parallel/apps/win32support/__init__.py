from __future__ import print_function
from _mock import _Mock




forward_read_events = _Mock()

uuid = _Mock()

zmq = _Mock()



class ForwarderThread(_Mock):
  pass
  _Thread__initialized = False

class Thread(_Mock):
  pass
  _Thread__initialized = False

