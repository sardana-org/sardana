from __future__ import print_function
from _mock import _Mock




all_launchers = _Mock()

check_output = _Mock()

copy = _Mock()

find_cmd = _Mock()

find_job_cmd = _Mock()

forward_read_events = _Mock()

get_home_dir = _Mock()

htcondor_launchers = _Mock()

ioloop = _Mock()

ipcluster_cmd_argv = _Mock()

ipcontroller_cmd_argv = _Mock()

ipengine_cmd_argv = _Mock()

local_launchers = _Mock()

logging = _Mock()

lsf_launchers = _Mock()

mpi_launchers = _Mock()

os = _Mock()

pbs_launchers = _Mock()

pipes = _Mock()

sge_launchers = _Mock()

ssh_launchers = _Mock()

stat = _Mock()

sys = _Mock()

time = _Mock()

winhpc_launchers = _Mock()

DEFAULT_ENCODING = 'UTF-8'

PIPE = -1

SIGINT = 2

SIGKILL = 9

SIGTERM = 15

STDOUT = -2

WINDOWS = _Mock()

cmd = 'from IPython.parallel.apps.%s import launch_new_instance; launch_new_instance()'

class Any(_Mock):
  pass
  info_text = 'any value'

class Application(_Mock):
  pass


class BaseLauncher(_Mock):
  pass


class BatchClusterAppMixin(_Mock):
  pass


class BatchSystemLauncher(_Mock):
  pass


class CFloat(_Mock):
  pass
  default_value = 0.0
  info_text = 'a float'

class CRegExp(_Mock):
  pass
  info_text = 'a regular expression'

class ClusterAppMixin(_Mock):
  pass


class ControllerMixin(_Mock):
  pass


class DeprecatedMPILauncher(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class EngineMixin(_Mock):
  pass


class EvalFormatter(_Mock):
  pass


class FindCmdError(_Mock):
  pass


class HTCondorControllerLauncher(_Mock):
  pass


class HTCondorEngineSetLauncher(_Mock):
  pass


class HTCondorLauncher(_Mock):
  pass


class HasTraits(_Mock):
  pass


class IPClusterLauncher(_Mock):
  pass


class IPControllerJob(_Mock):
  pass


class IPControllerTask(_Mock):
  pass


class IPEngineSetJob(_Mock):
  pass


class IPEngineTask(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class LSFControllerLauncher(_Mock):
  pass


class LSFEngineSetLauncher(_Mock):
  pass


class LSFLauncher(_Mock):
  pass


class LauncherError(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class LocalControllerLauncher(_Mock):
  pass


class LocalEngineLauncher(_Mock):
  pass


class LocalEngineSetLauncher(_Mock):
  pass


class LocalProcessLauncher(_Mock):
  pass


class LoggingConfigurable(_Mock):
  pass


class MPIControllerLauncher(_Mock):
  pass


class MPIEngineSetLauncher(_Mock):
  pass


class MPIExecControllerLauncher(_Mock):
  pass


class MPIExecEngineSetLauncher(_Mock):
  pass


class MPIExecLauncher(_Mock):
  pass


class MPILauncher(_Mock):
  pass


class PBSControllerLauncher(_Mock):
  pass


class PBSEngineSetLauncher(_Mock):
  pass


class PBSLauncher(_Mock):
  pass


class Popen(_Mock):
  pass


class ProcessStateError(_Mock):
  pass


class SGEControllerLauncher(_Mock):
  pass


class SGEEngineSetLauncher(_Mock):
  pass


class SGELauncher(_Mock):
  pass


class SSHClusterLauncher(_Mock):
  pass


class SSHControllerLauncher(_Mock):
  pass


class SSHEngineLauncher(_Mock):
  pass


class SSHEngineSetLauncher(_Mock):
  pass


class SSHLauncher(_Mock):
  pass


class SSHProxyEngineSetLauncher(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class UnknownStatus(_Mock):
  pass


class WindowsHPCControllerLauncher(_Mock):
  pass


class WindowsHPCEngineSetLauncher(_Mock):
  pass


class WindowsHPCLauncher(_Mock):
  pass


