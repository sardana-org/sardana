from __future__ import print_function
from _mock import _Mock




ET = _Mock()

as_str = _Mock()

find_username = _Mock()

indent = _Mock()

os = _Mock()

re = _Mock()

uuid = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Configurable(_Mock):
  pass


class Enum(_Mock):
  pass
  info_text = 'any value'

class IPControllerJob(_Mock):
  pass


class IPControllerTask(_Mock):
  pass


class IPEngineSetJob(_Mock):
  pass


class IPEngineTask(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class List(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class WinHPCJob(_Mock):
  pass


class WinHPCTask(_Mock):
  pass


