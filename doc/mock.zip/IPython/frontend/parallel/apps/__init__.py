from __future__ import print_function
from _mock import _Mock

baseapp = __import__('IPython.frontend.parallel.apps.baseapp', fromlist=['baseapp'])
ipclusterapp = __import__('IPython.frontend.parallel.apps.ipclusterapp', fromlist=['ipclusterapp'])
ipcontrollerapp = __import__('IPython.frontend.parallel.apps.ipcontrollerapp', fromlist=['ipcontrollerapp'])
ipengineapp = __import__('IPython.frontend.parallel.apps.ipengineapp', fromlist=['ipengineapp'])
iploggerapp = __import__('IPython.frontend.parallel.apps.iploggerapp', fromlist=['iploggerapp'])
launcher = __import__('IPython.frontend.parallel.apps.launcher', fromlist=['launcher'])
logwatcher = __import__('IPython.frontend.parallel.apps.logwatcher', fromlist=['logwatcher'])
win32support = __import__('IPython.frontend.parallel.apps.win32support', fromlist=['win32support'])
winhpcjob = __import__('IPython.frontend.parallel.apps.winhpcjob', fromlist=['winhpcjob'])








