from __future__ import print_function
from _mock import _Mock




ioloop = _Mock()

logging = _Mock()

sys = _Mock()

zmq = _Mock()

zmqstream = _Mock()

LOCALHOST = '127.0.0.1'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Int(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

class List(_Mock):
  pass
  info_text = 'any value'

class LogWatcher(_Mock):
  pass


class LoggingConfigurable(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

