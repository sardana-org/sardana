from __future__ import print_function
from _mock import _Mock




collect_exceptions = _Mock()

print_function = _Mock()

sys = _Mock()

traceback = _Mock()

unwrap_exception = _Mock()

wrap_exception = _Mock()



class CompositeError(_Mock):
  pass
  tb_limit = 4

class DependencyTimeout(_Mock):
  pass


class IPythonError(_Mock):
  pass


class ImpossibleDependency(_Mock):
  pass


class InvalidDependency(_Mock):
  pass


class KernelError(_Mock):
  pass


class NoEnginesRegistered(_Mock):
  pass


class RemoteError(_Mock):
  pass


class TaskAborted(_Mock):
  pass


class TaskRejectError(_Mock):
  pass


class TaskTimeout(_Mock):
  pass


class TimeoutError(_Mock):
  pass


class UnmetDependency(_Mock):
  pass


