from __future__ import print_function
from _mock import _Mock




PUBLIC_IPS = _Mock()

_execute = _Mock()

_pull = _Mock()

_push = _Mock()

_random_ports = _Mock()

cPickle = _Mock()

connect_engine_logger = _Mock()

connect_logger = _Mock()

decorator = _Mock()

disambiguate_ip_address = _Mock()

disambiguate_url = _Mock()

generate_exec_key = _Mock()

handlers = _Mock()

integer_loglevel = _Mock()

interactive = _Mock()

is_url = _Mock()

local_logger = _Mock()

log_errors = _Mock()

logging = _Mock()

os = _Mock()

pack_apply_message = _Mock()

pickle = _Mock()

re = _Mock()

select_random_ports = _Mock()

serialize_object = _Mock()

set_hwm = _Mock()

signal = _Mock()

signal_children = _Mock()

socket = _Mock()

split_url = _Mock()

stat = _Mock()

sys = _Mock()

unpack_apply_message = _Mock()

unserialize_object = _Mock()

validate_url = _Mock()

validate_url_container = _Mock()

zmq = _Mock()

LOCALHOST = '127.0.0.1'

SIGABRT = 6

SIGINT = 2

SIGKILL = 9

SIGTERM = 15

class Application(_Mock):
  pass


class EnginePUBHandler(_Mock):
  pass


class Namespace(_Mock):
  pass


class ReverseDict(_Mock):
  pass


