from __future__ import print_function
from _mock import _Mock




logging = _Mock()

os = _Mock()

select_random_ports = _Mock()

zmq = _Mock()

LOCALHOST = '127.0.0.1'

class Configurable(_Mock):
  pass


class IOLoop(_Mock):
  pass
  ERROR = 24
  NONE = 0
  READ = 1
  WRITE = 4
  _EPOLLERR = 8
  _EPOLLET = 2147483648
  _EPOLLHUP = 16
  _EPOLLIN = 1
  _EPOLLONESHOT = 1073741824
  _EPOLLOUT = 4
  _EPOLLPRI = 2
  _EPOLLRDHUP = 8192

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class RegistrationFactory(_Mock):
  pass


class Session(_Mock):
  pass


class SessionFactory(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

