from __future__ import print_function
from _mock import _Mock

pexpect = __import__('IPython.external.pexpect', fromlist=['pexpect'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


main = _Mock()

optparse = _Mock()

os = _Mock()

pexpect_monkeypatch = _Mock()

print_function = _Mock()

sys = _Mock()

MAIN_USAGE = "\n%prog [options] file_to_run\n\nThis is an interface to the various interactive runners available in this\nmodule.  If you want to pass specific options to one of the runners, you need\nto first terminate the main options with a '--', and then provide the runner's\noptions.  For example:\n\nirunner.py --python -- --help\n\nwill pass --help to the python runner.  Similarly,\n\nirunner.py --ipython -- --interact script.ipy\n\nwill run the script.ipy file under the IPython runner, and then will start to\ninteract with IPython at the end of the script (instead of exiting).\n\nThe already implemented runners are listed below; adding one for a new program\nis a trivial task, see the source for examples.\n"

USAGE = '\nInteractive script runner, type: %s\n\nrunner [opts] script_name\n'

_ipython_cmd = 'ipython'

class IPythonRunner(_Mock):
  pass


class InteractiveRunner(_Mock):
  pass


class PythonRunner(_Mock):
  pass


class RunnerFactory(_Mock):
  pass


class SAGERunner(_Mock):
  pass


