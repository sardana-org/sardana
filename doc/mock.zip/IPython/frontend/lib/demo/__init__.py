from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])
openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])


marquee = _Mock()

os = _Mock()

print_function = _Mock()

re = _Mock()

re_mark = _Mock()

shlex = _Mock()

sys = _Mock()

unicode_literals = _Mock()



class ClearDemo(_Mock):
  pass


class ClearIPDemo(_Mock):
  pass


class ClearMixin(_Mock):
  pass


class Demo(_Mock):
  pass


class DemoError(_Mock):
  pass


class IPythonDemo(_Mock):
  pass


class IPythonLineDemo(_Mock):
  pass


class LineDemo(_Mock):
  pass


