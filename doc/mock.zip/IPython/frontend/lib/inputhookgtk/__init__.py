from __future__ import print_function
from _mock import _Mock




_main_quit = _Mock()

gobject = _Mock()

gtk = _Mock()

inputhook_gtk = _Mock()

sys = _Mock()





