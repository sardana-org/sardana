from __future__ import print_function
from _mock import _Mock




clock = _Mock()

inputhook_wx = _Mock()

inputhook_wx1 = _Mock()

inputhook_wx2 = _Mock()

inputhook_wx3 = _Mock()

signal = _Mock()

stdin_ready = _Mock()

sys = _Mock()

time = _Mock()

wx = _Mock()



class EventLoopRunner(_Mock):
  pass


class EventLoopTimer(_Mock):
  pass


