from __future__ import print_function
from _mock import _Mock




connect_qtconsole = _Mock()

find_connection_file = _Mock()

get_connection_file = _Mock()

get_connection_info = _Mock()

tunnel_to_kernel = _Mock()

warnings = _Mock()

write_connection_file = _Mock()





