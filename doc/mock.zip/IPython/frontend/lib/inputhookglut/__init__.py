from __future__ import print_function
from _mock import _Mock




clock = _Mock()

glut = _Mock()

glutMainLoopEvent = _Mock()

glut_close = _Mock()

glut_display = _Mock()

glut_idle = _Mock()

glut_int_handler = _Mock()

inputhook_glut = _Mock()

os = _Mock()

platform = _Mock()

select = _Mock()

signal = _Mock()

stdin_ready = _Mock()

sys = _Mock()

time = _Mock()

glut_display_mode = 18

glut_fps = 60



