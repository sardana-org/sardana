from __future__ import print_function
from _mock import _Mock




bytes_to_str = _Mock()

encodestring = _Mock()

find_cmd = _Mock()

genelatex = _Mock()

kpsewhich = _Mock()

latex_to_html = _Mock()

latex_to_png = _Mock()

latex_to_png_dvipng = _Mock()

latex_to_png_mpl = _Mock()

math_to_image = _Mock()

os = _Mock()

shutil = _Mock()

subprocess = _Mock()

tempfile = _Mock()

_data_uri_template_png = '<img src="data:image/png;base64,%s" alt=%s />'

class BytesIO(_Mock):
  pass


class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CUnicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class FindCmdError(_Mock):
  pass


class LaTeXTool(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class SingletonConfigurable(_Mock):
  pass


