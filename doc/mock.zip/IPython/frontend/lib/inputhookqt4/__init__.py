from __future__ import print_function
from _mock import _Mock




QtCore = _Mock()

QtGui = _Mock()

allow_CTRL_C = _Mock()

create_inputhook_qt4 = _Mock()

ignore_CTRL_C = _Mock()

os = _Mock()

sigint_timer = _Mock()

signal = _Mock()

stdin_ready = _Mock()

threading = _Mock()

got_kbdint = _Mock()

class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

