from __future__ import print_function
from _mock import _Mock

backgroundjobs = __import__('IPython.frontend.lib.backgroundjobs', fromlist=['backgroundjobs'])
clipboard = __import__('IPython.frontend.lib.clipboard', fromlist=['clipboard'])
deepreload = __import__('IPython.frontend.lib.deepreload', fromlist=['deepreload'])
demo = __import__('IPython.frontend.lib.demo', fromlist=['demo'])
display = __import__('IPython.frontend.lib.display', fromlist=['display'])
editorhooks = __import__('IPython.frontend.lib.editorhooks', fromlist=['editorhooks'])
guisupport = __import__('IPython.frontend.lib.guisupport', fromlist=['guisupport'])
inputhook = __import__('IPython.frontend.lib.inputhook', fromlist=['inputhook'])
inputhookglut = __import__('IPython.frontend.lib.inputhookglut', fromlist=['inputhookglut'])
inputhookgtk = __import__('IPython.frontend.lib.inputhookgtk', fromlist=['inputhookgtk'])
inputhookqt4 = __import__('IPython.frontend.lib.inputhookqt4', fromlist=['inputhookqt4'])
inputhookwx = __import__('IPython.frontend.lib.inputhookwx', fromlist=['inputhookwx'])
irunner = __import__('IPython.frontend.lib.irunner', fromlist=['irunner'])
kernel = __import__('IPython.frontend.lib.kernel', fromlist=['kernel'])
latextools = __import__('IPython.frontend.lib.latextools', fromlist=['latextools'])
pretty = __import__('IPython.frontend.lib.pretty', fromlist=['pretty'])
security = __import__('IPython.frontend.lib.security', fromlist=['security'])
tests = __import__('IPython.frontend.lib.tests', fromlist=['tests'])


passwd = _Mock()





