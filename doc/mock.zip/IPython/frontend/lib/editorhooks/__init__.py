from __future__ import print_function
from _mock import _Mock




crimson_editor = _Mock()

emacs = _Mock()

get_ipython = _Mock()

gnuclient = _Mock()

idle = _Mock()

install_editor = _Mock()

jed = _Mock()

kate = _Mock()

komodo = _Mock()

mate = _Mock()

notepadplusplus = _Mock()

os = _Mock()

pipes = _Mock()

scite = _Mock()

subprocess = _Mock()



class TryNext(_Mock):
  pass


