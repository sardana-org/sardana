from __future__ import print_function
from _mock import _Mock




MULTILINE_OUTPUTS = _Mock()

_pygment_highlight = _Mock()

get_lexer_by_name = _Mock()

highlight2html = _Mock()

highlight2latex = _Mock()

pygements_highlight = _Mock()



class HtmlFormatter(_Mock):
  pass
  name = 'HTML'
  unicodeoutput = True

class IPythonLexer(_Mock):
  pass
  _tmpname = 4
  flags = 8
  name = 'IPython'
  priority = 0

class LatexFormatter(_Mock):
  pass
  name = 'LaTeX'
  unicodeoutput = True

