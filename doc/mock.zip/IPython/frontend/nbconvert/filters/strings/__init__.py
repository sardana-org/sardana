from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


ElementTree = _Mock()

add_anchor = _Mock()

comment_lines = _Mock()

files_url_pattern = _Mock()

get_lines = _Mock()

html2text = _Mock()

ipython2python = _Mock()

os = _Mock()

posix_path = _Mock()

re = _Mock()

strip_dollars = _Mock()

strip_files_prefix = _Mock()

textwrap = _Mock()

wrap_text = _Mock()



class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

