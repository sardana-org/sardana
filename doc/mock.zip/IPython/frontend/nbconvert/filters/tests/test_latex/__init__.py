from __future__ import print_function
from _mock import _Mock




escape_latex = _Mock()

strip_math_space = _Mock()



class TestLatex(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestsBase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

