from __future__ import print_function
from _mock import _Mock

dec = __import__('IPython.testing.decorators', fromlist=['decorators'])


add_anchor = _Mock()

comment_lines = _Mock()

get_lines = _Mock()

html2text = _Mock()

ipython2python = _Mock()

os = _Mock()

posix_path = _Mock()

strip_dollars = _Mock()

strip_files_prefix = _Mock()

wrap_text = _Mock()



class TestStrings(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestsBase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

