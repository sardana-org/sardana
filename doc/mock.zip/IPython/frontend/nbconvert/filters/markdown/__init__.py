from __future__ import print_function
from _mock import _Mock




markdown2html = _Mock()

markdown2latex = _Mock()

markdown2rst = _Mock()

pandoc = _Mock()

print_function = _Mock()

subprocess = _Mock()

sys = _Mock()





