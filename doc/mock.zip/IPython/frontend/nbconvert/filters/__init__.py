from __future__ import print_function
from _mock import _Mock

ansi = __import__('IPython.frontend.nbconvert.filters.ansi', fromlist=['ansi'])
datatypefilter = __import__('IPython.frontend.nbconvert.filters.datatypefilter', fromlist=['datatypefilter'])
highlight = __import__('IPython.frontend.nbconvert.filters.highlight', fromlist=['highlight'])
latex = __import__('IPython.frontend.nbconvert.filters.latex', fromlist=['latex'])
markdown = __import__('IPython.frontend.nbconvert.filters.markdown', fromlist=['markdown'])
strings = __import__('IPython.frontend.nbconvert.filters.strings', fromlist=['strings'])
tests = __import__('IPython.frontend.nbconvert.filters.tests', fromlist=['tests'])


add_anchor = _Mock()

ansi2html = _Mock()

ansi2latex = _Mock()

comment_lines = _Mock()

escape_latex = _Mock()

get_lines = _Mock()

highlight2html = _Mock()

highlight2latex = _Mock()

html2text = _Mock()

ipython2python = _Mock()

markdown2html = _Mock()

markdown2latex = _Mock()

markdown2rst = _Mock()

posix_path = _Mock()

single_ansi2latex = _Mock()

strip_ansi = _Mock()

strip_dollars = _Mock()

strip_files_prefix = _Mock()

strip_math_space = _Mock()

wrap_text = _Mock()



class DataTypeFilter(_Mock):
  pass


