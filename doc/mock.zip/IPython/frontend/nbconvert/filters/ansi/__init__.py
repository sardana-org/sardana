from __future__ import print_function
from _mock import _Mock

coloransi = __import__('IPython.utils.coloransi', fromlist=['coloransi'])


ansi2html = _Mock()

ansi2latex = _Mock()

re = _Mock()

single_ansi2latex = _Mock()

strip_ansi = _Mock()





