from __future__ import print_function
from _mock import _Mock




LATEX_RE_SUBS = _Mock()

LATEX_SUBS = _Mock()

escape_latex = _Mock()

re = _Mock()

strip_math_space = _Mock()





