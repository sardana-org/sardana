from __future__ import print_function
from _mock import _Mock




glob = _Mock()

io = _Mock()

link_or_copy = _Mock()

os = _Mock()



class FilesWriter(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class WriterBase(_Mock):
  pass


