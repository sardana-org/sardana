from __future__ import print_function
from _mock import _Mock








class StdoutWriter(_Mock):
  pass


class WriterBase(_Mock):
  pass


