from __future__ import print_function
from _mock import _Mock

base = __import__('IPython.frontend.nbconvert.writers.base', fromlist=['base'])
debug = __import__('IPython.frontend.nbconvert.writers.debug', fromlist=['debug'])
files = __import__('IPython.frontend.nbconvert.writers.files', fromlist=['files'])
stdout = __import__('IPython.frontend.nbconvert.writers.stdout', fromlist=['stdout'])






class FilesWriter(_Mock):
  pass


class StdoutWriter(_Mock):
  pass


class WriterBase(_Mock):
  pass


