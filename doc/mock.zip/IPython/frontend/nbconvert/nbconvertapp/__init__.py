from __future__ import print_function
from _mock import _Mock

exporters = __import__('IPython.nbconvert.exporters', fromlist=['exporters'])
post_processors = __import__('IPython.nbconvert.post_processors', fromlist=['post_processors'])
transformers = __import__('IPython.nbconvert.transformers', fromlist=['transformers'])
writers = __import__('IPython.nbconvert.writers', fromlist=['writers'])


base_aliases = _Mock()

base_flags = _Mock()

catch_config_error = _Mock()

dedent = _Mock()

exporter_map = _Mock()

get_export_names = _Mock()

glob = _Mock()

import_item = _Mock()

launch_new_instance = _Mock()

logging = _Mock()

nbconvert_aliases = _Mock()

nbconvert_flags = _Mock()

os = _Mock()

print_function = _Mock()

sys = _Mock()



class BaseIPythonApplication(_Mock):
  pass
  _in_init_profile_dir = False

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class Configurable(_Mock):
  pass


class ConversionException(_Mock):
  pass


class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class DottedOrNone(_Mock):
  pass
  default_value = u''
  info_text = 'a valid object identifier in Python'

class Instance(_Mock):
  pass
  info_text = 'any value'

class List(_Mock):
  pass
  info_text = 'any value'

class NbConvertApp(_Mock):
  pass
  _in_init_profile_dir = False
  name = 'ipython-nbconvert'

class NbConvertBase(_Mock):
  pass


class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

