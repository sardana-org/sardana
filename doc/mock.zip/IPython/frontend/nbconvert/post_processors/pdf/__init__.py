from __future__ import print_function
from _mock import _Mock




os = _Mock()

subprocess = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class List(_Mock):
  pass
  info_text = 'any value'

class PDFPostProcessor(_Mock):
  pass


class PostProcessorBase(_Mock):
  pass


