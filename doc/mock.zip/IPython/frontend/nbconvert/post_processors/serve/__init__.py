from __future__ import print_function
from _mock import _Mock




os = _Mock()

webbrowser = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class HTTPServer(_Mock):
  pass
  address_family = 2
  allow_reuse_address = 1
  request_queue_size = 5
  socket_type = 1

class PostProcessorBase(_Mock):
  pass


class ServePostProcessor(_Mock):
  pass


class SimpleHTTPRequestHandler(_Mock):
  pass
  default_request_version = 'HTTP/0.9'
  disable_nagle_algorithm = False
  error_content_type = 'text/html'
  error_message_format = '<head>\n<title>Error response</title>\n</head>\n<body>\n<h1>Error response</h1>\n<p>Error code %(code)d.\n<p>Message: %(message)s.\n<p>Error code explanation: %(code)s = %(explain)s.\n</body>\n'
  protocol_version = 'HTTP/1.0'
  rbufsize = -1
  server_version = 'SimpleHTTP/0.6'
  sys_version = 'Python/2.7.6'
  wbufsize = 0

