from __future__ import print_function
from _mock import _Mock

base = __import__('IPython.frontend.nbconvert.post_processors.base', fromlist=['base'])
pdf = __import__('IPython.frontend.nbconvert.post_processors.pdf', fromlist=['pdf'])
serve = __import__('IPython.frontend.nbconvert.post_processors.serve', fromlist=['serve'])






class PDFPostProcessor(_Mock):
  pass


class PostProcessorBase(_Mock):
  pass


class ServePostProcessor(_Mock):
  pass


