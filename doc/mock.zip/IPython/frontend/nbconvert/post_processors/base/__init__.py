from __future__ import print_function
from _mock import _Mock








class NbConvertBase(_Mock):
  pass


class PostProcessorBase(_Mock):
  pass


