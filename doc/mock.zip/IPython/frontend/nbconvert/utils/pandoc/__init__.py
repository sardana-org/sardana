from __future__ import print_function
from _mock import _Mock




cast_bytes = _Mock()

pandoc = _Mock()

print_function = _Mock()

subprocess = _Mock()



class ConversionException(_Mock):
  pass


class PandocMissing(_Mock):
  pass


