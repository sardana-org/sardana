from __future__ import print_function
from _mock import _Mock








class List(_Mock):
  pass
  info_text = 'any value'

class LoggingConfigurable(_Mock):
  pass


class NbConvertBase(_Mock):
  pass


