from __future__ import print_function
from _mock import _Mock




input = _Mock()

prompt_boolean = _Mock()

prompt_dictionary = _Mock()

sys = _Mock()





