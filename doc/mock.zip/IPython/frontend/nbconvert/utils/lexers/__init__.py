from __future__ import print_function
from _mock import _Mock




Keyword = _Mock()

Operator = _Mock()

Text = _Mock()

bygroups = _Mock()

using = _Mock()



class BashLexer(_Mock):
  pass
  flags = 8
  name = 'Bash'
  priority = 0

class IPythonLexer(_Mock):
  pass
  _tmpname = 4
  flags = 8
  name = 'IPython'
  priority = 0

class PythonLexer(_Mock):
  pass
  _tmpname = 4
  flags = 8
  name = 'Python'
  priority = 0

