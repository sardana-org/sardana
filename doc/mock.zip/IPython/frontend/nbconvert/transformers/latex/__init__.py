from __future__ import print_function
from _mock import _Mock

filters = __import__('IPython.nbconvert.filters', fromlist=['filters'])


absolute_import = _Mock()

print_function = _Mock()



class LatexTransformer(_Mock):
  pass


class Transformer(_Mock):
  pass


