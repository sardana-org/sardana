from __future__ import print_function
from _mock import _Mock

base = __import__('IPython.frontend.nbconvert.transformers.base', fromlist=['base'])
coalescestreams = __import__('IPython.frontend.nbconvert.transformers.coalescestreams', fromlist=['coalescestreams'])
convertfigures = __import__('IPython.frontend.nbconvert.transformers.convertfigures', fromlist=['convertfigures'])
csshtmlheader = __import__('IPython.frontend.nbconvert.transformers.csshtmlheader', fromlist=['csshtmlheader'])
extractoutput = __import__('IPython.frontend.nbconvert.transformers.extractoutput', fromlist=['extractoutput'])
latex = __import__('IPython.frontend.nbconvert.transformers.latex', fromlist=['latex'])
revealhelp = __import__('IPython.frontend.nbconvert.transformers.revealhelp', fromlist=['revealhelp'])
sphinx = __import__('IPython.frontend.nbconvert.transformers.sphinx', fromlist=['sphinx'])
svg2pdf = __import__('IPython.frontend.nbconvert.transformers.svg2pdf', fromlist=['svg2pdf'])


coalesce_streams = _Mock()



class CSSHTMLHeaderTransformer(_Mock):
  pass


class ConvertFiguresTransformer(_Mock):
  pass


class ExtractOutputTransformer(_Mock):
  pass


class LatexTransformer(_Mock):
  pass


class RevealHelpTransformer(_Mock):
  pass


class SVG2PDFTransformer(_Mock):
  pass


class SphinxTransformer(_Mock):
  pass


class Transformer(_Mock):
  pass


