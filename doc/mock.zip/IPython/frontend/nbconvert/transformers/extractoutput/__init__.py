from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


base64 = _Mock()

os = _Mock()

sys = _Mock()



class ExtractOutputTransformer(_Mock):
  pass


class Transformer(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

