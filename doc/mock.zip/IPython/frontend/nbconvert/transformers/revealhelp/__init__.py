from __future__ import print_function
from _mock import _Mock








class RevealHelpTransformer(_Mock):
  pass


class Transformer(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

