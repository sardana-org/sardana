from __future__ import print_function
from _mock import _Mock

console = __import__('IPython.nbconvert.utils.console', fromlist=['console'])


absolute_import = _Mock()

os = _Mock()

print_function = _Mock()

sphinx = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class LatexFormatter(_Mock):
  pass
  name = 'LaTeX'
  unicodeoutput = True

class SphinxTransformer(_Mock):
  pass


class Transformer(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class date(_Mock):
  pass


