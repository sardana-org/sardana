from __future__ import print_function
from _mock import _Mock




base64 = _Mock()

io = _Mock()

os = _Mock()

subprocess = _Mock()

sys = _Mock()

INKSCAPE_APP = '/Applications/Inkscape.app/Contents/Resources/bin/inkscape'

class ConvertFiguresTransformer(_Mock):
  pass


class SVG2PDFTransformer(_Mock):
  pass


class TemporaryDirectory(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

