from __future__ import print_function
from _mock import _Mock

base = __import__('IPython.frontend.nbconvert.tests.base', fromlist=['base'])








