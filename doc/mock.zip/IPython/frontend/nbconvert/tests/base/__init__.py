from __future__ import print_function
from _mock import _Mock

IPython = __import__('IPython', fromlist=['IPython'])


get_ipython_cmd = _Mock()

get_output_error_code = _Mock()

glob = _Mock()

os = _Mock()

shutil = _Mock()

ipy_cmd = '/usr/bin/python -m IPython '

class ParametricTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TemporaryWorkingDirectory(_Mock):
  pass


class TestsBase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

