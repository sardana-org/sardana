from __future__ import print_function
from _mock import _Mock




DocDecorator = _Mock()

_make_exporter = _Mock()

export = _Mock()

export_by_name = _Mock()

export_custom = _Mock()

export_html = _Mock()

export_latex = _Mock()

export_markdown = _Mock()

export_python = _Mock()

export_rst = _Mock()

export_slides = _Mock()

exporter_map = _Mock()

g = _Mock()

get_export_names = _Mock()

wraps = _Mock()

name = 'custom'

class Config(_Mock):
  pass


class E(_Mock):
  pass


class Exporter(_Mock):
  pass


class ExporterNameError(_Mock):
  pass


class HTMLExporter(_Mock):
  pass


class LatexExporter(_Mock):
  pass


class MarkdownExporter(_Mock):
  pass


class NotebookNode(_Mock):
  pass
  _allownew = True

class PythonExporter(_Mock):
  pass


class RSTExporter(_Mock):
  pass


class SlidesExporter(_Mock):
  pass


