from __future__ import print_function
from _mock import _Mock

filters = __import__('IPython.nbconvert.filters', fromlist=['filters'])
nbformat = __import__('IPython.nbformat.current', fromlist=['current'])
nbtransformers = __import__('IPython.nbconvert.transformers', fromlist=['transformers'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


JINJA_EXTENSIONS = _Mock()

absolute_import = _Mock()

collections = _Mock()

copy = _Mock()

datetime = _Mock()

default_filters = _Mock()

import_item = _Mock()

indent = _Mock()

inspect = _Mock()

io = _Mock()

os = _Mock()

print_function = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class ChoiceLoader(_Mock):
  pass
  has_source_access = True

class Config(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class DottedObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class Environment(_Mock):
  pass
  overlayed = False
  sandboxed = False
  shared = False

class Exporter(_Mock):
  pass


class FileSystemLoader(_Mock):
  pass
  has_source_access = True

class List(_Mock):
  pass
  info_text = 'any value'

class LoggingConfigurable(_Mock):
  pass


class MetaHasTraits(_Mock):
  pass


class ResourcesDict(_Mock):
  pass


class TemplateNotFound(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

