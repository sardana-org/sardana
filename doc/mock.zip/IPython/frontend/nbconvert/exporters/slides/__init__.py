from __future__ import print_function
from _mock import _Mock

transformers = __import__('IPython.nbconvert.transformers', fromlist=['transformers'])






class Config(_Mock):
  pass


class Exporter(_Mock):
  pass


class SlidesExporter(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

