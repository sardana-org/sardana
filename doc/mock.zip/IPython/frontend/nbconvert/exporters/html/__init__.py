from __future__ import print_function
from _mock import _Mock

transformers = __import__('IPython.nbconvert.transformers', fromlist=['transformers'])






class Config(_Mock):
  pass


class Exporter(_Mock):
  pass


class HTMLExporter(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

