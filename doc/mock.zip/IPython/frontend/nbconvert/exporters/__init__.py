from __future__ import print_function
from _mock import _Mock

exporter = __import__('IPython.frontend.nbconvert.exporters.exporter', fromlist=['exporter'])
html = __import__('IPython.frontend.nbconvert.exporters.html', fromlist=['html'])
latex = __import__('IPython.frontend.nbconvert.exporters.latex', fromlist=['latex'])
markdown = __import__('IPython.frontend.nbconvert.exporters.markdown', fromlist=['markdown'])
python = __import__('IPython.frontend.nbconvert.exporters.python', fromlist=['python'])
rst = __import__('IPython.frontend.nbconvert.exporters.rst', fromlist=['rst'])
slides = __import__('IPython.frontend.nbconvert.exporters.slides', fromlist=['slides'])
tests = __import__('IPython.frontend.nbconvert.exporters.tests', fromlist=['tests'])


export = _Mock()

export_by_name = _Mock()

export_custom = _Mock()

export_html = _Mock()

export_latex = _Mock()

export_markdown = _Mock()

export_python = _Mock()

export_rst = _Mock()

export_slides = _Mock()

get_export_names = _Mock()



class Exporter(_Mock):
  pass


class ExporterNameError(_Mock):
  pass


class HTMLExporter(_Mock):
  pass


class LatexExporter(_Mock):
  pass


class MarkdownExporter(_Mock):
  pass


class PythonExporter(_Mock):
  pass


class RSTExporter(_Mock):
  pass


class SlidesExporter(_Mock):
  pass


