from __future__ import print_function
from _mock import _Mock

nbformat = __import__('IPython.nbformat.current', fromlist=['current'])


export = _Mock()

export_by_name = _Mock()

export_custom = _Mock()

export_html = _Mock()

export_latex = _Mock()

export_markdown = _Mock()

export_python = _Mock()

export_rst = _Mock()

export_slides = _Mock()

get_export_names = _Mock()

os = _Mock()



class ExporterNameError(_Mock):
  pass


class ExportersTestsBase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class PythonExporter(_Mock):
  pass


class TestExport(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

