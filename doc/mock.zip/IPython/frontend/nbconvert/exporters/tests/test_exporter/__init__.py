from __future__ import print_function
from _mock import _Mock








class CheeseTransformer(_Mock):
  pass


class Config(_Mock):
  pass


class Exporter(_Mock):
  pass


class ExportersTestsBase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestExporter(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

