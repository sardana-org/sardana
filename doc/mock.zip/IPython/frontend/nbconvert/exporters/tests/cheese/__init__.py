from __future__ import print_function
from _mock import _Mock








class CheeseTransformer(_Mock):
  pass


class Transformer(_Mock):
  pass


