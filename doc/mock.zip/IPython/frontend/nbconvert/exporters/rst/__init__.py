from __future__ import print_function
from _mock import _Mock








class Config(_Mock):
  pass


class Exporter(_Mock):
  pass


class RSTExporter(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

