from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_join_lines = _Mock()

_multiline_outputs = _Mock()

base64_decode = _Mock()

base64_encode = _Mock()

decodestring = _Mock()

encodestring = _Mock()

pprint = _Mock()

rejoin_lines = _Mock()

restore_bytes = _Mock()

split_lines = _Mock()

str_to_bytes = _Mock()



class NotebookReader(_Mock):
  pass


class NotebookWriter(_Mock):
  pass


