from __future__ import print_function
from _mock import _Mock

argparse = __import__('IPython.external.argparse', fromlist=['argparse'])
jsonpointer = __import__('IPython.external.jsonpointer', fromlist=['jsonpointer'])


convert = _Mock()

json = _Mock()

nbvalidate = _Mock()

resolve_ref = _Mock()

traceback = _Mock()

validate = _Mock()



class Draft3Validator(_Mock):
  pass


class ValidationError(_Mock):
  pass


