from __future__ import print_function
from _mock import _Mock




from_dict = _Mock()

new_author = _Mock()

new_code_cell = _Mock()

new_heading_cell = _Mock()

new_metadata = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

pprint = _Mock()

uuid = _Mock()

nbformat = 3

nbformat_minor = 0

class NotebookNode(_Mock):
  pass
  _allownew = True

class Struct(_Mock):
  pass
  _allownew = True

