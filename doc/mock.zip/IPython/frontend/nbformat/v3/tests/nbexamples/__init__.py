from __future__ import print_function
from _mock import _Mock




authors = _Mock()

encodestring = _Mock()

md = _Mock()

nb0 = _Mock()

new_author = _Mock()

new_code_cell = _Mock()

new_heading_cell = _Mock()

new_metadata = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

os = _Mock()

ws = _Mock()

jpeg = 'Zy7A94p6\n'

nb0_py = u'# -*- coding: utf-8 -*-\n# <nbformat>3.0</nbformat>\n\n# <htmlcell>\n\n# Some NumPy Examples\n\n# <codecell>\n\nimport numpy\n\n# <markdowncell>\n\n# A random array\n\n# <rawcell>\n\n# A random array\n\n# <headingcell level=2>\n\n# My Heading\n\n# <codecell>\n\na = numpy.random.rand(100)\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\nprint "\xfcn\xeec\xf8d\xe9"\n\n'

nbformat = 3

nbformat_minor = 0

png = 'ycIGME8=\n'

class NotebookNode(_Mock):
  pass
  _allownew = True

