from __future__ import print_function
from _mock import _Mock

formattest = __import__('IPython.frontend.nbformat.v3.tests.formattest', fromlist=['formattest'])
nbpy = __import__('IPython.frontend.nbformat.v3.nbpy', fromlist=['nbpy'])


nb0 = _Mock()

nb0_py = u'# -*- coding: utf-8 -*-\n# <nbformat>3.0</nbformat>\n\n# <htmlcell>\n\n# Some NumPy Examples\n\n# <codecell>\n\nimport numpy\n\n# <markdowncell>\n\n# A random array\n\n# <rawcell>\n\n# A random array\n\n# <headingcell level=2>\n\n# My Heading\n\n# <codecell>\n\na = numpy.random.rand(100)\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\nprint "\xfcn\xeec\xf8d\xe9"\n\n'

class TestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestPy(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  ext = 'py'
  longMessage = False
  maxDiff = 640
  nb0_ref = u'# -*- coding: utf-8 -*-\n# <nbformat>3.0</nbformat>\n\n# <htmlcell>\n\n# Some NumPy Examples\n\n# <codecell>\n\nimport numpy\n\n# <markdowncell>\n\n# A random array\n\n# <rawcell>\n\n# A random array\n\n# <headingcell level=2>\n\n# My Heading\n\n# <codecell>\n\na = numpy.random.rand(100)\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\nprint "\xfcn\xeec\xf8d\xe9"\n\n'

