from __future__ import print_function
from _mock import _Mock

formattest = __import__('IPython.frontend.nbformat.v3.tests.formattest', fromlist=['formattest'])
nbexamples = __import__('IPython.frontend.nbformat.v3.tests.nbexamples', fromlist=['nbexamples'])
test_json = __import__('IPython.frontend.nbformat.v3.tests.test_json', fromlist=['test_json'])
test_nbbase = __import__('IPython.frontend.nbformat.v3.tests.test_nbbase', fromlist=['test_nbbase'])
test_nbpy = __import__('IPython.frontend.nbformat.v3.tests.test_nbpy', fromlist=['test_nbpy'])








