from __future__ import print_function
from _mock import _Mock




io = _Mock()

nb0 = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

open_utf8 = _Mock()

os = _Mock()

pjoin = _Mock()

read = _Mock()

reads = _Mock()

shutil = _Mock()

tempfile = _Mock()

write = _Mock()

writes = _Mock()

nb0_py = u'# -*- coding: utf-8 -*-\n# <nbformat>3.0</nbformat>\n\n# <htmlcell>\n\n# Some NumPy Examples\n\n# <codecell>\n\nimport numpy\n\n# <markdowncell>\n\n# A random array\n\n# <rawcell>\n\n# A random array\n\n# <headingcell level=2>\n\n# My Heading\n\n# <codecell>\n\na = numpy.random.rand(100)\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\na = 10\nb = 5\n\n# <codecell>\n\nprint "\xfcn\xeec\xf8d\xe9"\n\n'

class NBFormatTest(_Mock):
  pass


class NotebookNode(_Mock):
  pass
  _allownew = True

