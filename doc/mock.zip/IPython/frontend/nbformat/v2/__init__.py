from __future__ import print_function
from _mock import _Mock

convert = __import__('IPython.frontend.nbformat.v2.convert', fromlist=['convert'])
nbbase = __import__('IPython.frontend.nbformat.v2.nbbase', fromlist=['nbbase'])
nbjson = __import__('IPython.frontend.nbformat.v2.nbjson', fromlist=['nbjson'])
nbpy = __import__('IPython.frontend.nbformat.v2.nbpy', fromlist=['nbpy'])
nbxml = __import__('IPython.frontend.nbformat.v2.nbxml', fromlist=['nbxml'])
rwbase = __import__('IPython.frontend.nbformat.v2.rwbase', fromlist=['rwbase'])
tests = __import__('IPython.frontend.nbformat.v2.tests', fromlist=['tests'])


convert_to_this_nbformat = _Mock()

new_author = _Mock()

new_code_cell = _Mock()

new_metadata = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

parse_filename = _Mock()

read_json = _Mock()

read_py = _Mock()

read_xml = _Mock()

reads_json = _Mock()

reads_py = _Mock()

reads_xml = _Mock()

to_notebook_json = _Mock()

to_notebook_py = _Mock()

to_notebook_xml = _Mock()

write_json = _Mock()

write_py = _Mock()

writes_json = _Mock()

writes_py = _Mock()



class NotebookNode(_Mock):
  pass
  _allownew = True

