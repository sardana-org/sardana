from __future__ import print_function
from _mock import _Mock




convert_to_this_nbformat = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()





