from __future__ import print_function
from _mock import _Mock




nb0 = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

reads = _Mock()

writes = _Mock()

nb0_py = '# -*- coding: utf-8 -*-\n# <nbformat>2</nbformat>\n\n# <htmlcell>\n\n# Some NumPy Examples\n\n# <codecell>\n\nimport numpy\n\n# <markdowncell>\n\n# A random array\n\n# <codecell>\n\na = numpy.random.rand(100)\n\n# <codecell>\n\nprint a\n\n'

class NotebookNode(_Mock):
  pass
  _allownew = True

class TestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestPy(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

