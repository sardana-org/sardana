from __future__ import print_function
from _mock import _Mock




authors = _Mock()

encodestring = _Mock()

md = _Mock()

nb0 = _Mock()

new_author = _Mock()

new_code_cell = _Mock()

new_metadata = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

os = _Mock()

ws = _Mock()

jpeg = 'I3LKxClU\n'

nb0_py = '# -*- coding: utf-8 -*-\n# <nbformat>2</nbformat>\n\n# <htmlcell>\n\n# Some NumPy Examples\n\n# <codecell>\n\nimport numpy\n\n# <markdowncell>\n\n# A random array\n\n# <codecell>\n\na = numpy.random.rand(100)\n\n# <codecell>\n\nprint a\n\n'

png = 'NRxGWxA=\n'

class NotebookNode(_Mock):
  pass
  _allownew = True

