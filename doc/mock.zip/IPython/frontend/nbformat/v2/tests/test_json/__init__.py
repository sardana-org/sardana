from __future__ import print_function
from _mock import _Mock




nb0 = _Mock()

pprint = _Mock()

reads = _Mock()

writes = _Mock()



class TestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestJSON(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

