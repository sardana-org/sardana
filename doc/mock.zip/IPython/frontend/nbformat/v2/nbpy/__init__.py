from __future__ import print_function
from _mock import _Mock




_encoding_declaration_re = _Mock()

_reader = _Mock()

_writer = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

re = _Mock()

read = _Mock()

reads = _Mock()

to_notebook = _Mock()

write = _Mock()

writes = _Mock()



class NotebookReader(_Mock):
  pass


class NotebookWriter(_Mock):
  pass


class PyReader(_Mock):
  pass


class PyReaderError(_Mock):
  pass


class PyWriter(_Mock):
  pass


