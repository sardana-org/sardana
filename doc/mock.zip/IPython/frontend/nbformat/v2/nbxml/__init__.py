from __future__ import print_function
from _mock import _Mock




ET = _Mock()

_get_binary = _Mock()

_get_bool = _Mock()

_get_int = _Mock()

_get_text = _Mock()

_reader = _Mock()

_set_binary = _Mock()

_set_bool = _Mock()

_set_int = _Mock()

_set_text = _Mock()

decodestring = _Mock()

encodestring = _Mock()

indent = _Mock()

new_code_cell = _Mock()

new_metadata = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

read = _Mock()

reads = _Mock()

to_notebook = _Mock()

warnings = _Mock()



class NotebookReader(_Mock):
  pass


class NotebookWriter(_Mock):
  pass


class XMLReader(_Mock):
  pass


