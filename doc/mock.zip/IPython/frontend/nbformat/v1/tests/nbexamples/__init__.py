from __future__ import print_function
from _mock import _Mock




nb0 = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()



class NotebookNode(_Mock):
  pass
  _allownew = True

