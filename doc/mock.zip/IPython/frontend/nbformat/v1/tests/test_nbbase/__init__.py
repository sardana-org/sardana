from __future__ import print_function
from _mock import _Mock




new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()



class NotebookNode(_Mock):
  pass
  _allownew = True

class TestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestCell(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestNotebook(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

