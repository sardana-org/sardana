from __future__ import print_function
from _mock import _Mock

nbexamples = __import__('IPython.frontend.nbformat.v1.tests.nbexamples', fromlist=['nbexamples'])
test_json = __import__('IPython.frontend.nbformat.v1.tests.test_json', fromlist=['test_json'])
test_nbbase = __import__('IPython.frontend.nbformat.v1.tests.test_nbbase', fromlist=['test_nbbase'])








