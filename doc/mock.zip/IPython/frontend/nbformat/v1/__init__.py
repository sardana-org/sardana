from __future__ import print_function
from _mock import _Mock

convert = __import__('IPython.frontend.nbformat.v1.convert', fromlist=['convert'])
nbbase = __import__('IPython.frontend.nbformat.v1.nbbase', fromlist=['nbbase'])
nbjson = __import__('IPython.frontend.nbformat.v1.nbjson', fromlist=['nbjson'])
rwbase = __import__('IPython.frontend.nbformat.v1.rwbase', fromlist=['rwbase'])
tests = __import__('IPython.frontend.nbformat.v1.tests', fromlist=['tests'])


convert_to_this_nbformat = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()

read_json = _Mock()

reads_json = _Mock()

to_notebook_json = _Mock()

write_json = _Mock()

writes_json = _Mock()



class NotebookNode(_Mock):
  pass
  _allownew = True

