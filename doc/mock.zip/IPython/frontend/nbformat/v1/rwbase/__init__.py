from __future__ import print_function
from _mock import _Mock




decodestring = _Mock()

encodestring = _Mock()



class NotebookReader(_Mock):
  pass


class NotebookWriter(_Mock):
  pass


