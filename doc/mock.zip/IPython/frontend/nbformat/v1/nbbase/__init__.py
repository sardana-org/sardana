from __future__ import print_function
from _mock import _Mock




from_dict = _Mock()

new_code_cell = _Mock()

new_notebook = _Mock()

new_text_cell = _Mock()

pprint = _Mock()

uuid = _Mock()



class NotebookNode(_Mock):
  pass
  _allownew = True

class Struct(_Mock):
  pass
  _allownew = True

