from __future__ import print_function
from _mock import _Mock




_reader = _Mock()

_writer = _Mock()

encodestring = _Mock()

from_dict = _Mock()

json = _Mock()

read = _Mock()

reads = _Mock()

to_notebook = _Mock()

write = _Mock()

writes = _Mock()



class JSONReader(_Mock):
  pass


class JSONWriter(_Mock):
  pass


class NotebookReader(_Mock):
  pass


class NotebookWriter(_Mock):
  pass


