from __future__ import print_function
from _mock import _Mock

current = __import__('IPython.frontend.nbformat.current', fromlist=['current'])
tests = __import__('IPython.frontend.nbformat.tests', fromlist=['tests'])
v1 = __import__('IPython.frontend.nbformat.v1', fromlist=['v1'])
v2 = __import__('IPython.frontend.nbformat.v2', fromlist=['v2'])
v3 = __import__('IPython.frontend.nbformat.v3', fromlist=['v3'])








