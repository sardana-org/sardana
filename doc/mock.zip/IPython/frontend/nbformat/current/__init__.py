from __future__ import print_function
from _mock import _Mock

v1 = __import__('IPython.nbformat.v1', fromlist=['v1'])
v2 = __import__('IPython.nbformat.v2', fromlist=['v2'])
v3 = __import__('IPython.nbformat.v3', fromlist=['v3'])


ET = _Mock()

_convert_to_metadata = _Mock()

json = _Mock()

new_author = _Mock()

new_code_cell = _Mock()

new_heading_cell = _Mock()

new_metadata = _Mock()

new_notebook = _Mock()

new_output = _Mock()

new_text_cell = _Mock()

new_worksheet = _Mock()

parse_filename = _Mock()

parse_json = _Mock()

parse_py = _Mock()

print_function = _Mock()

re = _Mock()

read = _Mock()

reads = _Mock()

reads_json = _Mock()

reads_py = _Mock()

write = _Mock()

writes = _Mock()

writes_json = _Mock()

writes_py = _Mock()

current_nbformat = 3

current_nbformat_minor = 0

nbformat = 3

nbformat_minor = 0

class NBFormatError(_Mock):
  pass


class NotJSONError(_Mock):
  pass


class NotebookNode(_Mock):
  pass
  _allownew = True

