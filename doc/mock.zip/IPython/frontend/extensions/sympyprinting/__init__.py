from __future__ import print_function
from _mock import _Mock




can_print_latex = _Mock()

latex_to_png = _Mock()

load_ipython_extension = _Mock()

print_basic_unicode = _Mock()

print_display_png = _Mock()

print_latex = _Mock()

print_png = _Mock()

warnings = _Mock()

_loaded = _Mock()



