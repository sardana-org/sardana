from __future__ import print_function
from _mock import _Mock

openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])


UPDATE_RULES = _Mock()

func_attrs = _Mock()

isinstance2 = _Mock()

line_magic = _Mock()

load_ipython_extension = _Mock()

magics_class = _Mock()

os = _Mock()

print_function = _Mock()

superreload = _Mock()

sys = _Mock()

traceback = _Mock()

types = _Mock()

update_class = _Mock()

update_function = _Mock()

update_generic = _Mock()

update_property = _Mock()

weakref = _Mock()

PY3 = _Mock()

skip_doctest = _Mock()

class AutoreloadMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

class ModuleReloader(_Mock):
  pass
  check_all = True
  enabled = False

class StrongRef(_Mock):
  pass


class TryNext(_Mock):
  pass


