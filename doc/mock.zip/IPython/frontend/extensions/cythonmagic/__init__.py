from __future__ import print_function
from _mock import _Mock

display = __import__('IPython.core.display', fromlist=['display'])
magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


Cython = _Mock()

cell_magic = _Mock()

cythonize = _Mock()

get_ipython_cache_dir = _Mock()

hashlib = _Mock()

imp = _Mock()

io = _Mock()

load_ipython_extension = _Mock()

magics_class = _Mock()

os = _Mock()

print_function = _Mock()

re = _Mock()

sys = _Mock()

time = _Mock()



class CompileError(_Mock):
  pass


class CythonMagics(_Mock):
  pass
  registered = True

class Distribution(_Mock):
  pass
  common_usage = "Common commands: (see '--help-commands' for more)\n\n  setup.py build      will build the package underneath 'build/'\n  setup.py install    will install the package\n"

class Extension(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class build_ext(_Mock):
  pass
  description = 'build C/C++ extensions (compile/link to build directory)'
  sep_by = " (separated by ':')"

