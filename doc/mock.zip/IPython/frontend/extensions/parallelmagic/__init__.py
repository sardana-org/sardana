from __future__ import print_function
from _mock import _Mock




load_ipython_extension = _Mock()

warn = _Mock()





