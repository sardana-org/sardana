from __future__ import print_function
from _mock import _Mock

autoreload = __import__('IPython.frontend.extensions.autoreload', fromlist=['autoreload'])
cythonmagic = __import__('IPython.frontend.extensions.cythonmagic', fromlist=['cythonmagic'])
parallelmagic = __import__('IPython.frontend.extensions.parallelmagic', fromlist=['parallelmagic'])
storemagic = __import__('IPython.frontend.extensions.storemagic', fromlist=['storemagic'])
sympyprinting = __import__('IPython.frontend.extensions.sympyprinting', fromlist=['sympyprinting'])
tests = __import__('IPython.frontend.extensions.tests', fromlist=['tests'])








