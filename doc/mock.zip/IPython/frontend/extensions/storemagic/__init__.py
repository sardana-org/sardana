from __future__ import print_function
from _mock import _Mock




inspect = _Mock()

line_magic = _Mock()

load_ipython_extension = _Mock()

magics_class = _Mock()

os = _Mock()

refresh_variables = _Mock()

restore_aliases = _Mock()

restore_data = _Mock()

restore_dhist = _Mock()

skip_doctest = _Mock()

sys = _Mock()

textwrap = _Mock()



class FakeModule(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class StoreMagics(_Mock):
  pass
  registered = True

class UsageError(_Mock):
  pass


