from __future__ import print_function
from _mock import _Mock




LOCAL_IPS = _Mock()

aliases = _Mock()

app_aliases = _Mock()

app_flags = _Mock()

atexit = _Mock()

boolean_flag = _Mock()

classes = _Mock()

default_secure = _Mock()

filefind = _Mock()

find_connection_file = _Mock()

flags = _Mock()

json = _Mock()

kernel_aliases = _Mock()

kernel_flags = _Mock()

os = _Mock()

shutil = _Mock()

signal = _Mock()

str_to_bytes = _Mock()

swallow_argv = _Mock()

sys = _Mock()

tunnel_to_kernel = _Mock()

uuid = _Mock()

LOCALHOST = '127.0.0.1'

class Any(_Mock):
  pass
  info_text = 'any value'

class BlockingKernelClient(_Mock):
  pass


class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CUnicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class IPKernelApp(_Mock):
  pass
  _in_init_profile_dir = False
  name = 'ipkernel'

class IPythonConsoleApp(_Mock):
  pass
  description = '\n        The IPython Mixin Console.\n        \n        This class contains the common portions of console client (QtConsole,\n        ZMQ-based terminal console, etc).  It is not a full console, in that\n        launched terminal subprocesses will not be able to accept input.\n        \n        The Console using this mixing supports various extra features beyond\n        the single-process Terminal IPython shell, such as connecting to\n        existing kernel, via:\n        \n            ipython <appname> --existing\n        \n        as well as tunnel via SSH\n        \n    '
  name = 'ipython-console-mixin'

class InlineBackend(_Mock):
  pass


class Int(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

class KernelManager(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class ProfileDir(_Mock):
  pass


class Session(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class ZMQInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

