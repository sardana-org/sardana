from __future__ import print_function
from _mock import _Mock




abc = _Mock()



class KernelClientABC(_Mock):
  pass
  _abc_negative_cache_version = 46

