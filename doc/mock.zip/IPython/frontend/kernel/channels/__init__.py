from __future__ import print_function
from _mock import _Mock




absolute_import = _Mock()

atexit = _Mock()

errno = _Mock()

ioloop = _Mock()

time = _Mock()

validate_string_dict = _Mock()

validate_string_list = _Mock()

zmq = _Mock()

zmqstream = _Mock()



class HBChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  time_to_dead = 3.0

class HBChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 44

class IOPubChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class IOPubChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 43

class InvalidPortNumber(_Mock):
  pass


class ShellChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False
  allow_stdin = True

class ShellChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 42

class StdInChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

class StdInChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 45

class Thread(_Mock):
  pass
  _Thread__initialized = False

class ZMQError(_Mock):
  pass


class ZMQSocketChannel(_Mock):
  pass
  _Thread__initialized = False
  _exiting = False

