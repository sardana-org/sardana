from __future__ import print_function
from _mock import _Mock








class InProcessHBChannel(_Mock):
  pass
  time_to_dead = 3.0

class InProcessIOPubChannel(_Mock):
  pass


class InProcessKernelClient(_Mock):
  pass


class InProcessShellChannel(_Mock):
  pass
  allow_stdin = True

class InProcessStdInChannel(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class KernelClient(_Mock):
  pass


class KernelClientABC(_Mock):
  pass
  _abc_negative_cache_version = 54

class Type(_Mock):
  pass
  info_text = 'any value'

