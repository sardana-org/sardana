from __future__ import print_function
from _mock import _Mock

test_kernelmanager = __import__('IPython.frontend.kernel.inprocess.tests.test_kernelmanager', fromlist=['test_kernelmanager'])








