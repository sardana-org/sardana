from __future__ import print_function
from _mock import _Mock








class DummySocket(_Mock):
  pass


class HBChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 52

class IOPubChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 51

class InProcessChannel(_Mock):
  pass


class InProcessHBChannel(_Mock):
  pass
  time_to_dead = 3.0

class InProcessIOPubChannel(_Mock):
  pass


class InProcessShellChannel(_Mock):
  pass
  allow_stdin = True

class InProcessStdInChannel(_Mock):
  pass


class ShellChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 50

class StdInChannelABC(_Mock):
  pass
  _abc_negative_cache_version = 53

