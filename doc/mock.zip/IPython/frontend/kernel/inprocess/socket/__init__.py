from __future__ import print_function
from _mock import _Mock




Queue = _Mock()

abc = _Mock()

zmq = _Mock()



class DummySocket(_Mock):
  pass


class HasTraits(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Int(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

class SocketABC(_Mock):
  pass
  _abc_negative_cache_version = 49

