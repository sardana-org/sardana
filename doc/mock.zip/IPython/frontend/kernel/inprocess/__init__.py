from __future__ import print_function
from _mock import _Mock

blocking = __import__('IPython.frontend.kernel.inprocess.blocking', fromlist=['blocking'])
channels = __import__('IPython.frontend.kernel.inprocess.channels', fromlist=['channels'])
client = __import__('IPython.frontend.kernel.inprocess.client', fromlist=['client'])
ipkernel = __import__('IPython.frontend.kernel.inprocess.ipkernel', fromlist=['ipkernel'])
manager = __import__('IPython.frontend.kernel.inprocess.manager', fromlist=['manager'])
socket = __import__('IPython.frontend.kernel.inprocess.socket', fromlist=['socket'])
tests = __import__('IPython.frontend.kernel.inprocess.tests', fromlist=['tests'])






class BlockingInProcessKernelClient(_Mock):
  pass


class InProcessHBChannel(_Mock):
  pass
  time_to_dead = 3.0

class InProcessIOPubChannel(_Mock):
  pass


class InProcessKernelClient(_Mock):
  pass


class InProcessKernelManager(_Mock):
  pass


class InProcessShellChannel(_Mock):
  pass
  allow_stdin = True

class InProcessStdInChannel(_Mock):
  pass


