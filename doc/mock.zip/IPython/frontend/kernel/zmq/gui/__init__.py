from __future__ import print_function
from _mock import _Mock

gtkembed = __import__('IPython.frontend.kernel.zmq.gui.gtkembed', fromlist=['gtkembed'])








