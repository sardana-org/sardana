from __future__ import print_function
from _mock import _Mock

test_session = __import__('IPython.frontend.kernel.zmq.tests.test_session', fromlist=['test_session'])








