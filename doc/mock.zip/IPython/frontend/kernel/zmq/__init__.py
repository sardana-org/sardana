from __future__ import print_function
from _mock import _Mock

datapub = __import__('IPython.frontend.kernel.zmq.datapub', fromlist=['datapub'])
displayhook = __import__('IPython.frontend.kernel.zmq.displayhook', fromlist=['displayhook'])
embed = __import__('IPython.frontend.kernel.zmq.embed', fromlist=['embed'])
eventloops = __import__('IPython.frontend.kernel.zmq.eventloops', fromlist=['eventloops'])
gui = __import__('IPython.frontend.kernel.zmq.gui', fromlist=['gui'])
heartbeat = __import__('IPython.frontend.kernel.zmq.heartbeat', fromlist=['heartbeat'])
iostream = __import__('IPython.frontend.kernel.zmq.iostream', fromlist=['iostream'])
ipkernel = __import__('IPython.frontend.kernel.zmq.ipkernel', fromlist=['ipkernel'])
kernelapp = __import__('IPython.frontend.kernel.zmq.kernelapp', fromlist=['kernelapp'])
log = __import__('IPython.frontend.kernel.zmq.log', fromlist=['log'])
parentpoller = __import__('IPython.frontend.kernel.zmq.parentpoller', fromlist=['parentpoller'])
pylab = __import__('IPython.frontend.kernel.zmq.pylab', fromlist=['pylab'])
serialize = __import__('IPython.frontend.kernel.zmq.serialize', fromlist=['serialize'])
session = __import__('IPython.frontend.kernel.zmq.session', fromlist=['session'])
tests = __import__('IPython.frontend.kernel.zmq.tests', fromlist=['tests'])
zmqshell = __import__('IPython.frontend.kernel.zmq.zmqshell', fromlist=['zmqshell'])


check_for_zmq = _Mock()



class Session(_Mock):
  pass


