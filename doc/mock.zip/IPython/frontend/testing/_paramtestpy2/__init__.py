from __future__ import print_function
from _mock import _Mock




isgenerator = _Mock()

parametric = _Mock()

sys = _Mock()

unittest = _Mock()

CO_GENERATOR = 32

class ParametricTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

