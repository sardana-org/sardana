from __future__ import print_function
from _mock import _Mock

_paramtestpy2 = __import__('IPython.frontend.testing._paramtestpy2', fromlist=['_paramtestpy2'])
_paramtestpy3 = __import__('IPython.frontend.testing._paramtestpy3', fromlist=['_paramtestpy3'])
decorators = __import__('IPython.frontend.testing.decorators', fromlist=['decorators'])
globalipapp = __import__('IPython.frontend.testing.globalipapp', fromlist=['globalipapp'])
ipunittest = __import__('IPython.frontend.testing.ipunittest', fromlist=['ipunittest'])
mkdoctests = __import__('IPython.frontend.testing.mkdoctests', fromlist=['mkdoctests'])
plugin = __import__('IPython.frontend.testing.plugin', fromlist=['plugin'])
skipdoctest = __import__('IPython.frontend.testing.skipdoctest', fromlist=['skipdoctest'])
tests = __import__('IPython.frontend.testing.tests', fromlist=['tests'])
tools = __import__('IPython.frontend.testing.tools', fromlist=['tools'])


test = _Mock()





