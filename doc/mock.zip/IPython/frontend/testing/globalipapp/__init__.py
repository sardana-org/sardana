from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])
page = __import__('IPython.core.page', fromlist=['page'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
tools = __import__('IPython.frontend.testing.tools', fromlist=['tools'])


_run_ns_sync = _Mock()

_showtraceback = _Mock()

absolute_import = _Mock()

builtin_mod = _Mock()

get_ipython = _Mock()

os = _Mock()

print_function = _Mock()

start_ipython = _Mock()

sys = _Mock()

xsys = _Mock()



class StreamProxy(_Mock):
  pass


class TerminalInteractiveShell(_Mock):
  pass
  default_user_namespaces = True

class py_file_finder(_Mock):
  pass


