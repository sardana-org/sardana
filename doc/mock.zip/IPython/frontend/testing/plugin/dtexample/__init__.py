from __future__ import print_function
from _mock import _Mock




doctest_refactor_print = _Mock()

ipfunc = _Mock()

iprand = _Mock()

iprand_all = _Mock()

pyfunc = _Mock()

random_all = _Mock()

ranfunc = _Mock()





