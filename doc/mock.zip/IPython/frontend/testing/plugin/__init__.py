from __future__ import print_function
from _mock import _Mock

dtexample = __import__('IPython.frontend.testing.plugin.dtexample', fromlist=['dtexample'])
show_refs = __import__('IPython.frontend.testing.plugin.show_refs', fromlist=['show_refs'])
simple = __import__('IPython.frontend.testing.plugin.simple', fromlist=['simple'])
simplevars = __import__('IPython.frontend.testing.plugin.simplevars', fromlist=['simplevars'])
test_ipdoctest = __import__('IPython.frontend.testing.plugin.test_ipdoctest', fromlist=['test_ipdoctest'])
test_refs = __import__('IPython.frontend.testing.plugin.test_refs', fromlist=['test_refs'])








