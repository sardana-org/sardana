from __future__ import print_function
from _mock import _Mock




doctest_ivars = _Mock()

doctest_refs = _Mock()

doctest_run = _Mock()

doctest_runvars = _Mock()

inspect = _Mock()

test_trivial = _Mock()





