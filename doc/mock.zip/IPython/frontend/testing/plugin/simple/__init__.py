from __future__ import print_function
from _mock import _Mock




ipyfunc2 = _Mock()

pyfunc = _Mock()





