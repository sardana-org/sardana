from __future__ import print_function
from _mock import _Mock




doctest_multiline1 = _Mock()

doctest_multiline2 = _Mock()

doctest_multiline3 = _Mock()

doctest_refactor_print = _Mock()

doctest_simple = _Mock()





