from __future__ import print_function
from _mock import _Mock






x = 1



