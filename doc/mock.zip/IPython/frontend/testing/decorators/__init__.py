from __future__ import print_function
from _mock import _Mock




apply_wrapper = _Mock()

as_unittest = _Mock()

decorator = _Mock()

deprecated = _Mock()

f = _Mock()

ipdocstring = _Mock()

ipdoctest = _Mock()

is_cmd_found = _Mock()

known_failure_py3 = _Mock()

knownfailureif = _Mock()

make_label_dec = _Mock()

module_not_available = _Mock()

null_deco = _Mock()

onlyif = _Mock()

onlyif_cmds_exist = _Mock()

onlyif_unicode_paths = _Mock()

parametric = _Mock()

setastest = _Mock()

skip = _Mock()

skip_if_not_linux = _Mock()

skip_if_not_osx = _Mock()

skip_if_not_win32 = _Mock()

skip_known_failure = _Mock()

skip_linux = _Mock()

skip_osx = _Mock()

skip_win32 = _Mock()

skip_without = _Mock()

skipif = _Mock()

skipif_not_matplotlib = _Mock()

skipif_not_numpy = _Mock()

skipif_not_sympy = _Mock()

slow = _Mock()

sys = _Mock()

tempfile = _Mock()

unittest = _Mock()

warnings = _Mock()

unicode_paths = _Mock()

class WarningManager(_Mock):
  pass


class WarningMessage(_Mock):
  pass


