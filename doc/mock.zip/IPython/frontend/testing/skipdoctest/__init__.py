from __future__ import print_function
from _mock import _Mock




skip_doctest = _Mock()

skip_doctest_py3 = _Mock()

sys = _Mock()





