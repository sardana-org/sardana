from __future__ import print_function
from _mock import _Mock

dec = __import__('IPython.frontend.testing.decorators', fromlist=['decorators'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
skipdoctest = __import__('IPython.frontend.testing.skipdoctest', fromlist=['skipdoctest'])


absolute_import = _Mock()

check_pairs = _Mock()

contextmanager = _Mock()

default_argv = _Mock()

default_config = _Mock()

doctest_deco = _Mock()

full_path = _Mock()

get_ipython_cmd = _Mock()

ipexec = _Mock()

ipexec_validate = _Mock()

list_strings = _Mock()

make_tempfile = _Mock()

monkeypatch = _Mock()

mute_warn = _Mock()

os = _Mock()

parse_test_output = _Mock()

re = _Mock()

sys = _Mock()

temp_pyfile = _Mock()

tempfile = _Mock()

DEFAULT_ENCODING = 'UTF-8'

PIPE = -1

has_nose = _Mock()

notprinted_msg = 'Did not find {0!r} in printed output (on {1}):\n-------\n{2!s}\n-------\n'

pair_fail_msg = 'Testing {0}\n\nIn:\n  {1!r}\nExpected:\n  {2!r}\nGot:\n  {3!r}\n'

printed_msg = 'Found {0!r} in printed output (on {1}):\n-------\n{2!s}\n-------\n'

class AssertNotPrints(_Mock):
  pass


class AssertPrints(_Mock):
  pass


class Config(_Mock):
  pass


class MyStringIO(_Mock):
  pass


class Popen(_Mock):
  pass


class StringIO(_Mock):
  pass


class Tee(_Mock):
  pass


class TempFileMixin(_Mock):
  pass


