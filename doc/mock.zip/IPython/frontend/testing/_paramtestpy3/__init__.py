from __future__ import print_function
from _mock import _Mock




isgenerator = _Mock()

parametric = _Mock()

unittest = _Mock()



class IterCallableSuite(_Mock):
  pass


class ParametricTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestSuite(_Mock):
  pass


