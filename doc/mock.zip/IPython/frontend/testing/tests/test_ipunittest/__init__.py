from __future__ import print_function
from _mock import _Mock




doctest_refactor_print = _Mock()

ipdocstring = _Mock()

ipdoctest = _Mock()



class Foo(_Mock):
  pass


class ipdt_flush(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class ipdt_indented_test(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class simple_dt(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

