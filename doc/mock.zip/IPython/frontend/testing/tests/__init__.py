from __future__ import print_function
from _mock import _Mock

test_ipunittest = __import__('IPython.frontend.testing.tests.test_ipunittest', fromlist=['test_ipunittest'])








