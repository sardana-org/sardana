from __future__ import print_function
from _mock import _Mock




absolute_import = _Mock()

count_failures = _Mock()

ip2py = _Mock()

ipdocstring = _Mock()

ipdoctest = _Mock()

re = _Mock()

sys = _Mock()

unittest = _Mock()



class Doc2UnitTester(_Mock):
  pass


class DocTestFinder(_Mock):
  pass


class DocTestRunner(_Mock):
  pass
  DIVIDER = '**********************************************************************'

class IPython2PythonConverter(_Mock):
  pass


class ParametricTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TestResults(_Mock):
  pass


