from __future__ import print_function
from _mock import _Mock

tt = __import__('IPython.testing.tools', fromlist=['tools'])


io = _Mock()

ip = _Mock()

os = _Mock()

unittest = _Mock()

file_1 = '1\n2\n3\ndef f():\n  1/0\n'

file_2 = 'def f():\n  1/0\n'

indentationerror_file = 'if True:\nzoon()\n'

iso_8859_5_file = u'# coding: iso-8859-5\n\ndef fail():\n    """\u0434\u0431\u0418\u0416"""\n    1/0     # \u0434\u0431\u0418\u0416\n'

class ChangedPyFileTest(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class IndentationErrorTest(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class NonAsciiTest(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class SyntaxErrorTest(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class TemporaryDirectory(_Mock):
  pass


class prepended_to_syspath(_Mock):
  pass


