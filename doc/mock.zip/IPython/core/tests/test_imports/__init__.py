from __future__ import print_function
from _mock import _Mock




test_import_completer = _Mock()

test_import_crashhandler = _Mock()

test_import_debugger = _Mock()

test_import_excolors = _Mock()

test_import_fakemodule = _Mock()

test_import_getipython = _Mock()

test_import_history = _Mock()

test_import_hooks = _Mock()

test_import_interactiveshell = _Mock()

test_import_logger = _Mock()

test_import_macro = _Mock()

test_import_magic = _Mock()

test_import_oinspect = _Mock()

test_import_prefilter = _Mock()

test_import_prompts = _Mock()

test_import_release = _Mock()

test_import_shadowns = _Mock()

test_import_ultratb = _Mock()

test_import_usage = _Mock()





