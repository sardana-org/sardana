from __future__ import print_function
from _mock import _Mock

page = __import__('IPython.core.page', fromlist=['page'])


io = _Mock()

test_detect_screen_size = _Mock()





