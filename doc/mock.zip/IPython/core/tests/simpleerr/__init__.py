from __future__ import print_function
from _mock import _Mock




bar = _Mock()

div0 = _Mock()

sys = _Mock()

sysexit = _Mock()





