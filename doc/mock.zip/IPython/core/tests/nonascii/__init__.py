from __future__ import print_function
from _mock import _Mock




unicode_literals = _Mock()

u = u'\u040e\u0442\u2116\u0424'



