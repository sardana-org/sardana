from __future__ import print_function
from _mock import _Mock




print_function = _Mock()

sys = _Mock()



class C(_Mock):
  pass


