from __future__ import print_function
from _mock import _Mock

dec = __import__('IPython.testing.decorators', fromlist=['decorators'])
tt = __import__('IPython.testing.tools', fromlist=['tools'])


unittest = _Mock()



class TestFileToRun(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

