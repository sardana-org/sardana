from __future__ import print_function
from _mock import _Mock




absolute_import = _Mock()

join = _Mock()

magic_run_completer = _Mock()

module_completion = _Mock()

os = _Mock()

shutil = _Mock()

sys = _Mock()

tempfile = _Mock()

unittest = _Mock()



class MockEvent(_Mock):
  pass


class TemporaryDirectory(_Mock):
  pass


class Test_magic_run_completer(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

