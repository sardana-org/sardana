from __future__ import print_function
from _mock import _Mock




default_aliases = _Mock()

error = _Mock()

keyword = _Mock()

os = _Mock()

re = _Mock()

shell_line_split = _Mock()

split_user_input = _Mock()

sys = _Mock()

warn = _Mock()



class AliasError(_Mock):
  pass


class AliasManager(_Mock):
  pass


class Configurable(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class InvalidAliasError(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

