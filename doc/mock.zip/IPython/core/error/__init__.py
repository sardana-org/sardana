from __future__ import print_function
from _mock import _Mock








class IPythonCoreError(_Mock):
  pass


class StdinNotImplementedError(_Mock):
  pass


class TryNext(_Mock):
  pass


class UsageError(_Mock):
  pass


