from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


print_function = _Mock()

publish_display_data = _Mock()



class Configurable(_Mock):
  pass


class DisplayPublisher(_Mock):
  pass


