from __future__ import print_function
from _mock import _Mock




sys = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class Configurable(_Mock):
  pass


class DisplayTrap(_Mock):
  pass


