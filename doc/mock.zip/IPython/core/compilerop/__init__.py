from __future__ import print_function
from _mock import _Mock




check_linecache_ipython = _Mock()

code_name = _Mock()

codeop = _Mock()

functools = _Mock()

hashlib = _Mock()

linecache = _Mock()

operator = _Mock()

print_function = _Mock()

time = _Mock()

PyCF_MASK = 253968

PyCF_ONLY_AST = 1024

class CachingCompiler(_Mock):
  pass


