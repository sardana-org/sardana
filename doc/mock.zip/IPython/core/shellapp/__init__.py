from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
pylabtools = __import__('IPython.core.pylabtools', fromlist=['pylabtools'])


absolute_import = _Mock()

addflag = _Mock()

backend_keys = _Mock()

boolean_flag = _Mock()

filefind = _Mock()

glob = _Mock()

nosep_config = _Mock()

os = _Mock()

shell_aliases = _Mock()

shell_flags = _Mock()

sys = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CaselessStrEnum(_Mock):
  pass
  info_text = 'any value'

class Config(_Mock):
  pass


class Configurable(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class InteractiveShellApp(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class preserve_keys(_Mock):
  pass


