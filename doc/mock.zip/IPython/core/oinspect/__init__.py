from __future__ import print_function
from _mock import _Mock

PyColorize = __import__('IPython.utils.PyColorize', fromlist=['PyColorize'])
io = __import__('IPython.utils.io', fromlist=['io'])
openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])
page = __import__('IPython.core.page', fromlist=['page'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


InspectColors = _Mock()

LightBGColors = _Mock()

LinuxColors = _Mock()

NoColor = _Mock()

call_tip = _Mock()

cast_unicode = _Mock()

find_file = _Mock()

find_source_lines = _Mock()

format_argspec = _Mock()

get_encoding = _Mock()

getargspec = _Mock()

getdoc = _Mock()

getsource = _Mock()

indent = _Mock()

info_fields = _Mock()

inspect = _Mock()

linecache = _Mock()

list_namespace = _Mock()

object_info = _Mock()

os = _Mock()

print_function = _Mock()

safe_hasattr = _Mock()

skip_doctest_py3 = _Mock()

stdlib_io = _Mock()

types = _Mock()



class ColorScheme(_Mock):
  pass


class ColorSchemeTable(_Mock):
  pass


class Colors(_Mock):
  pass
  Black = '\x1b[0;30m'
  BlinkBlack = '\x1b[5;30m'
  BlinkBlue = '\x1b[5;34m'
  BlinkCyan = '\x1b[5;36m'
  BlinkGreen = '\x1b[5;32m'
  BlinkLightGray = '\x1b[5;37m'
  BlinkPurple = '\x1b[5;35m'
  BlinkRed = '\x1b[5;31m'
  BlinkYellow = '\x1b[5;33m'
  Blue = '\x1b[0;34m'
  Brown = '\x1b[0;33m'
  Cyan = '\x1b[0;36m'
  DarkGray = '\x1b[1;30m'
  Green = '\x1b[0;32m'
  LightBlue = '\x1b[1;34m'
  LightCyan = '\x1b[1;36m'
  LightGray = '\x1b[0;37m'
  LightGreen = '\x1b[1;32m'
  LightPurple = '\x1b[1;35m'
  LightRed = '\x1b[1;31m'
  NoColor = ''
  Normal = '\x1b[0m'
  Purple = '\x1b[0;35m'
  Red = '\x1b[0;31m'
  White = '\x1b[1;37m'
  Yellow = '\x1b[1;33m'
  _base = '\x1b[%sm'

class InputTermColors(_Mock):
  pass
  Black = '\x01\x1b[0;30m\x02'
  BlinkBlack = '\x01\x1b[5;30m\x02'
  BlinkBlue = '\x01\x1b[5;34m\x02'
  BlinkCyan = '\x01\x1b[5;36m\x02'
  BlinkGreen = '\x01\x1b[5;32m\x02'
  BlinkLightGray = '\x01\x1b[5;37m\x02'
  BlinkPurple = '\x01\x1b[5;35m\x02'
  BlinkRed = '\x01\x1b[5;31m\x02'
  BlinkYellow = '\x01\x1b[5;33m\x02'
  Blue = '\x01\x1b[0;34m\x02'
  Brown = '\x01\x1b[0;33m\x02'
  Cyan = '\x01\x1b[0;36m\x02'
  DarkGray = '\x01\x1b[1;30m\x02'
  Green = '\x01\x1b[0;32m\x02'
  LightBlue = '\x01\x1b[1;34m\x02'
  LightCyan = '\x01\x1b[1;36m\x02'
  LightGray = '\x01\x1b[0;37m\x02'
  LightGreen = '\x01\x1b[1;32m\x02'
  LightPurple = '\x01\x1b[1;35m\x02'
  LightRed = '\x01\x1b[1;31m\x02'
  NoColor = ''
  Normal = '\x01\x1b[0m\x02'
  Purple = '\x01\x1b[0;35m\x02'
  Red = '\x01\x1b[0;31m\x02'
  White = '\x01\x1b[1;37m\x02'
  Yellow = '\x01\x1b[1;33m\x02'
  _base = '\x01\x1b[%sm\x02'

class Inspector(_Mock):
  pass


class TermColors(_Mock):
  pass
  Black = '\x1b[0;30m'
  BlinkBlack = '\x1b[5;30m'
  BlinkBlue = '\x1b[5;34m'
  BlinkCyan = '\x1b[5;36m'
  BlinkGreen = '\x1b[5;32m'
  BlinkLightGray = '\x1b[5;37m'
  BlinkPurple = '\x1b[5;35m'
  BlinkRed = '\x1b[5;31m'
  BlinkYellow = '\x1b[5;33m'
  Blue = '\x1b[0;34m'
  Brown = '\x1b[0;33m'
  Cyan = '\x1b[0;36m'
  DarkGray = '\x1b[1;30m'
  Green = '\x1b[0;32m'
  LightBlue = '\x1b[1;34m'
  LightCyan = '\x1b[1;36m'
  LightGray = '\x1b[0;37m'
  LightGreen = '\x1b[1;32m'
  LightPurple = '\x1b[1;35m'
  LightRed = '\x1b[1;31m'
  NoColor = ''
  Normal = '\x1b[0m'
  Purple = '\x1b[0;35m'
  Red = '\x1b[0;31m'
  White = '\x1b[1;37m'
  Yellow = '\x1b[1;33m'
  _base = '\x1b[%sm'

class izip_longest(_Mock):
  pass


