from __future__ import print_function
from _mock import _Mock

pretty = __import__('IPython.lib.pretty', fromlist=['pretty'])


abc = _Mock()

format_display_data = _Mock()

sys = _Mock()

unicode_to_str = _Mock()

warnings = _Mock()



class BaseFormatter(_Mock):
  pass


class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CUnicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class DisplayFormatter(_Mock):
  pass


class FormatterABC(_Mock):
  pass
  _abc_negative_cache_version = 23
  enabled = True
  format_type = 'text/plain'

class HTMLFormatter(_Mock):
  pass


class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class JPEGFormatter(_Mock):
  pass


class JSONFormatter(_Mock):
  pass


class JavascriptFormatter(_Mock):
  pass


class LatexFormatter(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class ObjectName(_Mock):
  pass
  info_text = 'a valid object identifier in Python'

class PNGFormatter(_Mock):
  pass


class PlainTextFormatter(_Mock):
  pass


class SVGFormatter(_Mock):
  pass


class StringIO(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

