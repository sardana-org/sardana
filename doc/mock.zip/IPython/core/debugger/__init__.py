from __future__ import print_function
from _mock import _Mock

PyColorize = __import__('IPython.utils.PyColorize', fromlist=['PyColorize'])
coloransi = __import__('IPython.utils.coloransi', fromlist=['coloransi'])
io = __import__('IPython.utils.io', fromlist=['io'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
ulinecache = __import__('IPython.utils.ulinecache', fromlist=['ulinecache'])


BdbQuit_IPython_excepthook = _Mock()

BdbQuit_excepthook = _Mock()

_file_lines = _Mock()

bdb = _Mock()

decorate_fn_with_doc = _Mock()

exception_colors = _Mock()

functools = _Mock()

get_ipython = _Mock()

linecache = _Mock()

print_function = _Mock()

sys = _Mock()

has_pydb = _Mock()

prompt = 'ipdb> '

class OldPdb(_Mock):
  pass
  doc_header = 'Documented commands (type help <topic>):'
  doc_leader = ''
  identchars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'
  lastcmd = ''
  misc_header = 'Miscellaneous help topics:'
  nohelp = '*** No help on %s'
  prompt = '(Cmd) '
  ruler = '='
  undoc_header = 'Undocumented commands:'
  use_rawinput = 1

class Pdb(_Mock):
  pass
  doc_header = 'Documented commands (type help <topic>):'
  doc_leader = ''
  identchars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'
  lastcmd = ''
  misc_header = 'Miscellaneous help topics:'
  nohelp = '*** No help on %s'
  prompt = '(Cmd) '
  ruler = '='
  undoc_header = 'Undocumented commands:'
  use_rawinput = 1

class Tracer(_Mock):
  pass


