from __future__ import print_function
from _mock import _Mock




clipboard_get = _Mock()

editor = _Mock()

fix_error_editor = _Mock()

input_prefilter = _Mock()

late_startup_hook = _Mock()

os = _Mock()

pre_prompt_hook = _Mock()

pre_run_code_hook = _Mock()

show_in_pager = _Mock()

shutdown_hook = _Mock()

subprocess = _Mock()

synchronize_with_editor = _Mock()

sys = _Mock()

tempfile = _Mock()



class CommandChainDispatcher(_Mock):
  pass


class TryNext(_Mock):
  pass


