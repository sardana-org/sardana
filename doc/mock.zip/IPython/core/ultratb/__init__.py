from __future__ import print_function
from _mock import _Mock

PyColorize = __import__('IPython.utils.PyColorize', fromlist=['PyColorize'])
debugger = __import__('IPython.core.debugger', fromlist=['debugger'])
io = __import__('IPython.utils.io', fromlist=['io'])
openpy = __import__('IPython.utils.openpy', fromlist=['openpy'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
ulinecache = __import__('IPython.utils.ulinecache', fromlist=['ulinecache'])
util_path = __import__('IPython.utils.path', fromlist=['path'])


_fixed_getinnerframes = _Mock()

_format_traceback_lines = _Mock()

_parser = _Mock()

error = _Mock()

exception_colors = _Mock()

findsource = _Mock()

fix_frame_records_filenames = _Mock()

generate_tokens = _Mock()

get_ipython = _Mock()

getfile = _Mock()

getmodule = _Mock()

getsourcefile = _Mock()

info = _Mock()

inspect = _Mock()

inspect_error = _Mock()

isclass = _Mock()

iscode = _Mock()

isframe = _Mock()

isfunction = _Mock()

ismethod = _Mock()

ismodule = _Mock()

istraceback = _Mock()

keyword = _Mock()

linecache = _Mock()

os = _Mock()

pydoc = _Mock()

re = _Mock()

sys = _Mock()

time = _Mock()

tokenize = _Mock()

traceback = _Mock()

types = _Mock()

unicode_literals = _Mock()

uniq_stable = _Mock()

DEFAULT_SCHEME = u'NoColor'

INDENT_SIZE = 8

class AutoFormattedTB(_Mock):
  pass
  tb_offset = 0

class ColorTB(_Mock):
  pass
  tb_offset = 0

class DisplayTrap(_Mock):
  pass


class FormattedTB(_Mock):
  pass
  tb_offset = 0

class ListTB(_Mock):
  pass
  tb_offset = 0

class SyntaxTB(_Mock):
  pass
  tb_offset = 0

class TBTools(_Mock):
  pass
  tb_offset = 0

class VerboseTB(_Mock):
  pass
  tb_offset = 0

