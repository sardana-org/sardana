from __future__ import print_function
from _mock import _Mock




_default_checkers = _Mock()

_default_handlers = _Mock()

_default_transformers = _Mock()

is_shadowed = _Mock()

re = _Mock()

re_exclude_auto = _Mock()

re_fun_name = _Mock()

ESC_MAGIC = '%'

ESC_PAREN = '/'

ESC_QUOTE = ','

ESC_QUOTE2 = ';'

class AliasChecker(_Mock):
  pass


class AliasHandler(_Mock):
  pass


class AssignmentChecker(_Mock):
  pass


class AutoHandler(_Mock):
  pass


class AutoMagicChecker(_Mock):
  pass


class AutocallChecker(_Mock):
  pass


class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class CRegExp(_Mock):
  pass
  info_text = 'a regular expression'

class Configurable(_Mock):
  pass


class EmacsChecker(_Mock):
  pass


class EmacsHandler(_Mock):
  pass


class IPyAutocall(_Mock):
  pass
  rewrite = True

class IPyAutocallChecker(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class LineInfo(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class Macro(_Mock):
  pass


class MacroChecker(_Mock):
  pass


class MacroHandler(_Mock):
  pass


class MagicHandler(_Mock):
  pass


class PrefilterChecker(_Mock):
  pass


class PrefilterError(_Mock):
  pass


class PrefilterHandler(_Mock):
  pass


class PrefilterManager(_Mock):
  pass


class PrefilterTransformer(_Mock):
  pass


class PythonOpsChecker(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

