from __future__ import print_function
from _mock import _Mock




_format_lineno = _Mock()

atexit = _Mock()

catch_corrupt_db = _Mock()

datetime = _Mock()

decorator = _Mock()

extract_hist_ranges = _Mock()

locate_profile = _Mock()

needs_sqlite = _Mock()

os = _Mock()

print_function = _Mock()

range_re = _Mock()

re = _Mock()

sqlite3 = _Mock()

threading = _Mock()

warn = _Mock()



class Any(_Mock):
  pass
  info_text = 'any value'

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Configurable(_Mock):
  pass


class DatabaseError(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class DummyDB(_Mock):
  pass


class HistoryAccessor(_Mock):
  pass


class HistoryManager(_Mock):
  pass


class HistorySavingThread(_Mock):
  pass
  _Thread__initialized = False
  daemon = True
  enabled = True
  stop_now = False

class Instance(_Mock):
  pass
  info_text = 'any value'

class Integer(_Mock):
  pass
  default_value = 0
  info_text = 'an integer'

class List(_Mock):
  pass
  info_text = 'any value'

class TraitError(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

