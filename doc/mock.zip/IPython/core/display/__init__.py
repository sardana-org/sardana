from __future__ import print_function
from _mock import _Mock




_display_mimetype = _Mock()

_jpegxy = _Mock()

_merge = _Mock()

_pngxy = _Mock()

_safe_exists = _Mock()

cast_bytes_py2 = _Mock()

cast_unicode = _Mock()

clear_output = _Mock()

display = _Mock()

display_html = _Mock()

display_javascript = _Mock()

display_jpeg = _Mock()

display_json = _Mock()

display_latex = _Mock()

display_png = _Mock()

display_pretty = _Mock()

display_svg = _Mock()

os = _Mock()

print_function = _Mock()

publish_display_data = _Mock()

string_types = _Mock()

struct = _Mock()

_JPEG = '\xff\xd8'

_PNG = '\x89PNG\r\n\x1a\n'

css_t = '$("head").append($("<link/>").attr({\n  rel:  "stylesheet",\n  type: "text/css",\n  href: "%s"\n}));\n'

lib_t1 = '$.getScript("%s", function () {\n'

lib_t2 = '});\n'

class DisplayObject(_Mock):
  pass
  _read_flags = 'r'

class HTML(_Mock):
  pass
  _read_flags = 'r'

class Image(_Mock):
  pass
  _FMT_JPEG = u'jpeg'
  _FMT_PNG = u'png'
  _read_flags = 'rb'

class JSON(_Mock):
  pass
  _read_flags = 'r'

class Javascript(_Mock):
  pass
  _read_flags = 'r'

class Latex(_Mock):
  pass
  _read_flags = 'r'

class Math(_Mock):
  pass
  _read_flags = 'r'

class Pretty(_Mock):
  pass
  _read_flags = 'r'

class SVG(_Mock):
  pass
  _read_flags = 'r'

