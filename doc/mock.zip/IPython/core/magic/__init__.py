from __future__ import print_function
from _mock import _Mock

oinspect = __import__('IPython.core.oinspect', fromlist=['oinspect'])


_function_magic_marker = _Mock()

_method_magic_marker = _Mock()

arg_split = _Mock()

cell_magic = _Mock()

compress_dhist = _Mock()

decorator = _Mock()

dedent = _Mock()

error = _Mock()

getopt = _Mock()

line_cell_magic = _Mock()

line_magic = _Mock()

magic_escapes = _Mock()

magic_kinds = _Mock()

magic_spec = _Mock()

magics = _Mock()

magics_class = _Mock()

needs_local_scope = _Mock()

on_off = _Mock()

os = _Mock()

re = _Mock()

record_magic = _Mock()

register_cell_magic = _Mock()

register_line_cell_magic = _Mock()

register_line_magic = _Mock()

sys = _Mock()

types = _Mock()

validate_type = _Mock()

ESC_MAGIC = '%'

ESC_MAGIC2 = '%%'

_docstring_template = "Decorate the given {0} as {1} magic.\n\nThe decorator can be used with or without arguments, as follows.\n\ni) without arguments: it will create a {1} magic named as the {0} being\ndecorated::\n\n    @deco\n    def foo(...)\n\nwill create a {1} magic named `foo`.\n\nii) with one string argument: which will be used as the actual name of the\nresulting magic::\n\n    @deco('bar')\n    def foo(...)\n\nwill create a {1} magic named `bar`.\n"

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Bunch(_Mock):
  pass


class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class GetoptError(_Mock):
  pass
  msg = ''
  opt = ''

class Instance(_Mock):
  pass
  info_text = 'any value'

class MagicAlias(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class MagicsManager(_Mock):
  pass


class MetaHasTraits(_Mock):
  pass


class Struct(_Mock):
  pass
  _allownew = True

class UsageError(_Mock):
  pass


