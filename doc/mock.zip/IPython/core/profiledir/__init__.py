from __future__ import print_function
from _mock import _Mock




expand_path = _Mock()

get_ipython_package_dir = _Mock()

os = _Mock()

shutil = _Mock()



class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class LoggingConfigurable(_Mock):
  pass


class ProfileDir(_Mock):
  pass


class ProfileDirError(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

