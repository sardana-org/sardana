from __future__ import print_function
from _mock import _Mock




arg_split = _Mock()

cd_completer = _Mock()

compress_user = _Mock()

expand_user = _Mock()

get_ipython = _Mock()

get_root_modules = _Mock()

glob = _Mock()

imp = _Mock()

import_re = _Mock()

inspect = _Mock()

is_importable = _Mock()

magic_run_completer = _Mock()

magic_run_re = _Mock()

module_completer = _Mock()

module_completion = _Mock()

module_list = _Mock()

os = _Mock()

print_function = _Mock()

quick_completer = _Mock()

re = _Mock()

reset_completer = _Mock()

sys = _Mock()

time = _Mock()

try_import = _Mock()

TIMEOUT_GIVEUP = 20

TIMEOUT_STORAGE = 2

class TryNext(_Mock):
  pass


class zipimporter(_Mock):
  pass


