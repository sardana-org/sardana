from __future__ import print_function
from _mock import _Mock




ExceptionColors = _Mock()

exception_colors = _Mock()



class ColorScheme(_Mock):
  pass


class ColorSchemeTable(_Mock):
  pass


class TermColors(_Mock):
  pass
  Black = '\x1b[0;30m'
  BlinkBlack = '\x1b[5;30m'
  BlinkBlue = '\x1b[5;34m'
  BlinkCyan = '\x1b[5;36m'
  BlinkGreen = '\x1b[5;32m'
  BlinkLightGray = '\x1b[5;37m'
  BlinkPurple = '\x1b[5;35m'
  BlinkRed = '\x1b[5;31m'
  BlinkYellow = '\x1b[5;33m'
  Blue = '\x1b[0;34m'
  Brown = '\x1b[0;33m'
  Cyan = '\x1b[0;36m'
  DarkGray = '\x1b[1;30m'
  Green = '\x1b[0;32m'
  LightBlue = '\x1b[1;34m'
  LightCyan = '\x1b[1;36m'
  LightGray = '\x1b[0;37m'
  LightGreen = '\x1b[1;32m'
  LightPurple = '\x1b[1;35m'
  LightRed = '\x1b[1;31m'
  NoColor = ''
  Normal = '\x1b[0m'
  Purple = '\x1b[0;35m'
  Red = '\x1b[0;31m'
  White = '\x1b[1;37m'
  Yellow = '\x1b[1;33m'
  _base = '\x1b[%sm'

