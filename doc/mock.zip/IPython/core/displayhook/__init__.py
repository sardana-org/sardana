from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


print_function = _Mock()

sys = _Mock()

warn = _Mock()



class Configurable(_Mock):
  pass


class DisplayHook(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

