from __future__ import print_function
from _mock import _Mock

magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])
page = __import__('IPython.core.page', fromlist=['page'])


dedent = _Mock()

error = _Mock()

format_screen = _Mock()

indent = _Mock()

io = _Mock()

json = _Mock()

line_magic = _Mock()

magic_escapes = _Mock()

magics_class = _Mock()

pformat = _Mock()

print_function = _Mock()

skip_doctest = _Mock()

sys = _Mock()

unquote_filename = _Mock()

warn = _Mock()



class BasicMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

class MagicsDisplay(_Mock):
  pass


class Struct(_Mock):
  pass
  _allownew = True

class UsageError(_Mock):
  pass


