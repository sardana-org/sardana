from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])


_unspecified = _Mock()

io_open = _Mock()

line_magic = _Mock()

magics_class = _Mock()

os = _Mock()

parse_argstring = _Mock()

print_function = _Mock()

skip_doctest = _Mock()



class HistoryMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

class StdinNotImplementedError(_Mock):
  pass


class argument(_Mock):
  pass
  _method_name = 'add_argument'

class magic_arguments(_Mock):
  pass


