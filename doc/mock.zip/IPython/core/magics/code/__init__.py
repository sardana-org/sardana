from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


find_file = _Mock()

find_source_lines = _Mock()

get_py_filename = _Mock()

inspect = _Mock()

io = _Mock()

ipython_input_pat = _Mock()

line_magic = _Mock()

magics_class = _Mock()

os = _Mock()

re = _Mock()

skip_doctest = _Mock()

sys = _Mock()

unquote_filename = _Mock()

warn = _Mock()



class CodeMagics(_Mock):
  pass
  registered = True

class InteractivelyDefined(_Mock):
  pass


class Macro(_Mock):
  pass


class MacroToEdit(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class StdinNotImplementedError(_Mock):
  pass


class TryNext(_Mock):
  pass


class UsageError(_Mock):
  pass


class preserve_keys(_Mock):
  pass


