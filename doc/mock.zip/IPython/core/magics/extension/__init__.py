from __future__ import print_function
from _mock import _Mock




line_magic = _Mock()

magics_class = _Mock()

os = _Mock()



class ExtensionMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

class UsageError(_Mock):
  pass


