from __future__ import print_function
from _mock import _Mock

magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


arg_split = _Mock()

atexit = _Mock()

cell_magic = _Mock()

errno = _Mock()

line_magic = _Mock()

magics_class = _Mock()

os = _Mock()

script_args = _Mock()

signal = _Mock()

sys = _Mock()

time = _Mock()

PIPE = -1

class BackgroundJobManager(_Mock):
  pass


class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class List(_Mock):
  pass
  info_text = 'any value'

class Magics(_Mock):
  pass
  registered = False

class Popen(_Mock):
  pass


class ScriptMagics(_Mock):
  pass
  registered = True

