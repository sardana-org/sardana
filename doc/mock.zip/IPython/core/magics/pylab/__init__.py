from __future__ import print_function
from _mock import _Mock

magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])


backends = _Mock()

line_magic = _Mock()

magic_gui_arg = _Mock()

magics_class = _Mock()

skip_doctest = _Mock()

warn = _Mock()



class Application(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class PylabMagics(_Mock):
  pass
  registered = True

