from __future__ import print_function
from _mock import _Mock

page = __import__('IPython.core.page', fromlist=['page'])


gc = _Mock()

get_py_filename = _Mock()

line_magic = _Mock()

magics_class = _Mock()

re = _Mock()

read_py_file = _Mock()

skip_doctest = _Mock()

sys = _Mock()

DEFAULT_ENCODING = 'UTF-8'

class Magics(_Mock):
  pass
  registered = False

class NamespaceMagics(_Mock):
  pass
  registered = True

class StdinNotImplementedError(_Mock):
  pass


class UsageError(_Mock):
  pass


