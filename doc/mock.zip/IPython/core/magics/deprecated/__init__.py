from __future__ import print_function
from _mock import _Mock




line_magic = _Mock()

magics_class = _Mock()



class DeprecatedMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

