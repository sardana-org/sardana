from __future__ import print_function
from _mock import _Mock




cell_magic = _Mock()

display = _Mock()

magics_class = _Mock()



class DisplayMagics(_Mock):
  pass
  registered = True

class HTML(_Mock):
  pass
  _read_flags = 'r'

class Javascript(_Mock):
  pass
  _read_flags = 'r'

class Latex(_Mock):
  pass
  _read_flags = 'r'

class Magics(_Mock):
  pass
  registered = False

class SVG(_Mock):
  pass
  _read_flags = 'r'

