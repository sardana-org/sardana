from __future__ import print_function
from _mock import _Mock




line_magic = _Mock()

magics_class = _Mock()

os = _Mock()

str_to_unicode = _Mock()

sys = _Mock()

warn = _Mock()



class LoggingMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

