from __future__ import print_function
from _mock import _Mock

magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])
oinspect = __import__('IPython.core.oinspect', fromlist=['oinspect'])
page = __import__('IPython.core.page', fromlist=['page'])


abbrev_cwd = _Mock()

cell_magic = _Mock()

compress_dhist = _Mock()

io = _Mock()

line_cell_magic = _Mock()

line_magic = _Mock()

magics_class = _Mock()

os = _Mock()

pformat = _Mock()

re = _Mock()

set_term_title = _Mock()

skip_doctest = _Mock()

source_to_unicode = _Mock()

sys = _Mock()

unquote_filename = _Mock()



class Magics(_Mock):
  pass
  registered = False

class OSMagics(_Mock):
  pass
  registered = True

class UsageError(_Mock):
  pass


