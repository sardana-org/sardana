from __future__ import print_function
from _mock import _Mock




error = _Mock()

line_magic = _Mock()

magics_class = _Mock()

re = _Mock()

reg = _Mock()



class ConfigMagics(_Mock):
  pass
  registered = True

class Magics(_Mock):
  pass
  registered = False

class UsageError(_Mock):
  pass


