from __future__ import print_function
from _mock import _Mock

debugger = __import__('IPython.core.debugger', fromlist=['debugger'])
magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])
oinspect = __import__('IPython.core.oinspect', fromlist=['oinspect'])
page = __import__('IPython.core.page', fromlist=['page'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_format_time = _Mock()

ast = _Mock()

bdb = _Mock()

builtin_mod = _Mock()

cell_magic = _Mock()

clock = _Mock()

clock2 = _Mock()

error = _Mock()

find_mod = _Mock()

get_py_filename = _Mock()

line_cell_magic = _Mock()

line_magic = _Mock()

magics_class = _Mock()

needs_local_scope = _Mock()

on_off = _Mock()

os = _Mock()

parse_breakpoint = _Mock()

profile = _Mock()

pstats = _Mock()

shellglob = _Mock()

skip_doctest = _Mock()

sys = _Mock()

time = _Mock()

unquote_filename = _Mock()

warn = _Mock()



class ExecutionMagics(_Mock):
  pass
  registered = True

class Macro(_Mock):
  pass


class Magics(_Mock):
  pass
  registered = False

class StringIO(_Mock):
  pass


class Struct(_Mock):
  pass
  _allownew = True

class UsageError(_Mock):
  pass


class capture_output(_Mock):
  pass
  stderr = True
  stdout = True

class preserve_keys(_Mock):
  pass


