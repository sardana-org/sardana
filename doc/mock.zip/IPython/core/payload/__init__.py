from __future__ import print_function
from _mock import _Mock








class Configurable(_Mock):
  pass


class List(_Mock):
  pass
  info_text = 'any value'

class PayloadManager(_Mock):
  pass


