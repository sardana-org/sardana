from __future__ import print_function
from _mock import _Mock




copyfile = _Mock()

os = _Mock()

sys = _Mock()

PY3 = _Mock()

class Configurable(_Mock):
  pass


class ExtensionManager(_Mock):
  pass


class Instance(_Mock):
  pass
  info_text = 'any value'

