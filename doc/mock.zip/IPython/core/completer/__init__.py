from __future__ import print_function
from _mock import _Mock

generics = __import__('IPython.utils.generics', fromlist=['generics'])
io = __import__('IPython.utils.io', fromlist=['io'])


arg_split = _Mock()

compress_user = _Mock()

dir2 = _Mock()

expand_user = _Mock()

get__all__entries = _Mock()

glob = _Mock()

has_open_quotes = _Mock()

inspect = _Mock()

itertools = _Mock()

keyword = _Mock()

os = _Mock()

protect_filename = _Mock()

re = _Mock()

sys = _Mock()

DELIMS = ' \t\n`!@#$^&*()=+[{]}\\|;:\'",<>?'

ESC_MAGIC = '%'

GREEDY_DELIMS = ' =\r\n'

PROTECTABLES = ' ()[]{}?=\\|;:\'#*"^&'

class Bunch(_Mock):
  pass


class CBool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Completer(_Mock):
  pass


class CompletionSplitter(_Mock):
  pass
  _delims = ' \t\n`!@#$^&*()=+[{]}\\|;:\'",<>?'

class Configurable(_Mock):
  pass


class Enum(_Mock):
  pass
  info_text = 'any value'

class IPCompleter(_Mock):
  pass


class TryNext(_Mock):
  pass


