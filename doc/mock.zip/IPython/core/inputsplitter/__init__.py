from __future__ import print_function
from _mock import _Mock




ESC_SEQUENCES = _Mock()

assemble_logical_lines = _Mock()

assign_from_magic = _Mock()

assign_from_system = _Mock()

ast = _Mock()

cast_unicode = _Mock()

cellmagic = _Mock()

classic_prompt = _Mock()

codeop = _Mock()

comment_line_re = _Mock()

dedent_re = _Mock()

escaped_commands = _Mock()

get_input_encoding = _Mock()

help_end = _Mock()

ini_spaces_re = _Mock()

ipy_prompt = _Mock()

last_blank = _Mock()

last_two_blanks = _Mock()

last_two_blanks_re = _Mock()

last_two_blanks_re2 = _Mock()

leading_indent = _Mock()

num_ini_spaces = _Mock()

re = _Mock()

remove_comments = _Mock()

strip_encoding_cookie = _Mock()

sys = _Mock()

ESC_HELP = '?'

ESC_HELP2 = '??'

ESC_MAGIC = '%'

ESC_MAGIC2 = '%%'

ESC_PAREN = '/'

ESC_QUOTE = ','

ESC_QUOTE2 = ';'

ESC_SHELL = '!'

ESC_SH_CAP = '!!'

class IPythonInputSplitter(_Mock):
  pass
  _full_dedent = False
  encoding = ''
  indent_spaces = 0
  source = ''
  source_raw = ''
  transformer_accumulating = False
  within_python_line = False

class InputSplitter(_Mock):
  pass
  _full_dedent = False
  encoding = ''
  indent_spaces = 0
  source = ''

class assemble_python_lines(_Mock):
  pass
  _abc_negative_cache_version = 22

