from __future__ import print_function
from _mock import _Mock

argparse = __import__('IPython.external.argparse', fromlist=['argparse'])


arg_split = _Mock()

construct_parser = _Mock()

dedent = _Mock()

parse_argstring = _Mock()

real_name = _Mock()



class ArgDecorator(_Mock):
  pass


class ArgMethodWrapper(_Mock):
  pass


class MagicArgumentParser(_Mock):
  pass


class MagicHelpFormatter(_Mock):
  pass


class UsageError(_Mock):
  pass


class argument(_Mock):
  pass
  _method_name = 'add_argument'

class argument_group(_Mock):
  pass


class defaults(_Mock):
  pass
  _method_name = 'set_defaults'

class kwds(_Mock):
  pass


class magic_arguments(_Mock):
  pass


