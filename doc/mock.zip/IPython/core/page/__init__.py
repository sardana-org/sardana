from __future__ import print_function
from _mock import _Mock

io = __import__('IPython.utils.io', fromlist=['io'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


_detect_screen_size = _Mock()

chop = _Mock()

esc_re = _Mock()

get_ipython = _Mock()

get_pager_cmd = _Mock()

get_pager_start = _Mock()

get_terminal_size = _Mock()

orig_page = _Mock()

os = _Mock()

page = _Mock()

page_dumb = _Mock()

page_file = _Mock()

page_more = _Mock()

print_function = _Mock()

re = _Mock()

snip_print = _Mock()

sys = _Mock()

system = _Mock()

tempfile = _Mock()



class TryNext(_Mock):
  pass


class UnsupportedOperation(_Mock):
  pass


