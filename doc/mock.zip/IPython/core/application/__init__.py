from __future__ import print_function
from _mock import _Mock

crashhandler = __import__('IPython.core.crashhandler', fromlist=['crashhandler'])
release = __import__('IPython.core.release', fromlist=['release'])


atexit = _Mock()

base_aliases = _Mock()

base_flags = _Mock()

catch_config_error = _Mock()

get_ipython_dir = _Mock()

get_ipython_package_dir = _Mock()

glob = _Mock()

logging = _Mock()

os = _Mock()

shutil = _Mock()

sys = _Mock()



class Application(_Mock):
  pass


class BaseIPythonApplication(_Mock):
  pass
  _in_init_profile_dir = False

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class ConfigFileNotFound(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Instance(_Mock):
  pass
  info_text = 'any value'

class List(_Mock):
  pass
  info_text = 'any value'

class ProfileDir(_Mock):
  pass


class ProfileDirError(_Mock):
  pass


class Set(_Mock):
  pass
  info_text = 'any value'

class Type(_Mock):
  pass
  info_text = 'any value'

class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

