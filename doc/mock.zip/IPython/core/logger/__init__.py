from __future__ import print_function
from _mock import _Mock




glob = _Mock()

io = _Mock()

os = _Mock()

str_to_unicode = _Mock()

time = _Mock()



class Logger(_Mock):
  pass


