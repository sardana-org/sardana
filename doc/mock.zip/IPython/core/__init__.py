from __future__ import print_function
from _mock import _Mock

alias = __import__('IPython.core.alias', fromlist=['alias'])
application = __import__('IPython.core.application', fromlist=['application'])
autocall = __import__('IPython.core.autocall', fromlist=['autocall'])
builtin_trap = __import__('IPython.core.builtin_trap', fromlist=['builtin_trap'])
compilerop = __import__('IPython.core.compilerop', fromlist=['compilerop'])
completer = __import__('IPython.core.completer', fromlist=['completer'])
crashhandler = __import__('IPython.core.crashhandler', fromlist=['crashhandler'])
debugger = __import__('IPython.core.debugger', fromlist=['debugger'])
display = __import__('IPython.core.display', fromlist=['display'])
display_trap = __import__('IPython.core.display_trap', fromlist=['display_trap'])
displayhook = __import__('IPython.core.displayhook', fromlist=['displayhook'])
displaypub = __import__('IPython.core.displaypub', fromlist=['displaypub'])
error = __import__('IPython.core.error', fromlist=['error'])
excolors = __import__('IPython.core.excolors', fromlist=['excolors'])
extensions = __import__('IPython.core.extensions', fromlist=['extensions'])
fakemodule = __import__('IPython.core.fakemodule', fromlist=['fakemodule'])
formatters = __import__('IPython.core.formatters', fromlist=['formatters'])
getipython = __import__('IPython.core.getipython', fromlist=['getipython'])
history = __import__('IPython.core.history', fromlist=['history'])
hooks = __import__('IPython.core.hooks', fromlist=['hooks'])
inputsplitter = __import__('IPython.core.inputsplitter', fromlist=['inputsplitter'])
inputtransformer = __import__('IPython.core.inputtransformer', fromlist=['inputtransformer'])
interactiveshell = __import__('IPython.core.interactiveshell', fromlist=['interactiveshell'])
logger = __import__('IPython.core.logger', fromlist=['logger'])
macro = __import__('IPython.core.macro', fromlist=['macro'])
magic = __import__('IPython.core.magic', fromlist=['magic'])
magic_arguments = __import__('IPython.core.magic_arguments', fromlist=['magic_arguments'])
magics = __import__('IPython.core.magics', fromlist=['magics'])
oinspect = __import__('IPython.core.oinspect', fromlist=['oinspect'])
page = __import__('IPython.core.page', fromlist=['page'])
payload = __import__('IPython.core.payload', fromlist=['payload'])
payloadpage = __import__('IPython.core.payloadpage', fromlist=['payloadpage'])
prefilter = __import__('IPython.core.prefilter', fromlist=['prefilter'])
profiledir = __import__('IPython.core.profiledir', fromlist=['profiledir'])
prompts = __import__('IPython.core.prompts', fromlist=['prompts'])
pylabtools = __import__('IPython.core.pylabtools', fromlist=['pylabtools'])
release = __import__('IPython.core.release', fromlist=['release'])
shadowns = __import__('IPython.core.shadowns', fromlist=['shadowns'])
shellapp = __import__('IPython.core.shellapp', fromlist=['shellapp'])
splitinput = __import__('IPython.core.splitinput', fromlist=['splitinput'])
ultratb = __import__('IPython.core.ultratb', fromlist=['ultratb'])
usage = __import__('IPython.core.usage', fromlist=['usage'])








