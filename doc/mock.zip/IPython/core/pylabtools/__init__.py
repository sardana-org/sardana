from __future__ import print_function
from _mock import _Mock




_pngxy = _Mock()

activate_matplotlib = _Mock()

backend2gui = _Mock()

backends = _Mock()

configure_inline_support = _Mock()

figsize = _Mock()

find_gui_and_backend = _Mock()

flag_calls = _Mock()

getfigs = _Mock()

import_pylab = _Mock()

mpl_runner = _Mock()

print_figure = _Mock()

retina_figure = _Mock()

select_figure_format = _Mock()

sys = _Mock()



class BytesIO(_Mock):
  pass


