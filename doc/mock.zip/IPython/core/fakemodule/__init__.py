from __future__ import print_function
from _mock import _Mock




init_fakemod_dict = _Mock()

types = _Mock()



class FakeModule(_Mock):
  pass


