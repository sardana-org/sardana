from __future__ import print_function
from _mock import _Mock




os = _Mock()

print_function = _Mock()

sqlite3 = _Mock()

trim_hist_help = 'Trim the IPython history database to the last 1000 entries.\n\nThis actually copies the last 1000 entries to a new database, and then replaces\nthe old file with the new.\n'

class Application(_Mock):
  pass


class BaseIPythonApplication(_Mock):
  pass
  _in_init_profile_dir = False

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Dict(_Mock):
  pass
  info_text = 'any value'

class HistoryApp(_Mock):
  pass
  description = 'Manage the IPython history database.'
  name = u'ipython-history'

class HistoryTrim(_Mock):
  pass
  _in_init_profile_dir = False
  description = 'Trim the IPython history database to the last 1000 entries.\n\nThis actually copies the last 1000 entries to a new database, and then replaces\nthe old file with the new.\n'

class Int(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

