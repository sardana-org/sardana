from __future__ import print_function
from _mock import _Mock




install_payload_page = _Mock()

page = _Mock()

publish_string = _Mock()



class InteractiveShell(_Mock):
  pass
  default_user_namespaces = True

