from __future__ import print_function
from _mock import _Mock

py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])


get_stream_enc = _Mock()

line_split = _Mock()

re = _Mock()

split_user_input = _Mock()

sys = _Mock()



class LineInfo(_Mock):
  pass


