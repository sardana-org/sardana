from __future__ import print_function
from _mock import _Mock

tokenize2 = __import__('IPython.utils.tokenize2', fromlist=['tokenize2'])


ESC_SEQUENCES = _Mock()

_help_end_re = _Mock()

_initial_space_re = _Mock()

_make_help_call = _Mock()

_strip_prompts = _Mock()

_tr_help = _Mock()

_tr_magic = _Mock()

_tr_paren = _Mock()

_tr_quote = _Mock()

_tr_quote2 = _Mock()

_tr_system = _Mock()

_tr_system2 = _Mock()

abc = _Mock()

assemble_logical_lines = _Mock()

assign_from_magic = _Mock()

assign_from_system = _Mock()

assign_magic_re = _Mock()

assign_system_re = _Mock()

cellmagic = _Mock()

classic_prompt = _Mock()

cookie_comment_re = _Mock()

escaped_commands = _Mock()

functools = _Mock()

generate_tokens = _Mock()

has_comment = _Mock()

help_end = _Mock()

ipy_prompt = _Mock()

leading_indent = _Mock()

re = _Mock()

strip_encoding_cookie = _Mock()

tr = _Mock()

untokenize = _Mock()

ESC_HELP = '?'

ESC_HELP2 = '??'

ESC_MAGIC = '%'

ESC_MAGIC2 = '%%'

ESC_PAREN = '/'

ESC_QUOTE = ','

ESC_QUOTE2 = ';'

ESC_SHELL = '!'

ESC_SH_CAP = '!!'

assign_magic_template = '%s = get_ipython().magic(%r)'

assign_system_template = '%s = get_ipython().getoutput(%r)'

class CoroutineInputTransformer(_Mock):
  pass
  _abc_negative_cache_version = 22

class InputTransformer(_Mock):
  pass
  _abc_negative_cache_version = 22

class LineInfo(_Mock):
  pass


class StatelessInputTransformer(_Mock):
  pass
  _abc_negative_cache_version = 22

class StringIO(_Mock):
  pass


class TokenError(_Mock):
  pass


class TokenInputTransformer(_Mock):
  pass
  _abc_negative_cache_version = 22

class assemble_python_lines(_Mock):
  pass
  _abc_negative_cache_version = 22

