from __future__ import print_function
from _mock import _Mock








class ExitAutocall(_Mock):
  pass
  rewrite = False

class IPyAutocall(_Mock):
  pass
  rewrite = True

class ZMQExitAutocall(_Mock):
  pass
  rewrite = False

