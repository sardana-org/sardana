from __future__ import print_function
from _mock import _Mock

coloransi = __import__('IPython.utils.coloransi', fromlist=['coloransi'])
py3compat = __import__('IPython.utils.py3compat', fromlist=['py3compat'])
release = __import__('IPython.core.release', fromlist=['release'])


PColLightBG = _Mock()

PColLinux = _Mock()

PColNoColors = _Mock()

_lenlastline = _Mock()

color_lists = _Mock()

cwd_filt = _Mock()

cwd_filt2 = _Mock()

lazily_evaluate = _Mock()

multiple_replace = _Mock()

os = _Mock()

prompt_abbreviations = _Mock()

re = _Mock()

socket = _Mock()

sys = _Mock()

time = _Mock()

HOME = u'/home/zreszela'

HOSTNAME = u'pc255'

HOSTNAME_SHORT = u'pc255'

ROOT_SYMBOL = '$'

USER = u'zreszela'

x = 5

class Bool(_Mock):
  pass
  default_value = False
  info_text = 'a boolean'

class Colors(_Mock):
  pass
  Black = '\x1b[0;30m'
  BlinkBlack = '\x1b[5;30m'
  BlinkBlue = '\x1b[5;34m'
  BlinkCyan = '\x1b[5;36m'
  BlinkGreen = '\x1b[5;32m'
  BlinkLightGray = '\x1b[5;37m'
  BlinkPurple = '\x1b[5;35m'
  BlinkRed = '\x1b[5;31m'
  BlinkYellow = '\x1b[5;33m'
  Blue = '\x1b[0;34m'
  Brown = '\x1b[0;33m'
  Cyan = '\x1b[0;36m'
  DarkGray = '\x1b[1;30m'
  Green = '\x1b[0;32m'
  LightBlue = '\x1b[1;34m'
  LightCyan = '\x1b[1;36m'
  LightGray = '\x1b[0;37m'
  LightGreen = '\x1b[1;32m'
  LightPurple = '\x1b[1;35m'
  LightRed = '\x1b[1;31m'
  NoColor = ''
  Normal = '\x1b[0m'
  Purple = '\x1b[0;35m'
  Red = '\x1b[0;31m'
  White = '\x1b[1;37m'
  Yellow = '\x1b[1;33m'
  _base = '\x1b[%sm'

class Configurable(_Mock):
  pass


class Dict(_Mock):
  pass
  info_text = 'any value'

class Formatter(_Mock):
  pass


class InputColors(_Mock):
  pass
  Black = '\x01\x1b[0;30m\x02'
  BlinkBlack = '\x01\x1b[5;30m\x02'
  BlinkBlue = '\x01\x1b[5;34m\x02'
  BlinkCyan = '\x01\x1b[5;36m\x02'
  BlinkGreen = '\x01\x1b[5;32m\x02'
  BlinkLightGray = '\x01\x1b[5;37m\x02'
  BlinkPurple = '\x01\x1b[5;35m\x02'
  BlinkRed = '\x01\x1b[5;31m\x02'
  BlinkYellow = '\x01\x1b[5;33m\x02'
  Blue = '\x01\x1b[0;34m\x02'
  Brown = '\x01\x1b[0;33m\x02'
  Cyan = '\x01\x1b[0;36m\x02'
  DarkGray = '\x01\x1b[1;30m\x02'
  Green = '\x01\x1b[0;32m\x02'
  LightBlue = '\x01\x1b[1;34m\x02'
  LightCyan = '\x01\x1b[1;36m\x02'
  LightGray = '\x01\x1b[0;37m\x02'
  LightGreen = '\x01\x1b[1;32m\x02'
  LightPurple = '\x01\x1b[1;35m\x02'
  LightRed = '\x01\x1b[1;31m\x02'
  NoColor = ''
  Normal = '\x01\x1b[0m\x02'
  Purple = '\x01\x1b[0;35m\x02'
  Red = '\x01\x1b[0;31m\x02'
  White = '\x01\x1b[1;37m\x02'
  Yellow = '\x01\x1b[1;33m\x02'
  _base = '\x01\x1b[%sm\x02'

class Instance(_Mock):
  pass
  info_text = 'any value'

class Int(_Mock):
  pass
  default_value = 0
  info_text = 'an int'

class LazyEvaluate(_Mock):
  pass


class PromptManager(_Mock):
  pass


class Unicode(_Mock):
  pass
  default_value = u''
  info_text = 'a unicode string'

class UserNSFormatter(_Mock):
  pass


